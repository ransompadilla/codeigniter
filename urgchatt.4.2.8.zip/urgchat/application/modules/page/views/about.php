<?php 
//Titlebar
//================================================== ?>
<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2><?php echo $pagename ?></h2>

				<!-- Breadcrumbs -->
				<nav id="breadcrumbs">
					<ul>
						<li><a href="<?php echo site_url(); ?>">Home</a></li>
						<li><?php echo ($pagename) ?></li>
					</ul>
				</nav>

			</div>
		</div>
	</div>
</div>



<?php  
//Content
//================================================== ?>
<div class="container">

	<!-- Blockquote
	================================================== -->
	<div class="row">
		<div class="col-md-12">
		<!-- Headline -->
        <p>
            Aussieflatmates.com.au ( Registered under ABN: 34 198 740 287 ) is a share accommodation website with the vision to provide Australian community an excellent service. It is a quick & time efficient way of room/ housemates/ team-ups hunting without the need to travel for room inspections, and allows landlords/ room- owners to be able to have their spare room rented out quickly.
        </p>      
        <p>      
            Based in Melbourne, we are concentrated mainly on helping students as tenants here and abroad including holiday workers finding hassle free accommodations in Australia.
        </p>
    
        <blockquote>
            <p>
                Aussieflatmates.com.au will be giving .50c of every membership's fee to the building of new homes in Philippines for the disadvantage people living in the remote areas.
            </p>
            <p>
                “ Listings are active, up-to-date and constantly monitored.”
            </p>
            <p>“ Your data is secured and will not be shared elsewhere. You will only be contacted regarding your listings, searches & memberships. ”
</p>
        </blockquote>
		</div>
	</div>
</div>
