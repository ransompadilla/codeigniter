<?php 
//Titlebar
//================================================== ?>
<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2><?php echo $pagename ?></h2>

				<!-- Breadcrumbs -->
				<nav id="breadcrumbs">
					<ul>
						<li><a href="<?php echo site_url(); ?>">Home</a></li>
						<li><?php echo ($pagename) ?></li>
					</ul>
				</nav>

			</div>
		</div>
	</div>
</div>



<?php  
//Content
//================================================== ?>
<div class="container">

	<!-- Blockquote
	================================================== -->
	<div class="row">
		<div class="col-md-8 col-md-offset-2">
		<!-- Headline -->
				
				<!--Tabs -->
				<div class="style-1">

					
					<div class="tabs-container alt">

						<!-- Register -->
						<div class="tab-content" id="tab2" style="display: none;">
							<div class="msg"></div>
							<form action="<?php echo site_url('user/signup'); ?>" method="post" class="register">
							
							<!-- <input type="hidden" name="<?php //echo $this->security->get_csrf_token_name();?>" value="<?php echo $this->security->get_csrf_hash();?>"> -->
							<div class="col-md-6">
									<label for="first_name">First Name:
										<input type="text" class="input-text" name="first_name"  value="<?php echo set_value('first_name'); ?>" />
									</label>
									<?php echo form_error('first_name'); ?>
							</div>
							<div class="col-md-6">
									<label for="last_name">Last Name:
										<input type="text" class="input-text" name="last_name"  value="<?php echo set_value('last_name'); ?>" />
									</label>
									<?php echo form_error('last_name'); ?>
							</div>

							<div class="col-md-6">
								<label for="gender">Gender:
									<select class="chosen-select-no-single input-text" name="gender">
										<option label="blank">Select Gender</option>	
										<option value="male">Male</option>
										<option value="female">Female</option>
										<option value="other">Other</option>
									</select>
								</label>
								<?php echo form_error('gender'); ?>
							</div>
							<div class="col-md-6">
								<label for="status">Status:
									<select class="chosen-select-no-single input-text" name="status">
										<option label="blank">Select Status</option>	
										<option value="student">student</option>
										<option value="employed">employed</option>
										<option value="self employed">self employed</option>
										<option value="office worker">office worker</option>
										<option value="hospitality worker">hospitality worker</option>
										<option value="un-emplpoyed">un-emplpoyed</option>
										<option value="disable">disable</option>
									</select>
								</label>
								<?php echo form_error('status'); ?>
							</div>
							<div class="col-md-6">
								<label for="email">Age:
									<input type="text" class="input-text" name="age" value="<?php echo set_value('phone'); ?>" />
								</label>
								<?php echo form_error('age'); ?>
							</div>
							<div class="col-md-6">
								<label for="email">Phone:
									<input type="text" class="input-text" name="phone" value="<?php echo set_value('phone'); ?>" />
								</label>
								<?php echo form_error('phone'); ?>
							</div>	
							<div class="col-md-12">		
								<label for="email">Email Address:
									<input type="text" class="input-text" name="email" value="<?php echo set_value('email'); ?>" />
								</label>
								<?php echo form_error('email'); ?>
							</div>
							<div class="col-md-12">
								<hr/>
							</div>
							<div class="col-md-6">
								<label for="password1">Password:
									<input class="input-text" type="password" name="password1" />
								</label>
								<?php echo form_error('password1'); ?>
							</div>

							<div class="col-md-6">
								<label for="password2">Repeat Password:
									<input class="input-text" type="password" name="password2" />
								</label>
								<?php echo form_error('password2'); ?>
							</div>

							<div class="col-md-12">
								<div class="checkboxes margin-top-10">
									<input id="remember-me" type="checkbox" name="check">
									<label for="remember-me">I’ve read and agree to <a href="" target="_blank" style="color:#f91942">Terms and Conditions</a></label>
								</div>
							</div>

							<div class="col-md-12">
								<input type="submit" class="button border fw margin-top-10" name="register" value="Register" />
							</div>
							</form>
						</div>
					</div>
					
				</div>
		</div>
	</div>
</div>
