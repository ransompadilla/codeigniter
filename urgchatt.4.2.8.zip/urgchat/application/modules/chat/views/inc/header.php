<!DOCTYPE html>
<html>

<!-- Basic Page Needs
================================================== -->
<title>Aussie Flatmates</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/chat.css">
<!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.css"> -->

 <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-2.2.0.min.js"></script>

<script>var base_url = '<?php echo base_url() ?>';</script>
<!--script async src="<?php //echo base_url();?>assets/pscripts/b4a721cfb6.php"></script-->
<script type="text/javascript">
	var base_url = '<?php echo base_url() ?>';
	var list_id = $('#list_id').val();

$(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);

// $('#message-to-send').keyup(function(){
  
//   $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
// });
  
$(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
  $('#message-to-send').change(function(){
    var datas = {
                "from"      :$('#from').val(),
                "to"        :$('#to').val(),
                "message"   :$('#message-to-send').val()
              }
             
           
    if(datas.message != ""){
      var ctr=0;
        $.ajax({
          url : base_url + "chat/push_message",
          type : "POST",
          data : datas,
          success : function(data) {
            $('#message-to-send').val('');
            var interval = setInterval(function(){ 
              ctr++;
              if(ctr > 5){
                clearInterval(interval);

                ctr=0;
              }
              if(list_id == ""){
                $('.chat-history').load(base_url+'chat/load_chat/'+datas.to);
                $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
              }
              else{ 
                $('.chat-history').load(base_url+'chat/load_chat/'+datas.to+"/"+list_id);
                $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
              }
              
             }, 2000);

           
          },
          error : function(data) {
              // do something
          }
      
      });

    }
    
  });



  $('#get-in-touch').click(function(){
    $('.chat').toggle();
    $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
  });  

  // $.ajaxSetup({cache:false});

	
</script>
</head>
<body>
