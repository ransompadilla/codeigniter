<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Profile extends MY_Controller {

	public function __construct(){
        parent::__construct();
        if(!$this->check_login())
			redirect('/');
    }

	public function index(){
		$a_data = array(
			's_navcurrent'	=> 'profile',
			'pagename'		=> 'Profile'
		);

		// $this->mybreadcrumb->add('Home', base_url());
		// $this->mybreadcrumb->add('Dashboard', base_url('dashboard'));
		// $this->mybreadcrumb->add('Add Listing', base_url('listing'));
		// $data['breadcrumbs'] = $this->mybreadcrumb->render();
		 
	
		$this->dash_display('profile',$a_data);

	}



}
