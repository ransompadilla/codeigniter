<!-- Footer
================================================== -->
<div id="footer" class="dark sticky-footer margin-top-55">
	<!-- Main -->
	<div class="container">
		<div class="row">
			<div class="col-md-5 col-sm-6">
				<img class="footer-logo" src="assets/images/aussie.png" alt="">
				<br><br>
				<p>Aussieflatmates.com.au is a share accommodation website with the vision to provide Australian community an excellent service. It is a quick & time efficient way of room/ housemates/ team-ups hunting without the need to travel for room inspections, and allows landlords/ room- owners to be able to have their spare room rented out quickly.</p>

			</div>

			<div class="col-md-4 col-sm-6 ">
				<h4>Helpful Links</h4>
				<ul class="footer-links">
					<li><a href="#">Pricing</a></li>
					<li><a href="#">Privacy Policy</a></li>					
					<li><a href="#">FAQ</a></li>
				</ul>

				<ul class="footer-links">
					<li><a href="#">Blog</a></li>
					<!-- <li><a href="#">Our Partners</a></li> -->
					<li><a href="#">How It Works</a></li>
					<li><a href="#">Contact</a></li>
				</ul>
				<div class="clearfix"></div>
			</div>		

			<div class="col-md-3  col-sm-12">
				<h4>Connect Us</h4>
				<ul class="social-icons margin-top-20">
					<li><a class="facebook" href="#"><i class="icon-facebook"></i></a></li>
					<li><a class="twitter" href="#"><i class="icon-twitter"></i></a></li>
					<li><a class="gplus" href="#"><i class="icon-gplus"></i></a></li>
					<li><a class="vimeo" href="#"><i class="icon-vimeo"></i></a></li>
				</ul>

				

			</div>

		</div>
		
		<!-- Copyright -->
		<div class="row">
			<div class="col-md-12">
				<div class="copyrights">© 2018 Aussie. All Rights Reserved | Powered by: <a href="https://urgwebsolutions.com/" target="_blank">URG Websolutions</a></div>
			</div>
		</div>

	</div>

</div>
<!-- Footer / End -->

<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>

 <!-- <script data-cfasync="false" src="../../cdn-cgi/scripts/d07b1474/cloudflare-static/email-decode.min.js"></script> -->
<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/mmenu.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chosen.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/slick.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/rangeslider.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/magnific-popup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/waypoints.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/counterup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/tooltips.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chatjs.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/myscript.js"></script>
<!-- <script type="text/javascript" src="<?php echo base_url();?>assets/js/dropzone.js"></script> -->
<!-- <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/maps.js"></script> -->

