<div class="main-search-container" data-background-image="assets/images/banner-cap.jpg" style='background-image: url("assets/images/main-search-background-01.jpg");'>
	<div class="main-search-inner">

		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<h2>FIND SHARE ACCOMMODATION EASY</h2>
					<h4>Discover the Easy way for Aussie's to find the perfect ROOM to RENT, Apartment or a house to share, with the search tools designed for both locals, student’s and tourists. </h4>

					<div class="main-search-input">

						<div class="main-search-input-item">
							<input type="text" placeholder="What are you looking for?" value=""/>
						</div>

						<div class="main-search-input-item">
							<select data-placeholder="All Categories" class="chosen-select" >
								<option>Select Location</option>	
								<option value="VIC">VIC</option>	
								<option value="NSW">NSW</option>	
								<option value="QLD">QLD</option>	
								<option value="WA">WA</option>	
								<option value="SA">SA</option>	
								<option value="ACT">ACT</option>	
							</select>
						</div>

						<div class="main-search-input-item">
							<select data-placeholder="All Categories" class="chosen-select" >
								<option>All Categories</option>	
								<?php
								foreach($categories as $val){
									echo "<option value=\"".$val->cat_name."\">".ucfirst($val->cat_name)."</option>";
								}
								?>
							</select>
						</div>

						<button class="button" onclick="window.location.href='listings-half-screen-map-list.html'">Search</button>

					</div>
				</div>
			</div>
		</div>

	</div>
</div>