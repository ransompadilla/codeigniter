
var list_id = $('#list_id').val();

$(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);

// $('#message-to-send').keyup(function(){
  
//   $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
// });
  
$(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
  $('#message-to-send').change(function(){
    var datas = {
                "from"      :$('#from').val(),
                "to"        :$('#to').val(),
                "message"   :$('#message-to-send').val()
              }
    if(datas.message != ""){
      var ctr=0;
        $.ajax({
          url : base_url + "chat/push_message",
          type : "POST",
          data : datas,
          success : function(data) {
            $('#message-to-send').val('');
            var interval = setInterval(function(){ 
              ctr++;
              if(ctr > 5){
                clearInterval(interval);

                ctr=0;
              }
              if(list_id == ""){
                $('.chat-history').load(base_url+'chat/load_chat/'+datas.to);
                $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
              }
              else{ 
                $('.chat-history').load(base_url+'chat/load_chat/'+datas.to+"/"+list_id);
                $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
              }
              
             }, 2000);

           
          },
          error : function(data) {
              // do something
          }
      
      });

    }
    
  });



  $('#get-in-touch').click(function(){
    $('.chat').toggle();
    $(".chat-history").scrollTop($(".chat-history")[0].scrollHeight);
  });  

  // $.ajaxSetup({cache:false});
