$(document).ready(function(){
	// my_listings
	$(document).on('click', '.image_del', function(e){
		e.preventDefault();
		
		var id_list = $('.image_del').attr('data-id_list');
		var id_photo = $('.image_del').attr('data-id_photo');
		var url = base_url + "my_listings/delete_listings_photo/list/" + id_list + "/photo/" + id_photo;

		var msg_confirm = confirm("Are you sure you want to delete this photo?");

		if(msg_confirm){
			$.ajax({
				method: "POST", 
				url: url,
				success: function(data){

					$('body, html').animate({scrollTop:$('#titlebar').offset().top}, 'slow');
                    $('#notify').append().html(data);
                    setTimeout(function(){
                        window.location.reload();
                    }, 3000);

				}
			}); 	
		}
	});

	$('.register').submit(function(e){
		e.preventDefault();

		var para = {}
		para['url']  = $(this).attr('action');
		para['post'] = $(this).serialize();
		var getAjax = para;
		autoCall(getAjax, function (data) {
			//console.log(data);
			data = JSON.parse(data);

			if(data.status){
				$('.msg').html("<div class='notification success closeable'>"+ data.msg +"</div>");

				$('html, body').animate({
					scrollTop: $("#tab2").offset().top
				 }, 2000);				 
				$('form.register').find("input[type=text], textarea, input[type=password]").val("");
			}else{
				$('html, body').animate({
					scrollTop: $("#tab2").offset().top
				 }, 2000);
				$('.msg').html("<div class='notification error closeable'>"+ data.msg +"</div>");
			}
		});
		// return false;
	});



	$('.login').submit(function(e){
		
		e.preventDefault();
		var para = {}
		para['url']  = $(this).attr('action');
		para['post'] = $(this).serialize();
		var getAjax = para;
		autoCall(getAjax, function (data) {
			data = JSON.parse(data);  
			if(data.status){
				$('.msg_signin').html("<div class='notification success closeable'>"+ data.msg +"</div>");

				setTimeout(function(){
					window.location.href= base_url+"user";
				},2000);

			}else{
				$('html, body').animate({
					scrollTop: $("#tab1").offset().top
				 }, 2000);
				$('.msg_signin').html("<div class='notification error closeable'>"+ data.msg +"</div>");
			}
		});
				
		//return false;
	});


});

$(window).load(function() {
	loaderOut();	
 });


 function loaderOut(){
	setTimeout(function(){
		$('#loading').fadeOut(1000);
	}, 1000);
 }
 function loaderIn(){
		$('#loading').fadeIn(1000);
 }

 function autoCall(parArray, callback) {
	$.ajax({
		async: false,
		url: parArray['url'],
		//dataType: "json",
		type: "POST",
		data:parArray['post'],
		success: callback,
		beforeSend:function(){
			loaderIn();
		},
		error : function(jqXHR) {
			var msg = '';
			if (jqXHR.status === 0) {
				msg = 'Not connect.\n Verify Network.';
			} else if (jqXHR.status == 404) {
				msg = 'Requested page not found. [404]';
			} else if (jqXHR.status == 500) {
				msg = 'Internal Server Error [500].';
			} else if (exception === 'parsererror') {
				msg = 'Requested JSON parse failed.';
			} else if (exception === 'timeout') {
				msg = 'Time out error.';
			} else if (exception === 'abort') {
				msg = 'Ajax request aborted.';
			} else {
				msg = 'Uncaught Error.\n' + jqXHR.responseText;
			}
			console.log(msg);
		}
	});
	loaderOut();
}

