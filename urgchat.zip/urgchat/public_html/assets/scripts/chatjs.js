
  $('#message').change(function(){


    var data = {
                "from"      :$('#from').val(),
                "to"        :$('#to').val(),
                "message"   :$('#message').val()
              }
     $.ajax({
        url : baseurl + "chat/push_message",
        type : "POST",
        dataType : "json",
        data : data,
        success : function(data) {
          alert('success');
        },
        error : function(data) {
            // do something
        }
    });

  });

  // $.ajaxSetup({cache:false});
