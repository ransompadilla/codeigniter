<?php
class ListingModel extends MY_Model{

	public $table = 'listings';

	function __construct(){
		parent::__construct();
	}

	function getLastListing($id_user, $id_list){
		
		$this->db->where('id_user', $id_list);
		$this->db->where('id_user', $id_user);
		$query = $this->db->get('list');
		
		if($query->row()){
			return $query->row();
		}else{
			return false;
		}
	}

	function getlistings($where = ''){
		$this->db->select('*');
   		$this->db->from('listings a'); 
		$this->db->join('categories b', 'b.cat_id=a.category', 'left');

		if(is_array($where) && count($where) > 0){
			$this->db->where($where);
		}

		$query = $this->db->get(); 
		
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}

	
	function getlisting($where = ''){
		/*$this->db->select('*');
   		$this->db->from('listings a'); 
		$this->db->join('categories b', 'b.cat_id=a.category', 'left');
		$this->db->where($where);*/
		$fw = '';
		if(is_array($where)){
			$st = true;
			foreach($where as $key => $val){
				if($st){
					$fw = 'WHERE '. $key .'="'. $val.'"';
					$st = false;
				}else{
					$fw .= ' AND '.$key .'="'. $val.'"';
				}
			}
		}else{
			$fw = $where;
		}

		$sql = "SELECT * FROM listings as a LEFT JOIN categories as b ON b.cat_id=a.category ".$fw;
		$query = $this->db->query($sql);
		$query = $query->row(); 
		//var_dump(count($query));
		// if(count($query) == 1){
		 	//return (count($query) == 1) ? $query : false;
		// }
		// else{
		// 	return false;
		// }
	}

}

?>