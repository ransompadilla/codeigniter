<?php 
//Titlebar
//================================================== ?>
<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2><?php echo $pagename ?></h2>

				<!-- Breadcrumbs -->
				<nav id="breadcrumbs">
					<ul>
						<li><a href="<?php echo site_url(); ?>">Home</a></li>
						<li><?php echo ($pagename) ?></li>
					</ul>
				</nav>

			</div>
		</div>
	</div>
</div>


<?php  
//Content
//================================================== ?>
<div class="container">
	<div class="row">

		<div class="col-lg-9 col-md-8 padding-right-30">

			<!-- Sorting / Layout Switcher -->
			<div class="row margin-bottom-25">
				<!--
				<div class="col-md-6 col-xs-6">
				</div>

				<div class="col-md-6 col-xs-6">
					 Sort by >
					<div class="sort-by">
						<div class="sort-by-select">
							<select data-placeholder="Default order" class="chosen-select-no-single">
								<option>Default Order</option>	
								<option>Highest Rated</option>
								<option>Most Reviewed</option>
								<option>Newest Listings</option>
								<option>Oldest Listings</option>
							</select>
						</div>
					</div>
				</div-->
			</div>
			<!-- Sorting / Layout Switcher / End -->


			<div class="row">

				<?php 
				if(count($listings)> 0){
					foreach($listings as $val){
				?>
					<!-- Listing Item -->
					<div class="col-lg-6 col-md-12">
						<a href="listings-single-page.html" class="listing-item-container">
							<div class="listing-item">
									<?php 
									$media = unserialize($val->media);
									if(array_key_exists('images',$media) && $media['images'] != ''):
									?>
										<img src="<?php echo site_url('uploads/listing/'.$media['images'][0]); ?>" alt="<?php echo $val->title_for ?>"></a>
									<?php
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
									<?php 
									endif;
									?>
																
								<div class="listing-item-content">
									<span class="tag"><?php echo $val->cat_name; ?></span>
									<h3><?php echo $val->title_for ?><i class="verified-icon"></i></h3>
									<span><?php echo $val->location ?></span>
								</div>
								<span class="like-icon"></span>
							</div>
							<div class="star-rating" data-rating="3.5">
								<div class="rating-counter">(12 reviews)</div>
							</div>
						</a>
					</div>
					<!-- Listing Item / End -->
				<?php }
				}else{?>
					<div class="col-lg-6 col-md-12">No Data Found.</div>
				<?php } ?>
			</div>

			<!-- Pagination -->
			<div class="clearfix"></div>
			<div class="row">
				<div class="col-md-12">
					<!-- Pagination -->
					<div class="pagination-container margin-top-20 margin-bottom-40">
						<nav class="pagination">
							<ul>
								<li><a href="#" class="current-page">1</a></li>
								<li><a href="#">2</a></li>
								<li><a href="#">3</a></li>
								<li><a href="#"><i class="sl sl-icon-arrow-right"></i></a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
			<!-- Pagination / End -->

		</div>


		<!-- Sidebar
		================================================== -->
		<?php include 'inc/sidebar.php'; ?>
		<!-- Sidebar / End -->

	</div>
</div>
