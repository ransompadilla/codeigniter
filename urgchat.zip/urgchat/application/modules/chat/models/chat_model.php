<?php
class Chat_Model extends MY_Model{

	public function __construct(){
		parent::__construct();
	}
	public function getUsers(){
		return $this->getallQuery('select * from users');
	}
	public function getUserToChat($id){
		return $this->getRowQuery('select * from users where id='.$id.'');
	}
	public function pushMessage($data){
		return $this->insertData('chat',$data);
	}
	public function getChatLogs(){
		return $this->getallQuery('select * from chat order by time desc');
	}
	public function getFrom($id){
		return $this->getRowQuery('select * from chat where from='.$id.'');
	}
	public function getTo($id){
		return $this->getRowQuery('select * from chat where to='.$id.'');
	}
}
?>