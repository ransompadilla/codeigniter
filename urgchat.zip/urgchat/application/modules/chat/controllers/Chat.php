<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Chat extends MY_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('chat_model');
    }
    function index(){
    	$data['users'] = $this->chat_model->getUsers();
    	$this->load->view('content/chat-box', $data);
    }
    function with($id){
    	$data['users'] = $this->chat_model->getUsers();
    	$data['to'] = $this->chat_model->getUserToChat($id);

    	$data['chats'] = $this->chat_model->getChatLogs();
    	
    	$this->load->view('content/chat-box', $data);	
    }
    function push_message(){
    	$data = array(
    		'from'		=>$this->input->post('from'),
    		'to'		=>$this->input->post('to'),
    		'message'	=>$this->input->post('message')
    	);
   		$this->chat_model->pushMessage($data);
    }
    function chat_logs(){

    }
}
?>