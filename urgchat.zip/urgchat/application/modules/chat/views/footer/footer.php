	 <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-2.2.0.min.js"></script>

	 <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chatjs.js"></script>

</body>
</html>