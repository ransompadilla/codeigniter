<!DOCTYPE html>
<html>
<head>
	<title>Aussie Flatmates</title>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

	<!-- CSS
	================================================== -->
	<script type="text/javascript">var baseurl = "<?php echo base_url();?>"</script>
	 <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-2.2.0.min.js"></script>

	 <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chatjs.js"></script>

	<link rel="stylesheet" href="<?php echo base_url();?>assets/css/chat.css">

</head>
<body>
