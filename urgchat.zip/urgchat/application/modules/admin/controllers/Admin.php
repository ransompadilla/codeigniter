<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Admin extends MY_Controller{

	public function __construct(){
		parent::__construct();
		$this->load->model('admin_model');
	}

	function index(){
		$a_data = array(
			's_navcurrent'	=> 'admin',
			'pagename'		=> 'Admin'
		);

		$this->dash_display('admin',$a_data);
	}
	public function dashboard(){
		$this->userAuth();

		$a_data = array(
			's_navcurrent'	=> 'dashboard',
			'pagename'		=> 'Dashboard'
		);
		 
	
		$this->dash_display('dashboard',$a_data);
	}

	public function messages(){
		$this->userAuth();

		$this->load->module('messages/messages');

		$this->messages->user_messages();
	}

	public function profile(){
		$this->userAuth();

		$a_data = array(
			's_navcurrent'	=> 'profile',
			'pagename'		=> 'Profile'
		);

		// $this->mybreadcrumb->add('Home', base_url());
		// $this->mybreadcrumb->add('Dashboard', base_url('dashboard'));
		// $this->mybreadcrumb->add('Add Listing', base_url('listing'));
		// $data['breadcrumbs'] = $this->mybreadcrumb->render();
		
		$this->dash_display('profile',$a_data);
	}
	
	public function listings(){
		$this->userAuth();

		$a_data = array(
			's_navcurrent'	=> 'user-listing',
			'pagename'		=> 'Listing',
		);	
		$this->dash_display('user_listing',$a_data);
	}	

	public function add_listing(){
		$this->userAuth();
		
		//$msg = 'M';
		//echo bin2hex($this->encryption->create_key(16));

		//$ke = $this->encryption->encrypt($msg);
		//echo $ke;
		//echo '<br/>';
		//echo  $this->encryption->decrypt($ke);
		

		$a_data = array(
			's_navcurrent'	=> 'add-listing',
			'pagename'		=> 'Add Listing',
		);	

		$this->load->module('amenities/amenities');
		$a_data['amenities'] = $this->amenities->getAmenities();

		$this->load->module('category/category');	
		$a_data['categories'] = $this->category->getCategories(); 

		$this->dash_display('add_listing',$a_data);
	}


	
}
