<head>
<!-- Basic Page Needs
================================================== -->
<title>Aussie Flatmates</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

<!-- CSS
================================================== -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/colors/main.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/dropzone.min.css">
<!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.css"> -->

 <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-2.2.0.min.js"></script>

<script>var base_url = '<?php echo base_url() ?>';</script>
<!--script async src="<?php //echo base_url();?>assets/pscripts/b4a721cfb6.php"></script-->
<?php 
if(isset($map) && isset($map['js'])): 
    echo $map['js']; 
endif;
?>
</head>