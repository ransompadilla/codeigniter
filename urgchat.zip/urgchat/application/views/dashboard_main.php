<!DOCTYPE html>
<?php
    echo $head;
?>
<html>
    <body>
        <div id="wrapper">
            <?php
                echo $header;
            ?>
            <div id="dashboard">
                <?php
                echo $nav;
                ?>
                <div class="dashboard-content">
                    <?php
                        echo $body;
                    ?>
                </div>            
            </div>            
        </div>
    
    <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/custom.js"></script>        
    <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chosen.min.js"></script>        
    <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/slick.min.js"></script>        
    <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/rangeslider.min.js"></script>        
    <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/magnific-popup.min.js"></script>        
    <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/tooltips.min.js"></script>        
    <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/counterup.min.js"></script>        
    <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/dropzone.js"></script>        
    
    </body>
</html>
