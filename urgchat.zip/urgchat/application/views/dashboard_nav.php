<!-- Navigation
    ================================================== -->

    <!-- Responsive Navigation Trigger -->
    <a href="#" class="dashboard-responsive-nav-trigger"><i class="fa fa-reorder"></i> Dashboard Navigation</a>

    <div class="dashboard-nav">
        <div class="dashboard-nav-inner">
            <?php if($this->session->userdata('user_info')->role == 1): ?>
                <ul data-submenu-title="Main">
                    <li <?php if($s_navcurrent == 'dashboard'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/dashboard'); ?>"><i class="sl sl-icon-settings"></i> Dashboard</a></li>
                    <li <?php if($s_navcurrent == 'messages'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/messages'); ?>"><i class="sl sl-icon-envelope-open"></i> Messages <!-- <span class="nav-tag messages">2</span> --></a></li>
                    <!--li <?php //if($s_navcurrent == 'bookings'){ echo 'class="active"'; } ?> ><a href="<?php //echo base_url('bookings'); ?>"><i class="fa fa-calendar-check-o"></i> Bookings</a></li-->
                </ul>
                
                <ul data-submenu-title="Listings">
                    <li <?php if($s_navcurrent == 'add-listing' || 'profile-Post'){ echo 'class="active"'; } ?> ><a><i class="sl sl-icon-plus"></i> Add Listing</a>
                        <ul>                            
                            <li><a href="<?php echo base_url('user/add-listing'); ?>"><i class="sl sl-icon-direction"></i> List a Place </a></li>
                            <li><a href="<?php echo (isset($mywanted) && count($mywanted) > 0)  ? site_url('user/edit-listing/'.$mywanted->id_list) : site_url('user/profile-post'); ?>"><i class="sl sl-icon-user"></i> Find a Place </a></li>
                        </ul>
                    </li>
                    
                    <li <?php if($s_navcurrent == 'user-listing'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/listings'); ?>"><i class="sl sl-icon-layers"></i>My Listings <!-- <span class="nav-tag green">6</span> --></a></li>
                    <li <?php if($s_navcurrent == 'reviews'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('reviews'); ?>"><i class="sl sl-icon-star"></i> Reviews</a></li>
                </ul> 
            <?php endif; ?>
            
            <?php // ------------ADMIN NAV ------------- //
            if($this->session->userdata('user_info')->role == 0): ?>
                <ul data-submenu-title="Main">
                    <li <?php if($s_navcurrent == 'dashboard'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/dashboard'); ?>"><i class="sl sl-icon-settings"></i> Dashboard</a></li>
                    <li <?php if($s_navcurrent == 'messages'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/messages'); ?>"><i class="sl sl-icon-envelope-open"></i> Messages <!-- <span class="nav-tag messages">2</span> --></a></li>
                    <!--li <?php //if($s_navcurrent == 'bookings'){ echo 'class="active"'; } ?> ><a href="<?php //echo base_url('bookings'); ?>"><i class="fa fa-calendar-check-o"></i> Bookings</a></li-->
                </ul>

                <ul data-submenu-title="Listings">
                    <li <?php if($s_navcurrent == 'user-listing'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/listings'); ?>"><i class="sl sl-icon-layers"></i>Listings <!-- <span class="nav-tag green">6</span> --></a>    
                    </li>
                    <li <?php if($s_navcurrent == 'reviews'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('reviews'); ?>"><i class="sl sl-icon-star"></i> Reviews</a></li>
                </ul> 

                <ul data-submenu-title="Users">
                    <li <?php if($s_navcurrent == 'add-user'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/add-user'); ?>"><i class="sl sl-icon-plus"></i> Add User</a></li>
                    <li <?php if($s_navcurrent == 'user-active-users'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/active-users'); ?>"><i class="sl sl-icon-user"></i>Active Users <!-- <span class="nav-tag green">6</span> --></a>    
                    </li>
                    <li <?php if($s_navcurrent == 'Inactive'){ echo 'class="active"'; } ?> ><a href="<?php echo base_url('user/inactive-users'); ?>"><i class="sl sl-icon-user"></i> Inactive Users</a></li>
                </ul> 
            <?php endif; ?>
            
        </div>
    </div>
    <!-- Navigation / End -->