<div class="container">
	<div class="row">

		<div class="col-md-12">
			<h3 class="headline centered margin-top-75">
				Categories
				<span>Browse by Category</span>
			</h3>
		</div>

	</div>
</div>


<!-- Categories Carousel -->
<div class="fullwidth-carousel-container margin-top-25">
	

		<!-- Item -->
	<?php 
	if(count($categories) >0){ ?>

	<div class="fullwidth-slick-carousel category-carousel">

		<?php foreach($categories as $val){
		?>
			<div class="fw-carousel-item">
				<div class="category-box-container">
					<a href="listings-half-screen-map-grid-1.html" class="category-box" data-background-image="<?php echo site_url('uploads/category/'.$val->cat_cover) ?>" style='background-image: url("<?php echo site_url('assets/images/room.jpg') ?>");'>
						<div class="category-box-content">
							<h3><?php echo ucfirst($val->cat_name); ?></h3>
							<?php //<span>0 listings</span> ?>
						</div>
						<span class="category-box-btn">Browse</span>
					</a>
				</div>
			</div>
		<?php 
			}?>
			
	</div>
	<?php
	}else{ ?>
		<div class="row">
			<div class="col-md-12">No Category Found</div>
		</div>
	
	<?php 
	}
	?>

</div>
<!-- Categories Carousel / End -->

<!-- Info Section -->
<div class="container">

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h2 class="headline centered margin-top-80">
				How It Works? 
				<span class="margin-top-25"></span>
			</h2>
		</div>
	</div>

	<div class="row icons-container">
		<!-- Stage -->
		<div class="col-md-3">
			<div class="icon-box-2 with-line">
				<i class="im im-icon-Add-User"></i>
				<h3>REGISTER</h3>
			</div>
		</div>

		<!-- Stage -->
		<div class="col-md-3">
			<div class="icon-box-2 with-line">
				<i class="im im-icon-Mail-withAtSign"></i>
				<h3>VERIFY YOUR ACCOUNT</h3>
			</div>
		</div>

		<!-- Stage -->
		<div class="col-md-3">
			<div class="icon-box-2 with-line">
				<i class="im im-icon-Home-Window"></i>
				<h3>SEARCH OR LIST PROPERTY</h3>
			</div>
		</div>

		<!-- Stage -->
		<div class="col-md-3">
			<div class="icon-box-2">
				<i class="im im-icon-Hand-TouchSmartphone"></i>
				<h3>MAKE A CONTACT</h3>
			</div>
		</div>
	</div>

	<div class="row">
		<div class="col-md-8 col-md-offset-2">
			<h3 class="headline centered margin-top-80">
				HOSTING SERVICES 
				<span class="margin-top-25"></span>
			</h3>
		</div>
	</div>

	<div class="row icons-container">
		<!-- Stage -->
		<div class="col-md-6 got">
			<h3 class="center">Guest Account</h3>
			<ul class="list-group icon-list" style="list-style:none">
				<li class="list-group-item"><i class="fa fa-"></i>REGISTER </li>
				<li class="separator"><i class="im im-icon-Arrow-Down2"></i></li>
				<li class="list-group-item">VERIFY YOUR ACCOUNT </li>
				<li class="separator"><i class="im im-icon-Arrow-Down2"></i></li>
				<li class="list-group-item">SEARCH PROPERTY </li>
				<li class="separator"><i class="im im-icon-Arrow-Down2"></i></li>
				<li class="list-group-item">BOOK A ROOM</li>
				<li class="separator"><i class="im im-icon-Arrow-Down2"></i></li>
				<li class="list-group-item">MAKE A PAYMENT</li>
			</ul>
		</div>

		<!-- Stage -->
		<div class="col-md-6 got">
			<h3 class="center">Host Account</h3>
			<ul class="list-group icon-list" style="list-style:none">
				<li class="list-group-item"><i class="fa fa-"></i>REGISTER </li>
				<li class="separator"><i class="im im-icon-Arrow-Down2"></i></li>
				<li class="list-group-item">VERIFY YOUR ACCOUNT </li>
				<li class="separator"><i class="im im-icon-Arrow-Down2"></i></li>
				<li class="list-group-item">LIST YOUR PROPERTY </li>
				<li class="separator"><i class="im im-icon-Arrow-Down2"></i></li>
				<li class="list-group-item">SET AVAILABILITY DATE</li>
				<li class="separator"><i class="im im-icon-Arrow-Down2"></i></li>
				<li class="list-group-item">SET UP YOUR ACCOUNT FOR PAYMENTS.</li>
			</ul>
		</div>
	</div>	

</div>
<!-- Info Section / End -->

<div class="container">
	<div class="row">

		<div class="col-md-12">
			<h3 class="headline centered margin-bottom-35 margin-top-70">Popular Cities <span>Browse listings in popular places</span></h3>
		</div>
		
		<div class="col-md-4">

			<!-- Image Box -->
			<a href="listings-list-with-sidebar.html" class="img-box" data-background-image="<?php echo site_url('assets/images/melbourne.jpg') ?>">
				<div class="img-box-content visible">
					<h4>Melbourne</h4>
					<?php //<span>14 Listings</span> ?>
				</div>
			<div class="img-box-background" style="background-image: url(<?php echo site_url('assets/images/melbourne.jpg')?>);"></div></a>

		</div>	
			
		<div class="col-md-8">

			<!-- Image Box -->
			<a href="listings-list-with-sidebar.html" class="img-box" data-background-image="<?php echo site_url('assets/images/sydney.jpg') ?>">
				<div class="img-box-content visible">
					<h4>Sydney</h4>
				</div>
			<div class="img-box-background" style="background-image: url(<?php echo site_url('assets/images/sydney.jpg')?>);"></div></a>

		</div>	

		<div class="col-md-8">

			<!-- Image Box -->
			<a href="listings-list-with-sidebar.html" class="img-box" data-background-image="<?php echo site_url('assets/images/brisbane.jpg') ?>">
				<div class="img-box-content visible">
					<h4>Brisbane</h4>
				</div>
			<div class="img-box-background" style="background-image: url(<?php echo site_url('assets/images/brisbane.jpg')?>);"></div></a>

		</div>	
			
		<div class="col-md-4">

			<!-- Image Box -->
			<a href="listings-list-with-sidebar.html" class="img-box" data-background-image="<?php echo site_url('assets/images/perth.jpg') ?>">
				<div class="img-box-content visible">
					<h4>Perth</h4>
				</div>
			<div class="img-box-background" style="background-image: url(<?php echo site_url('assets/images/perth.jpg')?>);"></div></a>

		</div>

	</div>
</div>