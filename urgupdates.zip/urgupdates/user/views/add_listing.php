<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2>Add Listing</h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li><a href="<?php echo site_url('user/dashboard'); ?>">Dashboard</a></li>
                    <li>Add Listing</li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!-- form open-->
            <?php echo form_open_multipart(site_url('user/add_listing'), array('id'=>'listingni1')); ?>
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if(isset($notify) && $notify != '' ){
                            //$notify = $this->session->flashdata('notify');
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                    <h3><i class="sl sl-icon-doc"></i> Basic Informations</h3>
                </div>

                <!-- category -->
                <!-- State -->
                <div class="row with-forms">
                    <div class="col-md-12">
                        <h5>Category</h5>
                        <select name="category"  class="chosen-select-no-single" >
                        <?php if(count($categories) > 0):
                                foreach($categories as $val): 
                                 if($val->cat_id == set_value('category')):?>
                                    <option value="<?php echo $val->cat_id; ?>" selected><?php echo ucfirst($val->cat_name); ?></option>
                                <?php
                                 else: ?>
                                    <option value="<?php echo $val->cat_id; ?>"><?php echo ucfirst($val->cat_name); ?></option>
                        <?php
                            endif;
                            endforeach; 
                              endif; ?>
                        </select>
                    </div> 
                </div> 

                <!-- Title -->
                <div class="row with-forms">
                    <div class="col-md-12">
                        <h5>Title</h5>
                        <input type="input" name="title" class="search-field" value="<?php echo set_value('title') ?>" >
                    </div>
                </div>  


            </div>
            <!-- Section / End -->


              <!-- Section -->
            <div class="add-listing-section margin-top-45">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-docs"></i> Details</h3>
                </div>

                <!-- Description -->
                <div class="form">
                    <div class="row with-forms">
                        <div class="col-md-12">
                            <h5>Description</h5>
                            <textarea class="WYSIWYG" name="description" cols="40" rows="3" id="summary" spellcheck="true"><?php echo set_value('description') ?></textarea>
                        </div>
                        <div class="col-md-4">
                            <h5 class="margin-top-30 margin-bottom-10">Number of Rooms </h5>
                            <input name="num_rooms" type="number" value="<?php echo set_value('num_rooms') ?>">
                        </div>
                        <div class="col-md-4">
                            <h5 class="margin-top-30 margin-bottom-10">Number of Bathroom </h5>
                            <input name="num_bath" type="number" value="<?php echo set_value('num_bath') ?>">
                        </div> 
                        <div class="col-md-4">
                            <h5 class="margin-top-30 margin-bottom-10">Parking</h5>
                            <select name="parking" class="chosen-select">
                                <option value="no parking">no parking</option>
                                <option value="on street">on street</option>
                                <option value="off street parking">off street parking</option>
                            </select>
                        </div>

                        <div class="col-md-6">
                            <h5 class="margin-top-30 margin-bottom-10">Date of Availability </h5>
                            <input name="date_avail" type="date" value="<?php echo set_value('date_avail') ?>">
                        </div>
                        <div class="col-md-6">
                            <h5 class="margin-top-30 margin-bottom-10">Number of occupancy </h5>
                            <input name="num_occu" type="number" value="<?php echo set_value('num_occu') ?>">
                        </div>                        
                        <!-- Address -->
                        <script type="text/javascript">
                            $.ajax({
                                url: base_url+"assets/scripts/provinces.json",
                                type: "GET",
                                dataType: "json",

                                success: function(data){
                                    for(var i=0;i<data.length; i++){
                                        if(data[i].country == "AU"){
                                        $('#state').append("<option value='"+data[i].short+","+data[i].name+"'>"+data[i].name+"("+data[i].short+")" + "</option>");
                                        }
                                                                            
                                    }
                                }
                            });
                        </script>
                        <div class="col-md-12">
                            <h5>Location</h5>
                            <div class="col-md-6">
                                <input name="address" type="text" value="<?php echo set_value('address') ?>" placeholder="e.g. 964 School Street">
                            </div>
                            <div class="col-md-4">
                                <select name="state" id="state">
                                    <option value="">State</option>
                                </select>
                            </div>
                        </div>
                       
                        <div class="col-md-4">
                            <h5 class="margin-top-30 margin-bottom-10">Minimum Stay</h5>
                            <input name="minimun_stay" type="number" value="<?php echo set_value('minimun_stay') ?>">
                        </div>
                        <div class="col-md-4">
                            <h5 style="margin-top:23px;"> &nbsp; </h5>
                            <select name="minimun_stay_by" class="chosen-select">
                                <option value="">Select</option>
                                <option value="night(s)">night(s)</option>
                                <option value="day(s)">day(s)</option>
                                <option value="week(s)">week(s)</option>
                                <option value="month(s)">month(s)</option>
                            </select>
                        </div> 
                    </div>
                </div>                       


            </div>
            <!-- Section / End -->
    
          
            <div class="margin-top-45">
                <button class="button preview" type="submit">NEXT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            <?php echo form_close(); ?>
            <!--  form  -->
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
        </div>
    </div>

    <!-- Copyrights -->
    <?php include 'inc/copyrights.php'; ?>

</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);

</script>