<!-- Titlebar -->
		<div id="titlebar">
			<div class="row">
				<div class="col-md-12">
					<h2>My Listings</h2>
					<!-- Breadcrumbs -->
					<nav id="breadcrumbs">
						<ul>
							<li><a href="<?php echo site_url();?>">Home</a></li>
							<li><a href="dashboard">Dashboard</a></li>
							<li>My Listings</li>
						</ul>
					</nav>
				</div>
			</div>
		</div>

		<!-- Headline -->
		<div class="row">
			<div class="col-md-12">
				<div id="notify" class="notify" align="center">
					<?php 
					
					if($this->session->flashdata('notify') != '' ){
						$notify = $this->session->flashdata('notify');
						if($notify['status'] == true){
							echo '<div class="notification success closeable">
								<p>'.$notify['msg'].'</p>
								<a class="close"></a>
							</div>';
						}else{
							echo '<div class="notification error closeable">
								<p><span>Error! </span>'.$notify['msg'].'</p>
								<a class="close"></a>
							</div>';
						}
					}
					?>
						
				</div>
			</div>
		</div>

		<div class="row">
			
			<!-- Listings -->
			<div class="col-lg-12 col-md-12">
				<div class="dashboard-list-box margin-top-0">
					<h4>My Wanted Listing</h4>
					
						<?php if( $getmywanted != '' && count($getmywanted)> 0): ?>
						<ul>
						<?php
								foreach($getmywanted as $val):?>

									<li>
										<div class="list-box-listing">
											<div class="list-box-listing-img"><a href="#">
												<?php
												if($val->media != ''):
													$media = unserialize($val->media); 

													if(array_key_exists('images', $media) && $media['images'] != ''):
														$image = $media['images'];
														?>
														<img src="<?php echo site_url('uploads/listing/'.$image[0]); ?>" alt="<?php echo $val->title_for ?>"></a>
													<?php
													else: ?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
												<?php
													endif;
												else:
												?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
												<?php 
												endif;
												?>
												
											</div>
											<div class="list-box-listing-content">
												<div class="inner">
													<h3><a href="#"><?php echo $val->title_for ?></a></h3>
													<span><?php echo $val->location ?></span>
													<!--div class="star-rating" data-rating="3.5">
														<div class="rating-counter">(12 reviews)</div>
													</div-->
												</div>
											</div>
										</div>
										<div class="buttons-to-right">
											<a href="<?php echo site_url('user/edit_listing/'.$val->id_list); ?>" class="button gray"><i class="sl sl-icon-note"></i> Edit</a>
											<a href="#" class="button gray"><i class="sl sl-icon-close"></i> Delete</a>
										</div>
									</li>
							<?php
								endforeach;
							?>
						
						</ul>

						<?php
						else:?>
							<div>
								<p class="center"><stong>No Data Found</stong></p>
							</div>
						<?php
						endif; 
						?>
						
				</div>
			</div>
			
			<!-- Listings -->
			<div class="col-lg-12 col-md-12 margin-top-45">
				<div class="dashboard-list-box margin-top-0">
					<h4>My Property Listings</h4>
						
						<?php 
						if($getmyproperty != '' && count($getmyproperty) > 0): ?>
						<ul>
						<?php
								foreach($getmyproperty as $val):	
									$loc = unserialize($val->location);
									$abbrev = $loc['state']['abbrev'];
									$name = $loc['state']['name'];
								?>
									<li>
										<div class="list-box-listing">
											<div class="list-box-listing-img"><a href="#">
												<?php
												
												if($val->media != ''):
													$media = unserialize($val->media);
														if(array_key_exists('images', $media) && $media['images'] != ''):
													 	 	$display = $media['images'];
												?>
													<img src="<?php echo site_url('uploads/listing/'.$display[0]); ?>" alt="<?php echo $val->title_for ?>"></a>
												<?php 	else: ?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
												<?php
														endif;
												else:
												?>
													<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt=""></a>
												<?php 
												endif;
												?>
												
											</div>
											<div class="list-box-listing-content">
												<div class="inner">
													<h3><a href="#"><?php echo $val->title_for ?></a></h3>
													<span><?php echo $loc['address'].", ".$name."(".$abbrev.")"; ?></span>
													<!--div class="star-rating" data-rating="3.5">
														<div class="rating-counter">(12 reviews)</div>
													</div-->
												</div>
											</div>
										</div>
										<div class="buttons-to-right">
											<a href="<?php echo site_url('user/edit_listing/'.$val->id_list); ?>" class="button gray"><i class="sl sl-icon-note"></i> Edit</a>
											<a href="#" class="button gray"><i class="sl sl-icon-close"></i> Delete</a>
										</div>
									</li>
						<?php
							endforeach;
						?>
						
						</ul>

						<?php
						else:?>
							<div>
								<p class="center"><stong>No Data Found</stong></p>
							</div>
						<?php
						endif; 
						?>
						
				</div>
			</div>
            
            <!-- Copyrights -->
            <?php include 'inc/copyrights.php'; ?>

        </div>