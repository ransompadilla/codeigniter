<?php 
//Titlebar
//================================================== ?>
<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2><?php echo $pagename ?></h2>

				<!-- Breadcrumbs -->
				<nav id="breadcrumbs">
					<ul>
						<li><a href="<?php echo site_url(); ?>">Home</a></li>
						<li><?php echo ($pagename) ?></li>
					</ul>
				</nav>

			</div>
		</div>
	</div>
</div>



<?php  
//Content
//================================================== ?>
<div class="container">

	<!-- Blockquote
	================================================== -->
	<div class="row">
		<div class="col-md-12">
		<!-- Headline -->
		<p>Coming soon...</p>
		</div>
	</div>
</div>
