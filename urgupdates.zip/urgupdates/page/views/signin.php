<?php 
//Titlebar
//================================================== ?>
<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2><?php echo $pagename ?></h2>

				<!-- Breadcrumbs -->
				<!-- <nav id="breadcrumbs">
					<ul>
						<li><a href="<?php echo site_url(); ?>">Home</a></li>
						<li><?php echo ($pagename) ?></li>
					</ul>
				</nav> -->

			</div>
		</div>
	</div>
</div>



<?php  
//Content
//================================================== ?>
<div class="container">

	<!-- Blockquote
	================================================== -->
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
		<!-- Headline -->
				
				<!--Tabs -->
				<div class="sign-in-form style-1">

					
					<div class="tabs-container alt">

						<!-- Login -->
						<div class="tab-content" id="tab1" style="display: none;">
							<div class="msg_signin"></div>
							<form method="post" action="<?php echo site_url('user/signin'); ?>" class="login">

								<p class="form-row form-row-wide">
									<label for="email">Email:
										<i class="im im-icon-Mail"></i>
										<input type="text" class="input-text" name="email"  value="<?php echo set_value('email'); ?>" />
										<?php echo form_error('email'); ?>
									</label>
								</p>

								<p class="form-row form-row-wide">
									<label for="password">Password:
										<i class="im im-icon-Lock-2"></i>
										<input class="input-text" type="password" name="password" />
										<?php echo form_error('password'); ?>
									</label>
									<span class="lost_password">
										<a href="#" >Lost Your Password?</a>
									</span>
								</p>

								<div class="form-row">
									<input type="submit" class="button border margin-top-5" name="login" value="Login" />
									<!-- <div class="checkboxes margin-top-10">
										<input type="checkbox" name="check">
										<label for="remember-me">Remember Me</label>
									</div> -->
								</div>
								
								
							</form>
						</div>
						
					</div>
					
				</div>
		</div>

		<div class="col-md-6" style="display:none">
			<div class="form-row form-row-wide text-center social_btn">
				<h4><strong>Login with</strong></h4>
				<a  class="social_css"><i class="im im-icon-Facebook"></i>Facebook</a>
				<a  class="social_css google_login"><i class="im im-icon-Google-Plus"></i>Google</a>
			</div>
		</div>

	</div>
</div>
