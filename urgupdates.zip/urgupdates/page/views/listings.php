<?php 
//Titlebar
//================================================== ?>
<div id="titlebar" class="gradient">
	<div class="container">
		<div class="row">
			<div class="col-md-12">

				<h2><?php echo $pagename; ?></h2>

				<?php echo ($listings ? "<h5>Result: ".count($listings)."</h5>" : "") ?>
				<!-- Breadcrumbs -->
				<nav id="breadcrumbs">
					<ul>
						<li><a href="<?php echo site_url(); ?>">Home</a></li>
						<li><?php echo ($pagename)?></li>
					</ul>
				</nav>

			</div>
		</div>
	</div>
</div>


<?php  
//Content
//================================================== ?>

<div class="container">
	<div class="row">

		<div class="col-lg-9 col-md-8 padding-right-30">

			<!-- Sorting / Layout Switcher -->
			<div class="row margin-bottom-25">

				<!--
				<div class="col-md-6 col-xs-6">
				</div>

				<div class="col-md-6 col-xs-6">
					 Sort by >
					<div class="sort-by">
						<div class="sort-by-select">
							<select data-placeholder="Default order" class="chosen-select-no-single">
								<option>Default Order</option>	
								<option>Highest Rated</option>
								<option>Most Reviewed</option>
								<option>Newest Listings</option>
								<option>Oldest Listings</option>
							</select>
						</div>
					</div>
				</div-->
			</div>
			<!-- Sorting / Layout Switcher / End -->


			<div class="row">

				<?php 
				if($listings){
					foreach($listings as $val){
					$loc = unserialize($val->location);
					$abbrev = $loc['state']['abbrev'];
					$name = $loc['state']['name'];

				?>
					<!-- Listing Item -->
					<div class="col-lg-6 col-md-12">
						<a href="<?php echo site_url('listing/'.$val->id_list);?>" class="listing-item-container">
							<div class="listing-item">
									<?php 
									$media = unserialize($val->media);
									if(array_key_exists('images',$media) && $media['images'] != ''):
									?>
										<img src="<?php echo site_url('uploads/listing/'.$media['images'][0]); ?>" alt="<?php echo $val->title_for ?>">
									<?php
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php 
									endif;
									?>
																
								<div class="listing-item-content">
									<span class="tag"><?php echo $val->cat_name; ?></span>
									<h3><?php echo $val->title_for ?><i class="verified-icon"></i></h3>
									<span><?php echo $loc['address'];?></span><br>
									<span><?php echo $name."(".$abbrev.")";?></span>
								</div>
								<span class="like-icon"></span>
							</div>
							<div class="star-rating" data-rating="3.5">
								<div class="rating-counter">(12 reviews)</div>
							</div>
						</a>
					</div>
					<!-- Listing Item / End -->
				<?php }
				}else{?>
					<div class="col-lg-6 col-md-12"><h3>No Data Found.</h3></div>
				<?php } ?>
			</div>
			<hr>
			

		</div>


		<!-- Sidebar
		================================================== -->
		<?php include 'inc/sidebar.php'; ?>
		<!-- Sidebar / End -->

	</div>
</div>
<?php if($related): ?>
<div class="container-fluid">
	
			<h3>Related Search Result: </h3>
			<div class="row">

				<?php 
				if($related){
					foreach($related as $val){
					$loc = unserialize($val->location);
					$abbrev = $loc['state']['abbrev'];
					$name = $loc['state']['name'];

				?>
					<!-- Listing Item -->
					<div class="col-sm-3">
						<a href="<?php echo site_url('listing/'.$val->id_list);?>" class="listing-item-container">
							<div class="listing-item" style="height: 210px;">
									<?php 
									$media = unserialize($val->media);
									if(array_key_exists('images',$media) && $media['images'] != ''):
									?>
										<img src="<?php echo site_url('uploads/listing/'.$media['images'][0]); ?>" alt="<?php echo $val->title_for ?>">
									<?php
									else:
									?>
										<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
									<?php 
									endif;
									?>
																
								<div class="listing-item-content">
									<span class="tag"><?php echo $val->cat_name; ?></span>
									<h3><?php echo $val->title_for ?><i class="verified-icon"></i></h3>
									<span><?php echo $loc['address'].", ".$abbrev;?></span>
								</div>
								<span class="like-icon"></span>
							</div>
							<div class="star-rating" data-rating="3.5">
								<div class="rating-counter">(12 reviews)</div>
							</div>
						</a>
					</div>
					<!-- Listing Item / End -->
				<?php }
				}else{?>
					<div class="col-lg-6 col-md-12"><h3>No Data Found.</h3></div>
				<?php } ?>
			</div>
</div>
<?php endif; ?>