<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Home extends MY_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model('post/post_model', 'post_model');
		$this->load->model('user/user_model', 'user_model');
	}
	function index(){
		if($this->session->has_userdata('logged_in')){
			$_SESSION['home'] = "home";
			$this->load->view('home/view_home');
			$data['user_info'] = $this->user_model->getUserInfoByID($_SESSION['user_id']);
			$data['write_post_view'] = 'Post/write_post_view';
			$data['content_view'] = 'Post/post_view';
			$data['post_view'] = $this->post_model->getPost($_SESSION['user_id']);
			$this->template->homepage($data);
		}
		else{
			redirect(base_url('user'));
		}
		
	}
	
}
?>