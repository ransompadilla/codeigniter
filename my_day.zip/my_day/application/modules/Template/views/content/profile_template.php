<?php $this->load->view('header/header') ?>
  <!-- content -->
  <div class="container-fluid">
  <div class="row">
    <div class="col-md-4"> 
     <?php $this->load->view($my_profile);?>
    </div>
    <div class="col-md-8">
      <p>
        <?php $this->load->view($write_post_view);?>
        <?php $this->load->view($content_view);?>
      </p>
   </div>
 </div>
 </div>
 <?php $this->load->view('footer/footer') ?>