<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Template extends MY_Controller
{
	function __construct(){
		parent::__construct();
	}
	function login($data = Null){
		$this->load->view('content/login_template', $data);
	}
	function register($data = Null){
		$this->load->view('content/login_template', $data);
	}
	function homepage($data = Null){
		$this->load->view('content/homepage_template', $data);
	}
	function my_profile($data = Null){
		$this->load->view('content/profile_template', $data);
	}
}
?>