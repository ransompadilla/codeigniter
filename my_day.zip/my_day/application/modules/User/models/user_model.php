
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class User_Model extends CI_Model {
	function __construct() {
        parent::__construct();
    }
	public function register($data){
		$this->db->insert('user', $data);
		if($this->db->affected_rows() > 0 ){
			return true;
		}
		else {return false;}
	}
	public function validate_login($data){
		$query = $this->db->get_where('user', array('user_email'=>$data['email'], 'user_password'=>$data['password']));
		if($query->num_rows() > 0){
			return $query->row();
		}
		else {return false;}
	}
	public function getUserInfo($email){
		$query = $this->db->get_where('user', array('user_email'=>$email));
		if($query->num_rows() > 0){
			return $query->row();
		}
		else {return false;}
	}
	public function getUserInfoByID($id){
		$query = $this->db->get_where('user', array('user_id'=>$id));
		if($query->num_rows() > 0){
			return $query->row();
		}
		else {return false;}
	}
}