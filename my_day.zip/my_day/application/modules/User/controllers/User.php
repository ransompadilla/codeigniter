<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class User extends MY_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model('user_model');
	}
	function index(){
		$data['content_view'] = 'User/login_view';
		$this->template->login($data);
	}
	function register(){
		$data['content_view'] = 'User/register_view';
		$this->template->register($data);
	}
	function user_register(){
		$field = array(
			'user_fname'=>$this->input->post('fname'),
			'user_lname'=>$this->input->post('lname'),
			'user_address'=>$this->input->post('address'),
			'user_gender'=>$this->input->post('gender'),
			'user_bdate'=>$this->input->post('bdate'),
			'user_email'=>$this->input->post('email'),
			'user_password'=>$this->input->post('pword')
		);
		$result = $this->user_model->register($field);
		if($result){
			$this->session->set_flashdata('success_msg','You have successfully registered!');
		}
		else{

			$this->session->set_flashdata('error_msg','You have failed to register!');
		}
		redirect(base_url('user/register'));
	}
	
	function validate_login(){
		$field = array(
			'email'=>$this->input->post('email'),
			'password'=>$this->input->post('pword')
		);
		$result = $this->user_model->validate_login($field);
		if($result){
			$info = $this->user_model->getUserInfo($field['email']);

			$session_data = array(
			        'user_id'=>$info->user_id,
			        'logged_in'=>TRUE
			);

			$this->session->set_userdata($session_data);
			
			redirect(base_url('home'));
		}
		else{
			$this->session->set_flashdata('error_msg', 'Invalid Username or Password !');
			redirect(base_url('user'));
		}
	}
	function logout(){
		$array_items = array('user_id', 'logged_in');
		$this->session->unset_userdata($array_items);
		$this->session->sess_destroy();
		redirect(base_url('user'));
	}
}
?>