
<?php
	if($this->session->flashdata('success_msg')){
		echo '<div class="alert alert-success">'.$this->session->flashdata('success_msg').'</div>';
	}
?>
<div class="card card-register mx-auto mt-5">
      <div class="card-header">Register an Account</div>
      <div class="card-body">
        <form method="post" action="<?php echo base_url('user/user_register') ?>">
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputName">First name</label>
                <input class="form-control" name="fname" type="text" aria-describedby="nameHelp" placeholder="Enter first name" required>
              </div>
              <div class="col-md-6">
                <label for="exampleInputLastName">Last name</label>
                <input class="form-control" name="lname"  type="text" aria-describedby="nameHelp" placeholder="Enter last name" required>
              </div>
            </div>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Address</label>
            <input class="form-control" name="address" type="text" aria-describedby="emailHelp" placeholder="Enter address" required>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Gender</label>
            <select class="form-control" name="gender" required>
            	<option value="">Choose Gender</option>
            	<option value="M">Male</option>
            	<option value="F">Female</option>
            </select>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Birth-Date</label>
            <input class="form-control" name="bdate" type="date" aria-describedby="emailHelp" required>
          </div>
          <div class="form-group">
            <label for="exampleInputEmail1">Email address</label>
            <input class="form-control" type="email" name="email" aria-describedby="emailHelp" placeholder="Enter email" required>
          </div>
          <div class="form-group">
            <div class="form-row">
              <div class="col-md-6">
                <label for="exampleInputPassword1">Password</label>
                <input class="form-control" name="pword" type="password" placeholder="Password" required>
              </div>
              <div class="col-md-6">
                <label for="exampleConfirmPassword">Confirm password</label>
                <input class="form-control" name="pword2" type="password" placeholder="Confirm password" required>
              </div>
            </div>
          </div>
          <button type="submit" class="btn btn-primary btn-block">Register</button> 
        </form>
        <div class="text-center">
          <a class="d-block small mt-3" href="<?php echo base_url('user') ?>">Login Page</a>
          <a class="d-block small" href="forgot-password.html">Forgot Password?</a>
        </div>
      </div>
    </div>