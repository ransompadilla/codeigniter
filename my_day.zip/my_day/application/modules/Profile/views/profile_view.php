
  		 <div class="card mb-3">
          <form method="post" action="<?php echo base_url('profile/editme')?>" enctype="multipart/form-data">
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id'] ?>">
            <a href="#">
                <label id="upload-img">
                  <img id="img-upload" class="card-img-top img-fluid" src="<?php if($user_info->user_img){ echo base_url($user_info->user_img);} else{echo base_url('img/default/user-img.png');} ?>" alt="">
                  <input type="file" name="fileToUpload" id="imgInp" >
                </label>
            </a>
            <input type="submit" name="btnSubmit" class="btn-img btn btn-primary" value="Update">
          </form>
  		 	      
              <div class="card-body">
              	<h3 class="card-title mb-1"><a href="#"><?php echo $user_info->user_fname.' '.$user_info->user_fname ?></a></h3>
                
              </div>
              <!-- LINE GENDER -->
              <hr class="my-0">
              <div class="card-body py-2 small">
                <div id="line_gender">
                  <i class="fa fa-user"></i> Gender: <a class="mr-3 d-inline-block"  href="#"><?php if($user_info->user_gender == "F"){echo "Female";}else{echo "Male";}?></a>
                <a id="edit_gender" class="fa fa-pencil float-right" data-toggle="tooltip" title="Edit" data-placement="right" ></a>
                </div>
                
                <div id="edit_gender_div">
                <form method="post" action="<?php echo base_url('profile/editme')?>">
                    <div class="row">
                    <div class="col-sm-11">
                      <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id'] ?>">
                      <input  type="submit" name="edit_gender" class="form-control" <?php if($user_info->user_gender == "F"){echo "value= 'Male'";}else{echo "value='Female'";}?> >
                    </div>
                    <div class="col-sm-1">
                      <a id="cancel_edit_gender_div" class="fa fa-remove float-right" data-toggle="tooltip" title="Cancel" data-placement="right" ></a>
                    </div>
                  </div>
                </form>
                </div>
              </div>
              <!-- LINE ADDRESS -->
              <hr class="my-0">
               <div class="card-body py-2 small">
                <div id="line_address">
                  <i class="fa fa-globe"></i> Address: <a class="mr-3 d-inline-block"  href="#"><?php echo $user_info->user_address ?></a>
                <a id="edit_address"  class="fa fa-pencil float-right" data-toggle="tooltip" data-placement="right" title="Edit"></a>
                </div>
                
                <div id="edit_address_div">
                <form method="post" action="<?php echo base_url('profile/editme')?>" onchange="">
                    <div class="row">
                    <div class="col-sm-11">
                      <input type="hidden" name="user_id" value="<?php echo $user_info->user_id ?>">
                      <input  type="text" name="edit_address" class="form-control" placeholder="Your new address" required>
                    </div>
                    <div class="col-sm-1">
                      <a id="cancel_edit_address_div" class="fa fa-remove float-right" data-toggle="tooltip" title="Cancel" data-placement="right" ></a>
                    </div>
                  </div>
                </form>
                </div>
              </div>
              <!-- LINE BDATE -->
              <hr class="my-0">
               <div class="card-body py-2 small">
                <div id="line_bdate">
                  <i class="fa fa-calendar"></i> B-Date: 
                  <a class="mr-3 d-inline-block"  href="#">
                    <?php 
                      $d = strtotime($user_info->user_bdate);
                      $date = date('F j, Y', $d);
                      echo $date;
                    ?>
                    
                  </a>
                  <a id="edit_bdate" class="fa fa-pencil float-right" data-toggle="tooltip" data-placement="right" title="Edit"></a>
                </div>
                <div id="edit_bdate_div">
                <form method="post" action="<?php echo base_url('profile/editme')?>" onchange="">
                    <div class="row">
                    <div class="col-sm-11">
                      <input type="hidden" name="user_id" value="<?php echo $user_info->user_id ?>">
                      <div class="btn btn-group">
                        <input  type="date" name="edit_bdate" class="form-control" required>
                      <button type="submit" class="fa fa-calendar"></button></div>
                    </div>
                    <div class="col-sm-1">
                      <a id="cancel_edit_bdate_div" class="fa fa-remove float-right" data-toggle="tooltip" title="Cancel" data-placement="right" ></a>
                    </div>
                  </div>
                </form>
                </div>
              </div>
              <!-- LINE EMAIL -->
              <hr class="my-0">
               <div class="card-body py-2 small">
                <div id="line_email">
                  <i class="fa fa-envelope"></i> Email: <a class="mr-3 d-inline-block"  href="#"><?php echo $user_info->user_email ?></a>
                  <a id="edit_email" class="fa fa-pencil float-right" data-toggle="tooltip" data-placement="right" title="Edit"></a>
                </div>
                
                <div id="edit_email_div">
                <form method="post" action="<?php echo base_url('profile/editme')?>" onchange="">
                    <div class="row">
                    <div class="col-sm-11">
                      <input type="hidden" name="user_id" value="<?php echo $user_info->user_id ?>">
                      <input  type="email" name="edit_email" class="form-control" placeholder="Your new Email" required>
                    </div>
                    <div class="col-sm-1">
                      <a id="cancel_edit_email_div" class="fa fa-remove float-right" data-toggle="tooltip" title="Cancel" data-placement="right" ></a>
                    </div>
                  </div>
                </form>
                </div>
              </div>
              <div>
              </div>
            </div>
           
