<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Profile extends MY_Controller
{
	function __construct(){
		parent::__construct();
		$this->load->model('user/user_model', 'user_model');
		$this->load->model('post/post_model', 'post_model');
		$this->load->model('profile_model');
	}
	function index(){
		if($this->session->has_userdata('logged_in')){
			$_SESSION['profile'] = "profile";
			$data['user_info'] = $this->user_model->getUserInfoByID($_SESSION['user_id']);
			$data['write_post_view'] = 'Post/write_post_view';
			$data['content_view'] = 'Post/post_view';
			$data['post_view'] = $this->post_model->getMyPost($_SESSION['user_id']);
			$data['my_profile'] = "profile/profile_view";
			$this->template->my_profile($data);
		}
		else{
			redirect(base_url('user'));
		}
	}
	function editme(){
		if($this->input->post('edit_gender')){
			$gen=Null;
			$id = $this->input->post('user_id');
			if($this->input->post('edit_gender') == "Male"){
				$gen = "M";
			}
			else{
				$gen = "F";
			}
			$gender = array(
				'user_gender'=>$gen
			);
			$this->profile_model->edit_gender($gender, $id);
			
		}
		if($this->input->post('edit_address')){
			$id = $this->input->post('user_id');
			$address = array(
				'user_address'=>$this->input->post('edit_address')
			);
			$this->profile_model->edit_address($address, $id);
		}
		if($this->input->post('edit_bdate')){
			$id = $this->input->post('user_id');
			$bdate = array(
				'user_bdate'=>$this->input->post('edit_bdate')
			);
			$this->profile_model->edit_bdate($bdate, $id);
		}
		if($this->input->post('edit_email')){
			$id = $this->input->post('user_id');
			$email = array(
				'user_email'=>$this->input->post('edit_email')
			);
			$this->profile_model->edit_email($email, $id);
		}

		if($this->input->post('btnSubmit')){

			$id = $this->input->post('user_id');

			$target_dir = "uploads/";
			$target_file = $target_dir . basename($_FILES["fileToUpload"]["name"]);
			$uploadOk = 1;
			$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
			// Check if image file is a actual image or fake image
			if(isset($_POST["btnSubmit"])) {
			    $check = getimagesize($_FILES["fileToUpload"]["tmp_name"]);
			    if($check !== false) {
			        echo "File is an image - " . $check["mime"] . ".";
			        $uploadOk = 1;
			    } else {
			        echo "File is not an image.";
			        $uploadOk = 0;
			    }
			}
			// Check if file already exists
			if (file_exists($target_file)) {
			    echo "Sorry, file already exists.";
			    $uploadOk = 0;
			}
			// Check file size
			if ($_FILES["fileToUpload"]["size"] > 50000000) {
			    echo "Sorry, your file is too large.";
			    $uploadOk = 0;
			}
			// Allow certain file formats
			if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
			&& $imageFileType != "gif" ) {
			    echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
			    $uploadOk = 0;
			}
			// Check if $uploadOk is set to 0 by an error
			if ($uploadOk == 0) {
			    echo "Sorry, your file was not uploaded.";
			// if everything is ok, try to upload file
			} else {
			    if (move_uploaded_file($_FILES["fileToUpload"]["tmp_name"], $target_file)) {
			        echo "The file ". basename( $_FILES["fileToUpload"]["name"]). " has been uploaded.";
			    } else {
			        echo "Sorry, there was an error uploading your file.";
			    }
			}
			
			$img = array(
				'user_img'=>$target_file
			);
			$this->profile_model->edit_img($img, $id);
		}
		redirect(base_url('profile'));
	}
}
?>