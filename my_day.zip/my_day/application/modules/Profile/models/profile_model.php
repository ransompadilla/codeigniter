<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profile_Model extends CI_Model {
	function __construct() {
        parent::__construct();
    }
	public function edit_gender($data, $id){
		$this->db->where('user_id', $id);
		$this->db->update('user', $data);
		if($this->db->affected_rows() > 0 ){
			return true;
		}
		else {return false;}
	}
	public function edit_address($data, $id){
		$this->db->where('user_id', $id);
		$this->db->update('user', $data);
		if($this->db->affected_rows() > 0 ){
			return true;
		}
		else {return false;}
	}
	public function edit_bdate($data, $id){
		$this->db->where('user_id', $id);
		$this->db->update('user', $data);
		if($this->db->affected_rows() > 0 ){
			return true;
		}
		else {return false;}
	}
	public function edit_email($data, $id){
		$this->db->where('user_id', $id);
		$this->db->update('user', $data);
		if($this->db->affected_rows() > 0 ){
			return true;
		}
		else {return false;}
	}
	public function edit_img($data, $id){
		$this->db->where('user_id', $id);
		$this->db->update('user', $data);
		if($this->db->affected_rows() > 0 ){
			return true;
		}
		else {return false;}
	}
}
?>