<div class="card mb-3">
  <form method="post" action="<?php echo base_url('post/post_myday') ?>" enctype="multipart/form-data">
  <div class="card-header">
    <i class="fa fa-bar-chart"></i> Make your day the best!</div>
      <div class="card-body">
        <div class="row">
          <div class="col-sm-12 my-auto">
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['user_id'];?>">
          	<textarea name="post_caption" class="form-control" placeholder="Write your caption..." required></textarea>
          </div>
          
        </div>
     </div>
    <div class="card-footer small text-muted">
  	 <label id="upload-label"> Upload
    	<input type="file" name="post_img" id="imgInp" >
    </label> | 
    <button type="submit" name="submit" class="btnPost btn btn-primary">Post</button> | 
    <img id="img-upload" src="">
	</div>
  </form>
</div>	