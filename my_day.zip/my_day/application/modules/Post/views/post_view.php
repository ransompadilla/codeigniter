
      <?php
        if($post_view){
          foreach ($post_view as $post) {
            $d = strtotime($post->post_date);
            $date = date('F j @ h:i A', $d);
            echo '<div class="card mb-3">
              <div class="card-body">
                <h6 class="card-title mb-1"><a href="#"><img src="'.base_url($post->user_img).'" style="width:50px;height:50px;">&nbsp; '.$post->user_fname.' '.$post->user_lname.'</a></h6>
                <p class="card-text small">'.$post->post_caption.'
                  <a href="#">#kickflip</a>
                  <a href="#">#holdmybeer</a>
                  <a href="#">#igotthis</a>
                </p>
                <a href="#">
                <img class="card-img-top img-fluid w-100" src="'.base_url($post->post_img).'" alt="">
              </a>
                
              </div>
              <hr class="my-0">
              <div class="card-body py-2 small">
                <a class="mr-3 d-inline-block" href="#">
                  <i class="fa fa-fw fa-thumbs-up"></i>Like</a>
                <a class="mr-3 d-inline-block" href="#">
                  <i class="fa fa-fw fa-comment"></i>Comment</a>
                <a class="d-inline-block" href="#">
                  <i class="fa fa-fw fa-share"></i>Share</a>
              </div>
              <div class="card-footer small text-muted">Posted: '.$date.'</div>
            </div>';
          }
        }
      ?>
       

