<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_Model extends CI_Model {
	function __construct() {
        parent::__construct();
    }
	public function post_myday($data){
		$this->db->insert('post', $data);
		if($this->db->affected_rows() > 0 ){
			return true;
		}
		else {return false;}
	}
	public function getPost(){
		$this->db->select('*');
	    $this->db->from('user u'); 
	    $this->db->join('post p', 'p.user_id=u.user_id', 'inner');
		$this->db->order_by('p.post_date', 'desc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}
		else {return false;}
	}
	public function getMyPost($id){
		$this->db->select('*');
	    $this->db->from('user u'); 
	    $this->db->join('post p', 'p.user_id=u.user_id', 'inner');
	    $this->db->where('p.user_id', $id);
		$this->db->order_by('p.post_date', 'desc');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}
		else {return false;}
	}
}