<head>
<!-- Basic Page Needs
================================================== -->

<title>Aussie Flatmates</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<script>var base_url = '<?php echo base_url() ?>';</script>
<!-- CSS
================================================== -->
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/style.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/colors/main.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/custom.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/chat.css">
<link rel="stylesheet" href="<?php echo base_url();?>assets/css/dropzone.min.css">
<!-- <link rel="stylesheet" href="<?php echo base_url();?>assets/bootstrap/css/bootstrap.min.css"> -->

 <script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-2.2.0.min.js"></script>


</head>

<div id="myModal" class="modal">

  <!-- Modal content -->
  <div class="modal-content">
    <span class="popclose">&times;</span>
    <div class="popcontent"></div>
  </div>

</div>