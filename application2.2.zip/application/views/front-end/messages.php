<!DOCTYPE html>
<?php
    echo $head;
?>
<html>
    <body>
        <!-- loader -->
        <div id="loading" style="display:none">
            <img id="loading-image" src="<?php echo site_url('assets/images/spinner.gif') ?>" alt="Loading..." />
        </div>
            
        <div id="wrapper">
            <header id="header-container" style="height: 50px;">
                <!-- Header -->
                <div id="header">
                    <div class="container">
                        
                        <!-- Left Side Content -->
                        <div class="left-side">
                            
                            <!-- Logo -->
                            <div id="logo">
                                <a href="<?php echo base_url('/'); ?>"><img src="<?php echo site_url('assets/images/aussie.png') ?>" alt=""></a>
                            </div>

                            
                            <div class="clearfix"></div>
                            <!-- Main Navigation / End -->
                            
                        </div>
                        <!-- Left Side Content / End -->


                        <!-- Right Side Content / End -->
                        <div class="right-side">
                            <div class="header-widget">
                                <?php if($this->session->userdata('is_logged') == null && $this->session->userdata('is_logged') == false){ ?>
                                    <a href="<?php echo site_url('signin'); ?>" class="sign-in">Login</a>
                                    <a href="<?php echo site_url('signup'); ?>" class="sign-in">Register</a>
                                    <!--a href="<?php echo site_url('dashboard'); ?>" class="button border with-icon">Add Listing <i class="sl sl-icon-plus"></i></a-->
                                <?php }else{ ?>
                                    <a href="<?php echo site_url('user/dashboard'); ?>" class="sign-in"><i class="sl sl-icon-user"></i> <?php echo ucfirst($this->session->userdata('user_info')->first_name).' '.ucfirst(substr($this->session->userdata('user_info')->last_name, 0,1)).'.'; ?></a>
                                <?php } ?>



                                
                            </div>
                        </div>
                        <!-- Right Side Content / End -->



                    </div>
                </div>
                <!-- Header / End -->

            </header>
            <?php 
           	 echo $body; 
            ?>            
        
        </div> 
<script type="text/javascript" src="<?php echo base_url();?>assets/bootstrap/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/mmenu.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chosen.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/slick.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/rangeslider.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/magnific-popup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/waypoints.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/counterup.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery-ui.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/jquery.slimscroll.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/tooltips.min.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/custom.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chatjs.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/au-state.js"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/statejson.json"></script>
<script type="text/javascript" src="<?php echo base_url();?>assets/js/myscript.js"></script>       
    </body>
</html>
