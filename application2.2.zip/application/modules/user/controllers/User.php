<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class User extends MY_Controller{
	public function __construct(){
		parent::__construct();
		$this->load->model('UserModel');
		//$this->load->model('ListingModel');
		
	}

	public function index(){
		redirect('user/dashboard');
	}

	public function mailtest(){
		$token =  $this->generateRandomString(12);
		$this->sendVerification(20,'brianwebblogger@gmail.com',$token);

	}

	protected function userAuth(){
		if($this->session->userdata('is_logged') != true){
			redirect();
		}
		return $this->session->userdata('user_info');
	}
	protected function getUserInfo($id){
		return $this->UserModel->getUserInfo($id);
	}
	protected function sendVerification($id, $email, $token){
		$dcomp = 'Aussie Flatmates';
		$formname = 'Verification';
		$message = '<div align="left" style="width:700px; height:auto; font-size:12px; color:#333333; letter-spacing:1px; line-height:20px;">
			<div style="border:8px double #c3c3d0; padding:12px;"><div align="center" style="font-size:22px; font-family:Times New Roman, Times, serif; color:#051d38;">'.$dcomp.'</div>
			<div align="center" style="color:#990000; font-style:italic; font-size:13px; font-family:Arial;">('.$formname.')</div><p>&nbsp;</p>
			';

		$message .='<p>Welcome to Aussie Flatmates! Your account has been registered under your "'.$email.'" is now ready to go. All you need to do is to confirm your email address with us.<br/>
		Please, click on below link to confirm your registration at aussieflatmates.com.au</p>';

		$message .='<p><a href="'.base_url().'user/authentication/id/'.$id.'/verification/'.$token.'">Activate Now</a></p>';

		$message .='</div>
					</div>';
		$subject = 'Email Verification';

		$sendna = $this->mailthis($email, $subject, $message);

		if($sendna === true){

			$response['status'] = true;
			$response['msg'] = "<div style='text-center'>Registration Successful. <br />Your account has been created and an activation link has been sent to the email address you entered. Note that you must activate the account by clicking the activation link when you get the email before you can login.
			<br/>If you don't see this email in your inbox within 15 minutes, look for it in your junk mail folder. If you find it there, please mark the email as \"Not Junk\".<br /> Thank you...</div>";
			echo json_encode($response);

		}else{
			$response['status'] = false;
			$response['msg'] = $sendna;
			echo json_encode($response);

		}
	}


	public function signup(){
		$response = array();
		// set validation rules
		$this->form_validation->set_rules('first_name', 'First name', 'trim|required|max_length[35]');
		$this->form_validation->set_rules('last_name', 'Last name', 'trim|required|max_length[35]');
		$this->form_validation->set_rules('age', 'Age', 'trim|required|integer|max_length[3]');
		$this->form_validation->set_rules('gender', 'Gender', 'trim|required|in_list[male,female,other]');
		$this->form_validation->set_rules('status', 'Status', 'trim|required');
		$this->form_validation->set_rules('email', 'Email', 'trim|required|valid_email');			
		$this->form_validation->set_rules('phone', 'Phone', 'trim|required|max_length[14]');			
		$this->form_validation->set_rules('password1', 'Password', 'trim|required|min_length[8]');
		$this->form_validation->set_rules('password2', 'Confirm Password', 'trim|matches[password1]');
		

		if($this->form_validation->run()){
			//set variables from the form
			$first_name = strtolower($this->input->post('first_name'));
			$last_name 	= strtolower($this->input->post('last_name'));
			$age 		= strtolower($this->input->post('age'));
			$gender 	= strtolower($this->input->post('gender'));
			$status 	= strtolower($this->input->post('status'));
			$email    	= $this->input->post('email');
			$phone    	= $this->input->post('phone');
			$password 	= sha1($this->input->post('password1'));
			$token 		= $this->generateRandomString(12);

			$accountData = array(
				'first_name' => $first_name,
				'last_name' => $last_name,
				'age' => $age,
				'status' => $status,
				'gender' => $gender,
				'email' => $email,
				'phone' => $phone,
				'password' => $password,
				'role' => 1,
				'account_status' => 1,
				'subscription_type' => 0,
				'token' => $token,
				'date_added' => $this->getCurrentDateTime()
			);

			$id_inserted = $this->UserModel->insert($accountData);
				$id_inserted = true;
			if($id_inserted !== false){
				//$where = array('id'=>$id_inserted);
				//$info = $this->UserModel->getRow($where);
				
				//$this->sendVerification($info->id, $info->email, $info->token);	
					$response['status'] = true;
					$response['msg'] = "To verify your account. Please check your email.";
					echo json_encode($response);
				exit;
			}			
			
		}else{
			$response['status'] = false;
           	$response['msg'] = validation_errors().'-';
			   echo json_encode($response);
			   exit;
		}
			
	}

	public function signin(){
		$response = array();
	
		// set validation rules
		$this->form_validation->set_rules('email', 'Email', 'trim|required');
		$this->form_validation->set_rules('password', 'Password', 'trim|required');			
		
		if($this->form_validation->run()){

			// set variables from the form
			$email = strtolower($this->input->post('email'));
			$password = sha1($this->input->post('password'));
            
			$checklogin = $this->UserModel->authCheck(array('email' => $email, 'password'=>$password,'account_status' => 1));
			
			if($checklogin['status'] == true){

				$this->session->set_userdata('user_info', $checklogin['data']);
				$this->session->set_userdata('is_logged', true);

				$response['status'] = true;
				$response['msg'] = "Successful";
				echo json_encode($response);
				exit;	
				
			}else{
				$response['status'] = false;
				$response['msg'] = "Account does not exist or not yet verified.";
				echo json_encode($response);
				exit;
			}
				
			
		}else{
			$response['success'] = false;
           	$response['msg'] = validation_errors();
           	echo json_encode($response);
		}
			
	}

	public function authentication($id, $token ){
		$a_data = array(
			'pagename'		=> 'Email Verification',
			's_navcurrent'	=> ''
		);

		$urr = $this->uri->uri_to_assoc(3);
		$get['id']		= $urr['id'];
		$get['token']	= $urr['verification'];
		$get['account_status']	= 0;
		if(is_numeric($get['id']) && strlen($get['token']) === 12){
			$person_data = $this->UserModel->authCheck($get);

			if($person_data['status'] != false){
				if($person_data['data']->account_status == 0){
					$update['account_status'] = 1;

					$this->UserModel->update($update,$get);

					$this->session->set_userdata('user_info', $person_data['data']);
					$this->session->set_userdata('is_logged', true);

					$response['status'] = true;
					$response['msg'] = 'You have successfully registered with us!';
					$a_data['notify'] = $response;

				}else{
					$response['status'] = false;
					$response['msg'] = 'Verification link used already. Please use login details.';
					$a_data['notify'] = $response;
				}
				
			}else{
				$response['status'] = false;
				$response['msg'] = 'Invalid Link! Please contact the administrator.';
				$a_data['notify'] = $response;
			}
			
		}else{
			$response['status'] = false;
			$response['msg'] = 'Invalid Link! Please contact the administrator.';
			$a_data['notify'] = $response;
		}
		
		$this->pg_display('authentication',$a_data);
	}

	public function logout(){
		$this->session->set_userdata('user_info', '');
		$this->session->set_userdata('is_logged', false);
		$this->session->unset_userdata('user_info');
		$this->session->unset_userdata('is_logged');
		$this->session->sess_destroy();
		redirect('/', 'refresh');
	}
	public function getCountNotif(){
		$user_data = $this->userAuth();
		$p_user = $this->UserModel->getPaymentByUser($user_data->id);
		if($p_user){
			return $this->UserModel->count_notif($p_user->payment_id);
		}
		
	}
	public function manage_notification(){
		$rem_days="";$enddate="";$end="";$ckDate="";$ckStr="";
		$user_data = $this->userAuth();
		$paymentRecord = $this->UserModel->payment_record($user_data->id);
		date_default_timezone_set("Asia/Manila");
        $now = Date('F j, Y');
        $date_now = strtotime($now);
        if($paymentRecord){
        	foreach ($paymentRecord as $payment): 
				$check_date = $this->UserModel->checkDate($payment->payment_id);
				if($check_date){
					$ckStr = strtotime($check_date->notif_date);
					$ckDate .= Date('F j, Y', $ckStr);
				}
				
       			
              	
              if($payment->status == 1):
                $strDate = strtotime($payment->payment_date);
                $start_date = date('F j, Y', $strDate);
				  for($i=0;$i< $payment->days; $i++){
                    $end = $strDate + ($payment->days * 86400);
                    $enddate = date('F j, Y', $end);
                  }
                $rem_days = ($end - $date_now) / 86400;
                $use_days = $payment->days - intval($rem_days);
                $rem_days = intval($rem_days);
                if($rem_days <= 0){
                	$a_data = array(
				        'payment_id'=>$payment->payment_id,
				        'notif_message'=>'Your '.$payment->plan_category.' has been expired, please subscribe and try our other plan just click subscribe to get more information. Thanks!',
				        'notif_status'=>1
				        );
				    $result = $this->UserModel->insertNotification($a_data);
				    if($result == true){
				    	$this->UserModel->update_status_payment($payment->payment_id, array('status' => 0));
				    }
                	
                }

                if($now != $ckDate && $payment->status == 1){
                	if($payment->plan_id == 1){
                		if($rem_days < 4 && $rem_days > 2){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'Your '.$payment->plan_category.' is going out of date please subscribe again to extend your plan before it expired, Or you can upgrade your '.$payment->plan_category.' to Full Plan for 30 Days just click subscribe to see prices. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
				        if($rem_days == 1){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'You have '.$rem_days.' day more of your '.$payment->plan_category.', please subscribe again to extend your plan before it expired, Or you can upgrade your '.$payment->plan_category.' to Full Plan for 30 Days just click subscribe to see more information. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
                	}
                	
                	if($payment->plan_id == 2){
                		if($rem_days < 4 && $rem_days > 2){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'Your '.$payment->plan_category.' is going out of date please subscribe again to extend your plan before it expired. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
				        if($rem_days == 1){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'You have '.$rem_days.' day more of your '.$payment->plan_category.', please subscribe again to extend your plan before it expired. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
                	}
			        
                	if($payment->plan_id == 3){
                		if($rem_days < 4 && $rem_days > 2){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'Your '.$payment->plan_category.' is going out of date please subscribe and try our other plan just click subscribe to get more information. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
				        if($rem_days == 1){
				        	$a_data = array(
				        			'payment_id'=>$payment->payment_id,
				        			'notif_message'=>'You have '.$rem_days.' day more of your '.$payment->plan_category.', please subscribe and try our other plan just click subscribe to get more information. Thanks!',
				        			'notif_status'=>1
				        	);
				        	$this->UserModel->insertNotification($a_data);
				        }
                	}
                	return $rem_days.'-'.$payment->plan_category;
                }
              endif;
            endforeach;
        }
        
	}

	public function notification(){
		$user_data = $this->userAuth();

		$a_data = array(
			's_navcurrent'	=> 'notification',
			'pagename'		=> 'Notification'
		);
		$a_data['free'] 	= $this->generateRandomString(10)."Z3Z".$this->generateRandomString(10);
		$a_data['basic'] 	= $this->generateRandomString(10)."Z1Z".$this->generateRandomString(10);
		$a_data['full'] 	= $this->generateRandomString(10)."Z2Z".$this->generateRandomString(10);
		$a_data['p_status'] = $this->UserModel->getPaymentByUser($user_data->id);
		if($a_data['p_status']){
			$a_data['notification'] = $this->UserModel->notification($a_data['p_status']->payment_id);
			$a_data['nCount'] = $this->getCountNotif();
			$arr_data = array(
				'date_read'		=> $this->getCurrentDateTime(),
				'notif_status'	=> 0
				);
			$this->UserModel->update_status_notif($a_data['p_status']->payment_id, $arr_data);
		}
		else{
			$a_data['notification']="";
			$a_data['nCount'] = '';
		}
		
		$this->notif_display('notification',$a_data);
	}
	public function dashboard(){
		$user_data = $this->userAuth();

		$a_data = array(
			's_navcurrent'	=> 'dashboard',
			'pagename'		=> 'Dashboard'
		);
		$a_data['nCount'] = $this->getCountNotif();
		$this->dash_display('dashboard',$a_data);
	}
	public function payments(){
		$user_data = $this->userAuth();

		$a_data = array(
			's_navcurrent'	=> 'payment-records',
			'pagename'		=> 'Payment Records'
		);
		$a_data['nCount'] = $this->getCountNotif();
		$a_data['paymentRecord'] = $this->UserModel->payment_record($user_data->id);
		$a_data['totalPayment']	= $this->UserModel->totalOfPayment($user_data->id);
		$this->dash_display('payments',$a_data);
	}
	public function getPaymentRecords(){
		$user_data = $this->userAuth();
		return $a_data['paymentRecord'] = $this->UserModel->payment_record($user_data->id);
	}
	public function getPaymentByUser($id){
		return $this->UserModel->getPaymentByUser($id);
	}
	public function messages($data = ""){
		$unread = "";
		$user_data = $this->userAuth();
		
		$this->load->module('messages/messages');
		if($data != ""){
			$a_data['to'] = $this->UserModel->getUserInfo($data);
		}
		else{
			$a_data['to'] = "";
		}
		$a_data['messages_chat'] = $this->messages->getChatMessages($user_data->id);
		$a_data['nCount'] = $this->getCountNotif();
		$result = $this->UserModel->getPaymentByUser($user_data->id);
		if(!$result){
			$random = $this->generateRandomString(40)."zMsCz".$this->generateRandomString(30);
			redirect('page/pricing/'.$random);
		}

		$this->pg_messages('messages/messages', $a_data);
	}
	public function done_FreePlan(){
		$user_data = $this->userAuth();
		return $this->UserModel->getDoneFreePlan($user_data->id);
	}
	public function profile(){
		$user_data = $this->userAuth();
		$getwanted['id_user'] 	= $user_data->id;
		$getwanted['post_type']	= 'searcher';
		$this->load->module('listing/listing');	

		$a_data = array(
			's_navcurrent'	=> 'profile',
			'pagename'		=> 'Profile',
			'mywanted' 		=> $this->listing->getListing($getwanted) 
		);
		
		// $this->mybreadcrumb->add('Home', base_url());
		// $this->mybreadcrumb->add('Dashboard', base_url('dashboard'));
		// $this->mybreadcrumb->add('Add Listing', base_url('listing'));
		// $data['breadcrumbs'] = $this->mybreadcrumb->render();
		$a_data['nCount'] = $this->getCountNotif();
		$this->dash_display('profile',$a_data);
	}
	
	public function listings(){
		$user_data = $this->userAuth();

		$getwanted['id_user'] 	= $user_data->id;
		$getwanted['post_type']	= 'searcher';
		$this->load->module('listing/listing');	
		$a_data = array(
			's_navcurrent'	=> 'user-listing',
			'pagename'		=> 'Listing',
			'mywanted' 		=> $this->listing->getListing($getwanted) 
		);	

		
		if($user_data->role == 0){
			//exit;
			$a_data['listings'] = $this->listing->getListings();
		}else{
			$myid 			= $user_data->id;
			$getwanted 		= array("id_user" => $myid,'post_type'=>'searcher');
			$getproperty 	= array("id_user" => $myid,'post_type'=>'property');
			$a_data['getmywanted'] 	= $this->listing->getListings($getwanted); 	
			$a_data['getmyproperty'] 	= $this->listing->getListings($getproperty);


		}

		//$this->load->library('pagination');
		//$config['base_url'] = site_url('user/listings');
		//$config['total_rows'] = count($a_data['listings']);
		//$config['per_page'] =7;
		//$this->pagination->initialize($config);
		//$a_data['pagination'] = $this->pagination->create_links();
		$result = $this->UserModel->getPaymentByUser($user_data->id);
		if(!$result){
			$random = $this->generateRandomString(40)."zUsrLsTz".$this->generateRandomString(30);
			redirect('page/pricing/'.$random);
		}
		$a_data['nCount'] = $this->getCountNotif();
		$this->dash_display('user_listing',$a_data);
	}	

	public function add_listing(){
		$user_data = $this->userAuth();	
		
		$this->load->module('listing/listing');
		$a_data['s_navcurrent']	= 'add-listing';
		$a_data['pagename']		= 'Add Listing';

		if($_POST){
			$this->load->module('listing/listing');	
			$a_data['notify'] = $this->listing->validate_first_list('save'); 
		}
		$getwanted['id_user'] 	= $user_data->id;
		$getwanted['post_type']	= 'searcher';
		$a_data['mywanted'] = $this->listing->getListing($getwanted); 

		$this->load->module('category/category');	
		$a_data['categories'] = $this->category->getCategories(); 

		$this->load->module('options/options');	
		$a_data['options'] = $this->options->getOptions(); 
		$a_data['nCount'] = $this->getCountNotif();
		$this->dash_display('add_listing',$a_data);
	}
	
	//RANSOM FUNCTIONS
	public function add_listing_2(){
		$user_data = $this->userAuth();	
		
		$this->load->module('listing/listing');
		$a_data['s_navcurrent']	= 'add-listing-2';
		$a_data['pagename']		= 'Add Listing';

		if($_POST){
			$this->load->module('listing/listing');	
			$a_data['notify'] = $this->listing->save_list('save'); 
		}
		$getwanted['id_user'] 	= $user_data->id;
		$getwanted['post_type']	= 'searcher';
		$a_data['mywanted'] = $this->listing->getListing($getwanted); 

		$this->load->module('category/category');	
		$a_data['categories'] = $this->category->getCategories(); 

		$this->load->module('options/options');	
		$a_data['options'] = $this->options->getOptions(); 
		if(isset($_GET['sensor'])){
			$a_data['maps'] = $this->map_location($this->session->userdata('address'));
		}
		$a_data['nCount'] = $this->getCountNotif();
		$this->dash_display('add_listing2',$a_data);
	}
	
	public function map_location($loc){

		$this->load->library('googlemap_api');

		$config['center'] = $loc;
		$config['zoom'] = 15;
		$this->googlemap_api->initialize($config);

		$marker = array();
		$marker['position'] = $loc;
		$marker['draggable'] = true;
		//$marker['ondragend'] = 'alert(\'You just dropped me at: \' + event.latLng.lat() + \', \' + event.latLng.lng());';
		$marker['ondragend'] = 'document.getElementById("location").value = event.latLng.lat()+","+ event.latLng.lng()';
		$this->googlemap_api->add_marker($marker);
		
		return $this->googlemap_api->create_map();
	}
	//END RANSOM FUNCTIONS
	public function profile_post(){
		$user_data = $this->userAuth();
		$a_data = array(
			's_navcurrent'	=> 'profile-Post',
			'pagename'		=> 'Wanted Listing',
		);	

		$this->load->module('listing/listing');
		if($_POST){
			$this->load->module('listing/listing');	
			$a_data['notify'] = $this->listing->new_searcher(); 
		}
		$getwanted['id_user'] 	= $user_data->id;
		$getwanted['post_type']	= 'searcher';
		$a_data['mywanted'] = $this->listing->getListing($getwanted); 

		$this->load->module('options/options');	
		$a_data['options'] = $this->options->getOptions(); 

		$this->load->module('category/category');	
		$a_data['categories'] = $this->category->getCategories(); 

		$a_data['nCount'] = $this->getCountNotif();
		$this->dash_display('profile_post',$a_data);

	}

	public function edit_listing($id = 0){
		if(is_numeric($id) && $id != 0){
			$user_data = $this->userAuth();
			$getwanted['id_user'] 	= $user_data->id;
			$getwanted['post_type']	= 'searcher';
			$this->load->module('listing/listing');

			$a_data = array(
				's_navcurrent'	=> 'add-listing',
				'pagename'		=> 'Add Listing',
				'mywanted' 		=> $this->listing->getListing($getwanted) 
			);	
			
			if($_POST){
				$this->load->module('listing/listing');	
				$a_data['notify'] = $this->listing->update_list('update'); 
			}

			$id = array('id_list' => $id);
			$this->load->module('listing/listing');
			$a_data['listing'] = $this->listing->getlisting($id);
		
			$this->load->module('options/options');	
			$a_data['options'] = $this->options->getOptions(); 

			$this->load->module('category/category');	
			$a_data['categories'] 	= $this->category->getCategories(); 
			$a_data['list_id'] 		= $id['id_list'];
			$a_data['nCount'] = $this->getCountNotif();
			if($a_data['listing']->post_type == 'property'){
				$this->dash_display('edit_listing',$a_data);
			}elseif($a_data['listing']->post_type == 'searcher'){
				$this->dash_display('edit_profile_post',$a_data);
			}else{
				show_404();
			}
		}else{
			show_404();
		}
	}
	public function n_messages(){
		$a_data['users'] = $this->UserModel->getUsers();
		$this->load->view('chat/chat', $a_data);	
	}
	public function delete_listing($listing_id){
		$this->load->module('listing/listing');
		$this->listing->delete_listing($listing_id);
		redirect('user/listings');
	}
	public function add_user(){
		echo 'add-user';
	}

	public function active_users(){
		echo 'active-users';
	}

	public function inactive_users(){
		echo 'inactive-users';
	}

}
