<!-- Titlebar -->
        <div id="titlebar">
            <div class="row">
                <div class="col-md-12">
                    <h2><?php echo $pagename; ?></h2>
                    <!-- Breadcrumbs -->
                    <nav id="breadcrumbs">
                        <ul>
                            <li><a href="<?php echo site_url();?> ">Home</a></li>
                            <li><?php echo $pagename; ?></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>

        <!-- Notice -->
        <div class="row">
            <div class="col-md-12">
                <?php 
                if(isset($notify)){

                } ?>
            </div>
        </div>
        <div class="row">
            <!-- Payments -->
            <div class="col-lg-12">
                <div class="dashboard-list-box invoices with-icons margin-top-20">
                    <h4>
                    <?php if($totalPayment->payment != NULL): ?>
                        <span class="float-right"> Total: $<?php echo $totalPayment->payment;?></span>
                    <?php else:?>
                        <span></span>
                    <?php endif; ?>
                    </h4>
                  
                    <?php if($paymentRecord): ?>
                    <table class="table-responsive table table-stripped">
                    <th>Plan</th><th>Price</th><th>Amount</th><th>Payment Date</th><th>End Date</th><th>Use Days</th><th>Remaining Days</th><th>Status</th>
                        <?php 
                        $enddate="";$end="";$status="";
                        date_default_timezone_set("Asia/Manila");
                        $now = Date('F j, Y');
                        $date_now = strtotime($now);
                            foreach ($paymentRecord as $payment): 
                            $strDate = strtotime($payment->payment_date);
                            $start_date = date('F j, Y', $strDate);

                            //
                            for($i=0;$i< $payment->days; $i++){
                                $end = $strDate + ($payment->days * 86400);
                                $enddate = date('F j, Y', $end);
                            }
                            $rem_days = ($end - $date_now) / 86400;
                            $use_days = $payment->days - intval($rem_days);

                            if($payment->status == 1){
                                $status = "Active";
                            }
                            else{
                                $status = "UnActive";
                            }
                        ?>
                       
                            <tr>
                                <td><?php echo $payment->plan_category."(".$payment->days."D)"; ?></td>
                                <td><?php echo $payment->price.' '.$payment->currency_code; ?></td>
                                <td><?php echo $payment->payment_gross.' '.$payment->currency_code; ?></td>
                                <td><?php echo $start_date; ?></td>
                                <td><?php echo $enddate; ?></td>
                                <td><?php echo $use_days; ?></td>
                                <td><?php if(intval($rem_days > 0))echo intval($rem_days);else echo'0'; ?></td>
                                <td><?php echo $status;?></td>
                            </tr>

                        <?php  endforeach; ?>
                        
                       </table>
                    <?php else:?>
                        <h3 style="padding: 10px;">No Payment Records...</h3>
                    <?php endif;?>
                   
                </div>
            </div>

            <!-- Copyrights -->
            <?php include 'inc/copyrights.php'; ?>
            
        </div>
