<!-- Content
================================================== -->
<?php
	$loc = unserialize($listing->location);
	$abbrev = $loc['state']['abbrev'];
	$name = $loc['state']['name'];
?>
<div class="container">
	<div class="row sticky-wrapper">
		<div class="col-lg-8 col-md-8 padding-right-30">

			<!-- Titlebar -->
			<div id="titlebar" class="listing-titlebar">
				<div class="listing-titlebar-title">
					<h2><?php echo $listing->title_for;?></h2>
					<span>
						<a href="#listing-location" class="listing-address">
							<i class="fa fa-map-marker"></i>
							<?php echo $loc['address'].", ".$loc['city'].", ".$name."(".$abbrev.")";?>
						</a>
					</span>
					<div class="star-rating" data-rating="5" style="display:none">
						<div class="rating-counter"><a href="#listing-reviews">(31 reviews)</a></div>
					</div>
				</div>
			</div>

			<!-- Listing Nav -->
			<div id="listing-nav" class="listing-nav-container" style="display:none">
				<ul class="listing-nav">
					<li><a href="#listing-overview" class="active">Overview</a></li>
					<li><a href="#listing-pricing-list">Pricing</a></li>
					<li><a href="#listing-location">Location</a></li>
					<li><a href="#listing-reviews">Reviews</a></li>
					<li><a href="#add-review">Add Review</a></li>
				</ul>
			</div>
			
			<!-- Overview -->
			<div id="listing-overview" class="listing-section">
				<?php 
					$media = unserialize($listing->media);
					if(array_key_exists('images',$media) && $media['images'] != ''):
					?>
					<img src="<?php echo site_url('uploads/listing/'.$media['images'][0]); ?>" alt="<?php echo $listing->title_for ?>" >
				<?php else:?>
				<img src="<?php echo site_url('assets/images/listing-item-01.jpg') ?>" alt="">
				<?php endif;?>
				<?php echo $listing->about_describ;?>
				
				<!-- Amenities -->
				<h3 class="listing-desc-headline">Amenities</h3>
				<?php 
					$option = unserialize($listing->more_options); 
					$allowed = unserialize($listing->allowed); 
					$price = unserialize($listing->price); 
				?>
				<ul class="listing-features checkboxes margin-top-0">
					<!-- Price -->
					<?php
						for ($i=0; $i < count($price['included']) ; $i++): ?> 
							<li><?= $price['included'][$i];?></li>
					<?php
						endfor;
					?>
				</ul>

				<h3 class="listing-desc-headline">Allowed</h3>
				<ul class="listing-features checkboxes margin-top-0">
					<!-- Allowed -->
					<?php
						for ($i=0; $i < count($allowed) ; $i++): ?> 
							<li><?= $allowed[$i];?></li>
					<?php
						endfor;
					?>
				</ul>
				<h3 class="listing-desc-headline">More Options</h3>
				<ul class="listing-features checkboxes margin-top-0">
					
					<li>Parking: <?= $option['parking'];?></li>
					<li>NO. of Rooms: <?= $option['number_of_rooms'];?></li>
					<li>No. BathRooms: <?= $option['number_of_bathrooms'];?></li>
					<li>No. Occupancy: <?= $option['number_of_occupancy'];?></li>
				</ul>

				<h3 class="listing-desc-headline">Pricing</h3>
				<ul class="listing-features checkboxes margin-top-0">
					<!-- Price -->
					<li>Price: <?= $price['amount'];?> &nbsp;&nbsp;&nbsp;by: &nbsp;&nbsp;&nbsp;<?= ucfirst($price['price_by']);?></li>
				</ul>
			</div>

			

		
			<!-- Location -->
			<div id="listing-location" class="listing-section">
				<h3 class="listing-desc-headline margin-top-60 margin-bottom-30">Location</h3>

				<div id="singleListingMap-container">  
				<?php 
					//if(isset($_GET['sensor'])!=""){
						echo $maps['js'];
						echo $maps['html'];
					
				?>  

                   
				</div>
			</div>
				
		</div>


		<!-- Sidebar
		================================================== -->
		<?php include 'inc/sidebar.php'; ?>
		<!-- Sidebar / End -->

	</div>
</div>
