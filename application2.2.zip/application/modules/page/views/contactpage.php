<div class="clearfix"></div>

<div class="contact-map margin-bottom-60">

    <!-- Google Maps -->
    <div id="singleListingMap-container">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d788.4416102189679!2d144.97141753056874!3d-37.772074292920195!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad6434f676d9b81%3A0xb101244001bb6ec8!2s114%2F200+Lygon+St%2C+Brunswick+East+VIC+3057%2C+Australia!5e0!3m2!1sen!2sph!4v1525421109809" width="100%" height="420" frameborder="0" style="border:0" allowfullscreen></iframe>
    </div>
    <!-- Google Maps / End -->

    <!-- Office -->
    <?php 
    /*<div class="address-box-container">
        <div class="address-container" data-background-image="<?php echo site_url('assets/images/our-office.jpg'); ?>" style="background-image: url(&quot;<?php echo site_url('assets/images/our-office.jpg') ?>&quot;);">
            <div class="office-address">
                <h3>Our Office</h3>
                <ul>
                    <li>114/200 Lygon St.</li>
                    <li>Brunswick East Vic 3057,</li>
                    <li>Australia</li>
                </ul>
            </div>
        </div>
    </div>
    <!-- Office / End -->*/
    ?>

</div>

<div class="clearfix"></div>

<div class="container">

<div class="row">

    <!-- Contact Form -->
    <div class="col-md-12">

        <section id="contact">
            <h4 class="headline margin-bottom-35">Contact Form</h4>

            <div id="contact-message"></div> 

                <form method="post" action="contact.php" name="contactform" id="contactform" autocomplete="on">

                <div class="row">
                    <div class="col-md-12">
                        <div>
                            <label>Sent Message To</label>
                            <select>
                                <option>Select</option>
                                <option value="CONTACT BUSINESS">CONTACT BUSINESS</option>
                                <option value="ADVERTISING">ADVERTISING</option>
                                <option value="ADVERTISING">SUPPORT</option>
                                <option value="FEEDBACK DEPARTMENTS">FEEDBACK DEPARTMENTS</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row" style="padding-top:30px">
                    <div class="col-md-6">
                        <div>
                            <input name="name" type="text" id="name" placeholder="Your Name" required="required">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div>
                            <input name="email" type="email" id="email" placeholder="Email Address" pattern="^[A-Za-z0-9](([_\.\-]?[a-zA-Z0-9]+)*)@([A-Za-z0-9]+)(([\.\-]?[a-zA-Z0-9]+)*)\.([A-Za-z]{2,})$" required="required">
                        </div>
                    </div>
                </div>

                <div>
                    <input name="subject" type="text" id="subject" placeholder="Subject" required="required">
                </div>

                <div>
                    <textarea name="comments" cols="40" rows="3" id="comments" placeholder="Message" spellcheck="true" required="required"></textarea>
                </div>

                <input type="submit" class="submit button" id="submit" value="Submit Message">

                </form>
        </section>
    </div><!-- Contact Form / End -->

    <div class="col-md-12" style="padding-top:30px">
        Do you want to be part of us and advertise your business?
        Download our sponsorship program and sent it to us.
    </div>

</div>

</div><!-- container -->