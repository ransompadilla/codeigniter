<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Page extends MY_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('page_model');
        $this->load->module('listing/listing');
        $this->load->module('category/category');
		$this->load->module('options/options');	
		$this->load->module('user/user');	
    }

	public function index($page=''){
	    
		if($page === ''){
			$a_data = array(
				's_navcurrent'	=> 'home',
				'pagename'		=> 'Home'
			);
			$a_data['rand1'] = $this->generateRandomString(42);
			$a_data['rand2'] = $this->generateRandomString(28);
			$a_data['categories'] = $this->category->getCategories(); 

			$this->pg_display('main',$a_data);
		}else{
			redirect($page);
		}
	}

	public function about(){
		$a_data = array(
			's_navcurrent'	=> 'about',
			'pagename'		=> 'About'
		);
		$this->pg_display('about',$a_data);
	}

	public function listings(){
		$a_data = array();
		
		$a_data = array(
			's_navcurrent'	=> 'listings',
			'pagename'		=> 'Listings'
		);
		$a_data['categories'] = $this->category->getCategories(); 
		$a_data['rand1'] = $this->generateRandomString(8);
		$a_data['rand2'] = $this->generateRandomString(8);
		if(isset($_GET['cities']) &&  !(isset($_GET['state'])) && !(isset($_GET['category'])) && !(isset($_GET['search']))){
			$city_arr = explode('&', $_GET['cities']);
			$a_data['listings'] = $this->listing->cities_filter($city_arr[0]); 
			$a_data['related'] = "";
		}
		else if(isset($_GET['category']) && !(isset($_GET['state'])) && !(isset($_GET['cities'])) && !(isset($_GET['search']))){
			$cat_arr = explode('z', $_GET['category']);
			$a_data['listings'] = $this->listing->category_filter($cat_arr[1]); 
			$a_data['related'] = "";
		}
		else if(isset($_GET['category']) && isset($_GET['state']) && isset($_GET['search']) && !(isset($_GET['cities']))){
			$cat_arr = explode('i', $_GET['category']);
			$a_data['listings'] = $this->listing->filter($cat_arr[1], $_GET['state'], $_GET['search']); 
			$a_data['related'] = $this->listing->related_filter($cat_arr[1], $_GET['state'], $_GET['search']); 
		}
		else{
			$a_data['related'] = "";
			$a_data['listings'] = $this->listing->getListings();
		}
		
		$a_data['u_info'] = ''; 
		$this->pg_display('listings',$a_data);
	}

	public function listing($lst_id){ 
		$from = $this->session->userdata('user_info')->id;
		$arr = explode('i', $lst_id);
		$id = $arr[1];
		$list_id=$id;
		$a_data['rand1'] = $this->generateRandomString(42);
		$a_data['rand2'] = $this->generateRandomString(28);
		if(!$this->session->userdata('user_info')){
			redirect('opps');
		}
		$a_data = array(
			's_navcurrent'	=> 'listings',
			'pagename'		=> 'Listings'
		);
		
		$id = array('id_list' => $id);
		$a_data['listing'] = $this->listing->getlisting($id);

		$location = unserialize($a_data['listing']->location);

		$a_data['u_info'] = $this->listing->getUserByListingID($list_id); 
		$this->load->module('chat/chat');
		//$a_data['chat_convo'] = $this->chat->getChatIndivConvo($from, $a_data['u_info']->id);

		if($a_data['listing'] == '' ){
			show_404();
		}


		$a_data['options'] = $this->options->getOptions(); 

		$a_data['categories'] 	= $this->category->getCategories(); 
		$a_data['list_id'] 		= $id;
		// ---- MAP PART --- //
		
		$this->load->library('googlemap_api');
		$complate_add = $location['address'].", ".$location['city'].", ".$location['state']['name'];
		//if(isset($_GET['sensor'])!=""){
			$config['center'] = $complate_add;
			$config['zoom'] = 15;
			$this->googlemap_api->initialize($config);

			$marker = array();
			$marker['position'] = $complate_add;
			$this->googlemap_api->add_marker($marker);
			
			$a_data['maps'] = $this->googlemap_api->create_map();

		//}
		

		if($a_data['listing']->post_type == 'property'){
			$this->pg_display('property-list',$a_data);
		}elseif($a_data['listing']->post_type == 'searcher'){
			$this->pg_display('profile-list',$a_data);
		}else{
			show_404();
		}
		
	}
	public function pricing($data = ""){
		$a_data = array(
			's_navcurrent'	=> 'pricing',
			'pagename'		=> 'Pricing'
		);
		if($data != ""){
            $findme = array(0=>'zMsCz',1=>'UsrLsT',2=>'Lst');
            $pos = strpos($data, $findme[0]);
            $pos1 = strpos($data, $findme[1]);
            $pos2 = strpos($data, $findme[2]);
			
    			if($pos){
    				$a_data['message'] = "You wish to view your messages ? Please try our free plan or choose the best plan. thanks!";
    			}
    			else if($pos1){
    				$a_data['message'] = "You wish to manage your Listings ? Please try our free plan or choose the best plan. thanks!";
    			}
    			else if($pos2){
    				$a_data['message'] = "You wish to make listings? Please try our free plan or choose the best plan. thanks!";
    			}
    			else{show_404();}
			
		}
		else{
			$a_data['message']	= "";
		}

		$a_data['free'] 	= $this->generateRandomString(10)."z3z".$this->generateRandomString(10);
		$a_data['basic'] 	= $this->generateRandomString(10)."z1z".$this->generateRandomString(10);
		$a_data['full'] 	= $this->generateRandomString(10)."z2z".$this->generateRandomString(10);
		$done_free = $this->user->done_FreePlan();
		if($done_free == true){
			$a_data['done_free'] = true;
		}
		else{$a_data['done_free'] = false;}
		$this->pg_display('pricing',$a_data);
	}
	
	public function contact(){
		$a_data = array(
			's_navcurrent'	=> 'contact',
			'pagename'		=> 'Contact'
		);
		$this->pg_display('contactpage',$a_data);
	}
	public function terms_conditions(){
		$a_data = array(
			's_navcurrent'	=> 'terms-conditions',
			'pagename'		=> 'Terms and Conditions'
		);
		$this->pg_display('terms-conditions',$a_data);
	}

	public function signup(){
		$a_data = array(
			's_navcurrent'	=> 'signup',
			'pagename'		=> 'Register'
		);
		$this->pg_display('signup',$a_data);
	}
	public function signin(){
		$a_data = array(
			's_navcurrent'	=> 'signin',
			'pagename'		=> 'Login'
		);
		$this->pg_display('signin',$a_data);
	}
}

