<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Messages extends MY_Controller {
	protected $smiley_url = 'http://localhost/urgchat/public_html/assets/images/smileys';
	public function __construct(){
        parent::__construct();
        $this->load->model('messages_model');
        $this->load->model('user/UserModel');
		$this->load->helper('smiley');
    }

	public function index(){
		show_404();
	}
	//RANSOM FUNCTIONS
	public function messages(){
		//get paginated messages 
		$per_page 	= 5;
		$user		= $this->session->userdata('user_info')->id;
		$buddy 		= $this->input->post('user');
		$limit 		= isset($_POST['limit']) ? $this->input->post('limit') : $per_page ;
		$messages 	= array_reverse($this->messages_model->conversation($user, $buddy, $limit));
		$total 		= $this->messages_model->thread_len($user, $buddy);

		$thread = array();
		foreach ($messages as $message) {
			$owner = $this->UserModel->getUserInfo($message->from);
			$seen_id = $message->seen != NULL ? $message->seen : NULL;
			$seen_name = $this->UserModel->getUserInfo($seen_id);
			$chat = array(
				'msg' 		=> $message->id,
				'sender' 	=> $message->from, 
				'recipient' => $message->to,
				'avatar' 	=> $owner->avatar != '' ? $owner->avatar : 'no-image.jpg',
				'body' 		=> parse_smileys($message->message, $this->smiley_url),
				'time' 		=> date("M j, Y, g:i a", strtotime($message->time)),
				'type'		=> $message->from == $user ? 'out' : 'in',
				//'seen'		=> ucfirst($seen_name->first_name),
				'name'		=> $message->from == $user ? 'You' : ucwords($owner->first_name)
				);
			array_push($thread, $chat);
		}

		$chatbuddy = $this->UserModel->getUserInfo($buddy);

		$contact = array(
			'name'=>ucwords($chatbuddy->first_name.' '.$chatbuddy->last_name),
			'id'=>$chatbuddy->id,
			'limit'=>$limit + $per_page,
			'more' => $total  <= $limit ? false : true, 
			'scroll'=> $limit > $per_page  ?  false : true,
			'remaining'=> $total - $limit
			);


		$response = array(
					'success' => true,
					'errors'  => '',
					'message' => '',
					'buddy'	  => $contact,
					'thread'  => $thread
					);
		//add the header here
		header('Content-Type: application/json');
		echo json_encode($response);
	}
	public function save_message(){
		$logged_user = $this->session->userdata('user_info')->id;
		$buddy 		= $this->input->post('user');
		$message 	= $this->input->post('message');
		if($message != '' && $buddy != '')
		{
			$msg_id = $this->messages_model->insertMessage(array(
						'from' 		=> $logged_user,
						'to' 		=> $buddy,
						'message' 	=> $message,
					));
			$msg = $this->messages_model->getMessageByID($msg_id);

			$owner = $this->UserModel->getUserInfo($msg->from);
			$seen_id = $msg->seen != NULL ? $msg->seen : NULL;
			$seen_name = $this->UserModel->getUserInfo($seen_id);
			$chat = array(
				'msg' 		=> $msg->id,
				'sender' 	=> $msg->from, 
				'recipient' => $msg->to,
				'avatar' 	=> $owner->avatar != '' ? $owner->avatar : 'no-image.jpg',
				'body' 		=> parse_smileys($msg->message, $this->smiley_url),
				'time' 		=> date("M j, Y, g:i a", strtotime($msg->time)),
				'type'		=> $msg->from == $logged_user ? 'out' : 'in',
				//'seen'		=> ucfirst($seen_name->first_name),
				'name'		=> $msg->from == $logged_user ? 'You' : ucwords($owner->first_name)
				);

			$response = array(
				'success' => true,
				'message' => $chat 	  
				);
		}
		else{
			  $response = array(
				'success' => false,
				'message' => 'Empty fields exists'
				);
		}
		//add the header here
		header('Content-Type: application/json');
		echo json_encode( $response );
	}
	public function updates(){
	    $new_exists = false;
		$user_id 	= $this->session->userdata('user_info')->id;
		$last_seen = $this->messages_model->last_seen($user_id);
		$exists = $this->messages_model->latest_message($user_id, $last_seen->id);
		//echo $exists;
		if($exists){
			$new_exists = true;
		}
		// THIS WHOLE SECTION NEED A GOOD OVERHAUL TO CHANGE THE FUNCTIONALITY
	    if ($new_exists) {
	        $new_messages = $this->messages_model->unread($user_id);
			$thread = array();
			$senders = array();
			foreach ($new_messages as $message) {
				if(!isset($senders[$message->from])){
					$senders[$message->from]['count'] = 1; 
				}
				else{
					$senders[$message->from]['count'] += 1; 
				}
				$owner = $this->UserModel->getUserInfo($message->from);
				$seen_id = $message->seen != NULL ? $message->seen : NULL;
				$seen_name = $this->UserModel->getUserInfo($seen_id);
				$chat = array(
					'msg' 		=> $message->id,
					'sender' 	=> $message->from, 
					'recipient' => $message->to,
					'avatar' 	=> $owner->avatar != '' ? $owner->avatar : 'no-image.jpg',
					'body' 		=> parse_smileys($message->message, $this->smiley_url),
					'time' 		=> date("M j, Y, g:i a", strtotime($message->time)),
					'type'		=> $message->from == $user_id ? 'out' : 'in',
					///'seen'		=> ucfirst($seen_name->first_name),
					'name'		=> $message->from == $user_id ? 'You' : ucwords($owner->first_name)
					);
				array_push($thread, $chat);
			}

			$groups = array();
			foreach ($senders as $key=>$sender) {
				$sender = array('user'=> $key, 'count'=>$sender['count']);
				array_push($groups, $sender);
			}
			$response = array(
				'success' => true,
				'messages' => $thread,
				'senders' =>$groups
			);

			//add the header here
			header('Content-Type: application/json');
			echo json_encode( $response );
	    } 
	}
	public function mark_read(){
		$id = $this->input->post('id');
		$buddy = $this->input->post('buddy');
		$this->messages_model->mark_read($id, $buddy);
	}
	public function getChatMessages($id){
		return $this->messages_model->getChatMessages($id);
	}
	public function getUnreadMessages($id){
		return $this->messages_model->getUnreadMessages($id);
	}
	public function getLastMessage($from, $to){
		return $this->messages_model->getLastMessage($from, $to);
	}
	public function seen_message($from, $to){
		return $this->messages_model->seen_message($from, $to);
	}
}
