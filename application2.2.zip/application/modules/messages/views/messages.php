<!-- Titlebar -->

        <div class="messages-section row">
            
            <!-- Listings -->
            <div class="list_people col-md-4">

                <div class="messages-container margin-top-0">
                    <div class="messages-headline">
                        <input type="text" name="" placeholder="Search" />
                    </div>
                    
                    <div class="messages-inbox">

                        <ul>
                            <?php 
                            $date_message = "";
                            if($messages_chat != ""):
                                foreach($messages_chat as $message):
                                    $mes = $this->messages->getUnreadMessages($message->from);
                                    $last_message = $this->messages->getLastMessage($message->from, $message->to);
                                    if($mes):
                                        foreach($mes as $val):
                                            $d = strtotime($val->time);
                                            $date_cur_month = date('F j',$d);
                                            $date_cur_hour = date('h:i A',$d);
                                            $date_now = date('F j');
                                            $day_curr = date('j',$d);
                                            $day_now = date('j');
                                            if($date_cur_month == $date_now){
                                              $date_message = "Today ".$date_cur_hour;
                                            }
                                            else{
                                                $date_message = $date_cur_month." ".$date_cur_hour;
                                            }
                                        endforeach;?>
                                    <?php if(!($message->from == $this->session->userdata('user_info')->id) || !($message->to == $this->session->userdata('user_info')->id)):?>
                                        <li class="unread">
                                            <a href="<?php echo site_url('user/messages/'.$message->from);?>">
                                                <div class="message-avatar"><img src="http://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;s=70" alt="" /></div>

                                                <div class="message-by">
                                                    <div class="message-by-headline">
                                                        <h5><?= ucfirst($message->first_name)." ".ucfirst($message->last_name)?> <i class="unread"><?= count($mes);?> Unread</i></h5>
                                                        <span>
                                                            <p ><?= $date_message;?></p>
                                                        </span>
                                                    </div>
                                                    <p ><?= $val->message;?></p>
                                                   
                                                     
                                                </div>
                                            </a>
                                        </li>
                                    <?php endif;?>
                                <?php else:
                                            $d = strtotime($last_message->time);
                                            $date_cur_month = date('F j',$d);
                                            $date_cur_hour = date('h:i A',$d);
                                            $date_now = date('F j');
                                            $day_curr = date('j',$d);
                                            $day_now = date('j');
                                            if($date_cur_month == $date_now){
                                              $date_message = "Today ".$date_cur_hour;
                                            }
                                            else{
                                                $date_message = $date_cur_month." ".$date_cur_hour;
                                            }
                                    ?>
                                    <?php if(!($last_message->from == $this->session->userdata('user_info')->id) || !($last_message->to == $this->session->userdata('user_info')->id)):?>
                                        <li class="unread">
                                            <a href="<?php echo site_url('user/messages/'.$message->from);?>">
                                                <div class="message-avatar"><img src="http://www.gravatar.com/avatar/00000000000000000000000000000000?d=mm&amp;s=70" alt="" /></div>

                                                <div class="message-by">
                                                    <div class="message-by-headline">
                                                        <h5><?= ucfirst($message->first_name)." ".ucfirst($message->last_name)?> </h5>
                                                        <span>
                                                            <p id="date-message"><?= $date_message;?></p>
                                                        </span>
                                                    </div>
                                                   
                                                    <?php
                                                    $seen = "";
                                                        if($last_message->from == $this->session->userdata('user_info')->id):
                                                            if($last_message->seen != NULL){
                                                                $seen = "Seen by: ".ucfirst($message->first_name);
                                                            }
                                                    ?>

                                                        <p id="message-prompt">You: <?= $last_message->message;?> <span id="seen_by" class="float-right"><?= $seen?></span></p>
                                                    <?php else:?>
                                                        <p id="message-prompt"><?= $last_message->message;?></p>
                                                    <?php endif;?>
                                                   
                                                     
                                                </div>
                                            </a>
                                        </li>
                                    
                                    <?php endif;?>
                            <?php
                                endif;
                             endforeach;
                            endif;
                            ?>
                        </ul>
                        
                    </div>
                </div>

            </div>
            <!-- <div class="col-md-8 content-title">
                <?php if($to != ""):?>
                    <h3><?= ucfirst($to->first_name).' '.ucfirst($to->last_name) ?></h3>
                <?php endif;?>
            </div> -->
            <div class="col-md-8 content-view">
                <div class="row">
                    <div class="col-sm-7 input-section">
                        <div id="chat-container">
                        <div id="chat-box">
                        <div class="chat-box-header">
                            
                            <span class="user-status is-online"></span>
                            <span class="display-name">
                                <?php if($to != ""):?>
                                    <?= ucfirst($to->first_name).' '.ucfirst($to->last_name) ?>
                                <?php endif;?>
                            </span>
                            <small></small>
                        </div>

                        <div class="chat-container">
                            <div class="chat-content">
                                <ul class="chat-box-body"></ul>
                            </div>
                            <div class="chat-textarea input-section">
                                <input type="hidden" id="to" name="to" value="<?php if($to != ''){echo $to->id;}?>" />
                               <input type="text" id="input-message" name="input-message" placeholder="Write Messages...">
                                <button class="message-send">Send</button>
                            </div>
                        </div>
                        </div>
                    </div>
                    </div>
                    <div class="col-sm-5">
                        
                    </div>
                </div>
            </div>
            <?php include 'inc/copyrights.php';?>
        </div>