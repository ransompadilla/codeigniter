            <!-- Copyrights -->
            <div class="col-md-12 text-center">
                <div class="copyrights">© <?php echo date("Y"); ?> Aussieflatmates. All Rights Reserved | Powered by <a href="https://urgwebsolutions.com">URG Websolutions</a></div>
            </div>