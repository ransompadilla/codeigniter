<div class="input-section">
     <input type="hidden" id="from" name="from" value="<?php echo $this->session->userdata('user_info')->id; ?>" />
     <input type="hidden" id="to" name="to" value="<?php if($to != ''){echo $to->id;}?>" />
     <input type="text" id="input-message" name="input-message" />
     <button class="message-send button">Send</button>
</div>