<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reviews extends MY_Controller {

	public function __construct(){
        parent::__construct();
		$this->load->model('user/UserModel');
    }

	public function index(){
		$user_data = $this->session->userdata('user_info');
		$a_data = array(
			's_navcurrent'	=> 'reviews',
			'pagename'		=> 'Reviews'
		);

		$a_data['paymentRecord'] = $this->UserModel->payment_record($user_data->id);
		$p_user = $this->UserModel->getPaymentByUser($user_data->id);
		if($p_user != ""){
			$a_data['nCount'] = $this->UserModel->count_notif($p_user->payment_id);
		}
		else{
			$a_data['nCount'] = "";
		}
		// $this->mybreadcrumb->add('Home', base_url());
		// $this->mybreadcrumb->add('Dashboard', base_url('dashboard'));
		// $this->mybreadcrumb->add('Add Listing', base_url('listing'));
		// $data['breadcrumbs'] = $this->mybreadcrumb->render();
		 
	
		$this->dash_display('reviews',$a_data);

	}



}
