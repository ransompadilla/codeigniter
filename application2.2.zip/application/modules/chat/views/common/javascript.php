<script type="text/javascript">var base = "<?php echo base_url();?>";</script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets2/js/jquery-1.10.2.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets2/js/jquery-ui.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets2/js/bootstrap.min.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets2/js/jquery.slimscroll.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets2/js/main.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets2/js/chatigniter.js"></script>
