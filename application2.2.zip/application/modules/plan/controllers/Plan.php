<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Plan extends MY_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->library('paypal_lib');
       // $this->load->module('user/user');
        $this->load->model('Plan_Model');
    }
    function pay($plan_id){
        if(!$this->session->userdata('user_info')){
            redirect('opps');
        }
    	$p_id = explode("z", $plan_id);
        // Set variables for paypal form
        $returnURL = base_url().'plan/paypal/success'; //payment success url
        $cancelURL = base_url().'plan/paypal/cancel'; //payment cancel url
        $notifyURL = base_url().'plan/paypal/ipn'; //ipn url
        
        // Get product data
        $plan = $this->Plan_Model->getPlan($p_id[1]);
        
        // Get current user ID from session
        $userID = $this->session->userdata('user_info')->id;
        if($p_id[1] == 3){
             date_default_timezone_set("Asia/Manila");
             $data = array(
                'user_id'=>$userID,
                'plan_id'=>$p_id[1],
                'status'=>1
             );
            // Insert the transaction data into the database
            $result = $this->Plan_Model->insertTransaction($data);
            if($result){
                redirect('user/payments');
            }
        }
        else{
            // Add fields to paypal form
            $this->paypal_lib->add_field('return', $returnURL);
            $this->paypal_lib->add_field('cancel_return', $cancelURL);
            $this->paypal_lib->add_field('notify_url', $notifyURL);
            $this->paypal_lib->add_field('item_name', $plan->plan_category);
            $this->paypal_lib->add_field('custom', $userID);
            $this->paypal_lib->add_field('item_number',  $plan->plan_id);
            $this->paypal_lib->add_field('amount',  $plan->price);
            
            // Load paypal form
            $this->paypal_lib->paypal_auto_form();
        }
        
    }
}