<h3>Dear Buyer</h3>
<p>We are sorry! Your last transaction was cancelled.</p>
<a href="<?php echo base_url('pricing'); ?>">Back to pricing</a>