<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class Amenities extends MY_Controller{
    
    
    public function __construct(){
        parent::__construct();
        $this->load->model('AmenitiesModel');
    }
    
    public function index(){
        show_404();
    }

    public function getAmenities(){
        return $this->AmenitiesModel->getAll();
    }

}
