<?php (defined('BASEPATH')) OR exit('No direct script access allowed');

class MY_Controller extends MX_Controller {

	var $i_userid = 0;

	public function __construct() {
		parent::__construct();
		
		$this->load->module('user/user');

		$this->encryption->initialize(
				array(
						'cipher' => 'aes-256',
						'mode' => 'ctr',
						'key' => '8e5e5ef76d5e5ba1023c1a03fddb6cb6'
				)
		);

		$this->load->library('form_validation');
		$this->form_validation->CI =& $this;
        //if($this->check_login())
		//	$this->id_user = $this->session->userdata('user_id');
   	}
   	
	//company information
	protected function info($page = array()) {

		$a_info = array();

		$a_info['company_name'] = 'Aussie.Com';
		$a_info['pagename'] = (isset($page['pagename'])) ? $page['pagename'] . ' - ' : '';

		return $a_info;
	}

	//main display
	protected function pg_display($s_body, $a_data = array()) {
		$a_page = array();		

		$a_page['rand1'] = $this->generateRandomString(8);
        $a_page['rand2'] = $this->generateRandomString(8);
        $a_page['head'] = $this->load->view('front-end/head', $a_data, TRUE);
        $a_page['header'] = $this->load->view('front-end/header', $a_data, TRUE);
		$a_page['nav'] = $this->load->view('front-end/nav', $a_data, TRUE);
		$a_page['body'] = $this->load->view($s_body, $a_data, TRUE);
		$a_page['footer'] = $this->load->view('front-end/footer','', TRUE);

		$this->load->view('front-end/default', $a_page);
	}
	protected function pg_messages($s_body, $a_data = array()) {
		$a_page = array();		

		$a_page['rand1'] = $this->generateRandomString(8);
        $a_page['rand2'] = $this->generateRandomString(8);
        $a_page['head'] = $this->load->view('front-end/head', $a_data, TRUE);
        $a_page['header'] = $this->load->view('front-end/header', $a_data, TRUE);
		$a_page['nav'] = $this->load->view('front-end/nav', $a_data, TRUE);
		$a_page['body'] = $this->load->view($s_body, $a_data, TRUE);
		$a_page['footer'] = $this->load->view('front-end/footer','', TRUE);

		$this->load->view('front-end/messages', $a_page);
	}
	//dashboard display
	protected function dash_display($s_body, $a_data = array()) {
		$plan = $this->user->manage_notification();
		$arr = explode('-', $plan);
		$a_page = array();	
		$a_data['plan'] = array('plan'=>$arr[1],'rem_days'=>$arr[0]);
        $a_page['head'] = $this->load->view('dashboard_head', $a_data, TRUE);
        $a_page['header'] = $this->load->view('dashboard_header', $a_data, TRUE);
        $a_page['data'] = $this->user->getPaymentRecords();
		$a_page['nav'] = $this->load->view('dashboard_nav', $a_data, TRUE);
		$a_page['body'] = $this->load->view($s_body, $a_data, TRUE);
		$a_page['footer'] = $this->load->view('dashboard_footer','', TRUE);

		$this->load->view('dashboard_main', $a_page);
	}
	protected function notif_display($s_body, $a_data = array()) {
		$this->load->module('user/user');
		$a_page = array();		
        $a_page['head'] = $this->load->view('dashboard_head', $a_data, TRUE);
        $a_page['header'] = $this->load->view('dashboard_header', $a_data, TRUE);
        $a_page['data'] = $this->user->getPaymentRecords();
		$a_page['nav'] = $this->load->view('dashboard_nav', $a_data, TRUE);
		$a_page['body'] = $this->load->view($s_body, $a_data, TRUE);
		$a_page['footer'] = $this->load->view('dashboard_footer','', TRUE);

		$this->load->view('dashboard_main', $a_page);
	}
    // country list
    function countryArray(){
	return $country_Array = array('Afghanistan', 'Albania', 'Algeria', 'American Samoa', 'Andorra','Angola', 'Anguilla', 'Antarctica', 'Antigua and Barbuda', 'Argentina', 'Armenia', 'Aruba', 'Australia', 'Austria', 'Azerbaijan', 'Bahamas', 'Bahrain', 'Bangladesh', 'Barbados', 'Belarus','Belgium', 'Belize', 'Benin', 'Bermuda', 'Bhutan', 'Bolivia', 'Bosnia and Herzegowina', 'Botswana', 'Bouvet Island', 'Brazil', 'British Indian Ocean Territory', 'Brunei Darussalam', 'Bulgaria', 'Burkina Faso', 'Burundi', 'Cambodia', 'Cameroon', 'Canada', 'Cape Verde', 'Cayman Islands', 'Central African Republic', 'Chad', 'Chile', 'China', 'Christmas Island', 'Cocos (Keeling) Islands', 'Colombia', 'Comoros', 'Congo', 'Congo, the Democratic Republic of the', 'Cook Islands','Costa Rica', 'Cote d&#39Ivoire', 'Croatia (Hrvatska)', 'Cuba', 'Cyprus', 'Czech Republic', 'Denmark', 'Djibouti', 'Dominica', 'Dominican Republic', 'East Timor', 'Ecuador', 'Egypt', 'El Salvador', 'Equatorial Guinea', 'Eritrea', 'Estonia', 'Ethiopia', 'Falkland Islands (Malvinas)', 'Faroe Islands', 'Fiji', 'Finland', 'France', 'France, Metropolitan', 'French Guiana', 'French Polynesia', 'French Southern Territories', 'Gabon', 'Gambia', 'Georgia', 'Germany', 'Ghana', 'Gibraltar', 'Greece', 'Greenland', 'Grenada', 'Guadeloupe', 'Guam', 'Guatemala', 'Guinea', 'Guinea-Bissau', 'Guyana', 'Haiti', 'Heard and Mc Donald Islands', 'Holy See (Vatican City State)', 'Honduras', 'Hong Kong', 'Hungary', 'Iceland', 'India', 'Indonesia', 'Iran (Islamic Republic of)', 'Iraq', 'Ireland', 'Israel', 'Italy', 'Jamaica', 'Japan', 'Jordan', 'Kazakhstan', 'Kenya', 'Kiribati', 'Korea, Democratic People&#39s Republic of', 'Korea, Republic of', 'Kuwait', 'Kyrgyzstan', 'Lao People&#39s Democratic Republic', 'Latvia', 'Lebanon', 'Lesotho', 'Liberia', 'Libyan Arab Jamahiriya', 'Liechtenstein', 'Lithuania', 'Luxembourg', 'Macau', 'Macedonia, The Former Yugoslav Republic of', 'Madagascar', 'Malawi', 'Malaysia', 'Maldives', 'Mali', 'Malta', 'Marshall Islands', 'Martinique', 'Mauritania', 'Mauritius', 'Mayotte', 'Mexico', 'Micronesia, Federated States of', 'Moldova, Republic of', 'Monaco', 'Mongolia', 'Montserrat', 'Morocco', 'Mozambique', 'Myanmar', 'Namibia', 'Nauru', 'Nepal', 'Netherlands', 'Netherlands Antilles', 'New Caledonia', 'New Zealand', 'Nicaragua', 'Niger', 'Nigeria', 'Niue', 'Norfolk Island', 'Northern Mariana Islands', 'Norway', 'Oman', 'Pakistan', 'Palau', 'Panama', 'Papua New Guinea', 'Paraguay', 'Peru', 'Philippines', 'Pitcairn', 'Poland', 'Portugal', 'Puerto Rico', 'Qatar', 'Reunion', 'Romania', 'Russian Federation', 'Rwanda', 'Saint Kitts and Nevis', 'Saint LUCIA', 'Saint Vincent and the Grenadines', 'Samoa', 'San Marino', 'Sao Tome and Principe', 'Saudi Arabia', 'Senegal', 'Seychelles', 'Sierra Leone', 'Singapore', 'Slovakia (Slovak Republic)', 'Slovenia', 'Solomon Islands', 'Somalia', 'South Africa', 'South Georgia and the South Sandwich Islands', 'Spain', 'Sri Lanka', 'St. Helena', 'St. Pierre and Miquelon', 'Sudan', 'Suriname', 'Svalbard and Jan Mayen Islands', 'Swaziland', 'Sweden', 'Switzerland', 'Syrian Arab Republic', 'Taiwan, Province of China', 'Tajikistan', 'Tanzania, United Republic of', 'Thailand', 'Togo', 'Tokelau', 'Tonga', 'Trinidad and Tobago', 'Tunisia', 'Turkey', 'Turkmenistan', 'Turks and Caicos Islands', 'Tuvalu', 'Uganda', 'Ukraine', 'United Arab Emirates', 'United Kingdom', 'United States', 'UM' => 'United States Minor Outlying Islands', 'Uruguay', 'Uzbekistan', 'Vanuatu', 'Venezuela', 'Viet Nam', 'Virgin Islands (British)', 'Virgin Islands (U.S.)', 'Wallis and Futuna Islands', 'Western Sahara', 'Yemen', 'Yugoslavia', 'Zambia', 'Zimbabwe');
	}

	function stateArray(){
		return $country_Array = array('Australian Capital Territory', 'New South Wales', 'Victoria', 'Queensland', 'South Australia', 'Western Australia', 'Tasmania', 'Northern Territory');
	}

    // random string generator
	function generateRandomString($length) {
	    $characters = '0123456789abcdefghijklmnopqrstuvwxyABCDEFGHIJKLMNOPQRSTUVWXY';
	    $charactersLength = strlen($characters);
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, $charactersLength - 1)];
	    }
	    return $randomString;
	}


	function mailthis($to, $subject, $message){
		// $config = array(
		// 	"useragent" => $_SERVER['HTTP_USER_AGENT'],
		// 	"protocol" => "smtp",
		// 	"smtp_host" => "mail.urgwebsolutions.com",
		// 	"smtp_user" => "no-reply@urgwebsolutions.com",
		// 	"smtp_pass" => "L!-wj&Sfb[by",
		// 	"smtp_timeout" => "200",
		// 	"charset"	=> "iso-8859-1",
		// 	"smtp_port" => "465",
		// 	"mailtype" => "html",
		// 	"smtp_crypto" => "tls",
		// 	"crlf"     => "\r\n",
		// 	"validate"   => FALSE,
		// 	"priority"   => "3"
		// 	);

		$config =array(
			'useragent' => 'Aussieflatmates',
			'protocol' => 'sendmail',
			//'smtp_host' => 'mail.urgwebsolutions.com',
			//'smtp_user' => 'no-reply@urgwebsolutions.com',
			//'smtp_pass' => 'L!-wj&Sfb[by',
			//'smtp_port' => '587',
			'mailtype' => 'html',
			'charset'	=> 'iso-8859-1'
			);

		$this->email->initialize($config);
		$this->email->set_newline("\r\n");
		$this->email->from('Admin@email.com', 'aussie');
		$this->email->to($to);
		$this->email->reply_to('support@urgwebsolutions.com');
		// $this->email->cc('');
		// $this->email->bcc('');support@urgwebsolutions.com
		$this->email->subject($subject);
		$this->email->message($message);
		
		//$this->email->send();
		if($this->email->send()){

		 	return true;
		}else{
		 	return $this->email->print_debugger();
		}
		//return $this->email->print_debugger();
		//exit;
	}

	protected function check_login($i_usertype = 0) {
		$b_islogin = FALSE;

		if($this->session->userdata('token')) {

			$b_islogin = TRUE;

			//optional
			if($i_usertype != 0) {
				$b_islogin = $this->check_usertype($i_usertype);
			}
		}
		return $b_islogin;
	}

	protected function check_usertype($i_usertype = 0) {
		$b_type = FALSE;

		if(($i_usertype != 0) && ($this->session->userdata('role') == $i_usertype)) {
			$b_type = TRUE;
		}
		return $b_type;
	}

	function getCurrentDateTime(){
		$now = new DateTime();
		$now->setTimezone(new DateTimezone('Asia/Manila'));
		return $now->format('Y-m-d H:i:s');
	}

	
	
}
