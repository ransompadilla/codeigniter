var state = $('#input_state').val();
console.log(state);
$.ajax({
    url: base_url+"assets/scripts/statejson.json",
    type: "GET",
    dataType: "json",
	success: function(data){
        for(var i=0;i<data.length; i++){
            if(state != "" && state == data[i].name){
                $('#au_state').append("<option value='"+data[i].name+"' selected >"+data[i].name+"("+data[i].short+")" + "</option>");
            }
            else{
                $('#au_state').append("<option value='"+data[i].name+"'>"+data[i].name+"("+data[i].short+")" + "</option>");
            }
        }
    }
});