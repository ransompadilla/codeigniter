<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Listing extends MY_Controller {

	public function __construct(){
		parent::__construct();
	
		$this->load->model('ListingModel'); 
		//$this->load->model('UserModel'); 

	}

	public function index(){
		show_404();
	}

		
	public function new_searcher(){
		if($_POST){			
			$this->form_validation->set_rules('category', 'Post Category', 'callback_check_options');
			$this->form_validation->set_rules('for', 'For', 'trim|required');
			$this->form_validation->set_rules('description', 'Description', 'trim|required');
			$this->form_validation->set_rules('move_date', 'Move Date', 'trim|required');
			$this->form_validation->set_rules('min_price', 'Price Rate', 'trim|required');
			$this->form_validation->set_rules('max_price', 'Price Rate', 'trim|required');
			$this->form_validation->set_rules('price_by', 'Price Rate', 'trim|required');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			
			$image = array();
			$image_check = true;

			if($this->form_validation->run()){
				$category 	= $this->input->post('category');
				$for 		= $this->input->post('for');
				$date_avail = $this->input->post('move_date');
				$description= $this->input->post('description');
				$min_price 	= $this->input->post('min_price');
				$max_price 	= $this->input->post('max_price');
				$price_by 	= $this->input->post('price_by');
				$address 	= $this->input->post('address');
				
				//not required
				$allowed 		= $this->input->post('allowed');
				$room_type 		= $this->input->post('room_type');
				$length_stay 	= $this->input->post('length_stay');
				$length_stay_by = $this->input->post('length_stay_by');
				$requirements 	= $this->input->post('requirements');
				
				$length_stay = array('length_stay' =>$length_stay, 'length_stay_by'=> $length_stay_by);
				$final_more_options = array(
										'interested_also'  => $room_type,
									);
									
				$final_price = array('min_amount'=> $min_price,'max_amount'=> $max_price,'price_by'=> $price_by);

				if($_FILES['photo']['name'] != 0){

					$no_of_files = sizeof($_FILES['photo']['tmp_name']);
					$sub_type = $this->session->userdata('user_info')->subscription_type;

					if($no_of_files > 6 && $sub_type == 0){
						
							
						$response['status'] = false;
						$response['msg'] = 'Image was not Uploaded. Maximum allowed photos is (6). You must upgrade to upload more files. <a href="'.base_url('subscribe').'">Click here</a> to subscribe.';
						//echo json_encode($response);			

					}elseif(($no_of_files <= 6 && $sub_type == 0) || ($sub_type == 1)){
						$this->load->library('upload');
						$myStr = $this->session->userdata('user_info')->first_name;
						$key = mb_substr($myStr, 0, 3);
						//for ($i=0; $i < sizeof($_FILES['photo']['name']); $i++) {
							$_FILES['userfile']['name']     = $_FILES['photo']['name'];
							$_FILES['userfile']['type']     = $_FILES['photo']['type'];
							$_FILES['userfile']['tmp_name'] = $_FILES['photo']['tmp_name'];
							$_FILES['userfile']['error']    = $_FILES['photo']['error'];
							$_FILES['userfile']['size']     = $_FILES['photo']['size'];

							$config = array(
								'file_name'     => $key.date('ymdhis'),
								'allowed_types' => 'jpg|jpeg|png|gif',
								'max_size'      => 3000,
								'overwrite'     => FALSE,
								'max_width'		=> 1000,
								'max_height'	=> 768,
								'upload_path'	=> 'uploads/listing'
							);
							$this->upload->initialize($config);

							if ( !$this->upload->do_upload('userfile')) :
								$error = $this->upload->display_errors();
								$response['status'] = false;
								$response['msg'] = $error;
								$image_check = false;
							else :

							$image = $this->upload->data('file_name'); 
							// Continue processing the uploaded data

							endif;
						//}
						
					}				    		
				}

				$data_to_insert = array(
					'id_user' 		=> $this->session->userdata('user_info')->id,
					'category' 		=> $category,
					'title_for' 	=> $for,
					'post_type' 	=> 'searcher',
					'about_describ' => $description,
					'location' 		=> $address,
					'price' 		=> serialize($price),
					'media'			=> serialize(array('images' => '')),
					'avail_movein' 	=> $date_avail,
					'more_options' 	=> serialize($final_more_options),
					'allowed'	   	=> serialize($allowed),
					'price' 	   	=> serialize($final_price),
					'required'	  	=> $requirements,
					'stay_length' 	=> serialize($length_stay),
					'is_premium'	=> 0,
					'date_added'   	=> $this->getCurrentDateTime(),
					'date_updated' 	=> $this->getCurrentDateTime()
				);

				
				$response['msg'] = 'New Listing Added! Please add Cover photos to your new listing.';

				if(count($image) > 0 && $image_check == true){
					$data_to_insert['media'] = serialize(array('images' => $image));
					$response['msg'] 		 = 'New Listing Added!';
				}
				
				unset($_POST);
				$id_list = $this->ListingModel->insert($data_to_insert);
				$response['status'] = true;	
				$this->session->set_flashdata('notify',$response);
				redirect('user/listings');

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
			}
		
		}else{
			$response['status'] = false;
			$response['msg'] = 'Invalid Request!';
		}

		if(IS_AJAX){
			echo json_encode($response);
			exit;
		}else{
			return $response;
		}	

	}
	//RANSOM FUNCTIONS
	public function validate_first_list($request){
		$response = array();
		if($request == 'save'){	
			$this->form_validation->set_rules('category', 'Post Category', 'callback_check_options');
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('description', 'Description', 'trim|required');
			$this->form_validation->set_rules('num_rooms', 'Number of Rooms', 'trim|required|is_natural');
			$this->form_validation->set_rules('num_bath', 'Number of Bathroom', 'trim|required|is_natural');
			$this->form_validation->set_rules('date_avail', 'Date of Availability', 'trim|required');
			$this->form_validation->set_rules('num_occu', 'Number of Occupancy', 'trim|required|is_natural');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			$this->form_validation->set_rules('state', 'State', 'trim|required');
			$this->form_validation->set_rules('city', 'City', 'trim|required');
			$this->form_validation->set_rules('minimun_stay', 'Minimum Stay', 'trim|required');
			$this->form_validation->set_rules('minimun_stay_by', 'Minimum Stay', 'trim|required');
			
			
			if($this->form_validation->run()){ 
				$datas = array(
				'category' 	=> $this->input->post('category'),
				'title' 		=> $this->input->post('title'),
				'description'=> $this->input->post('description'),
				'num_rooms' 	=> $this->input->post('num_rooms'),
				'num_bath' 	=> $this->input->post('num_bath'),
				'date_avail' 	=> $this->input->post('date_avail'),
				'parking' 	=> $this->input->post('parking'),
				'num_occu' 	=> $this->input->post('num_occu'),
				'address' 	=> $this->input->post('address'),
				'state' 	=> $this->input->post('state'),
				'city' 	=> $this->input->post('city'),
				'capital' 	=> $this->input->post('capital'),
				
				//not required
				'minimun_stay' 	=> $this->input->post('minimun_stay'),
				'minimun_stay_by'=> $this->input->post('minimun_stay_by')
			);
			 $this->session->set_userdata($datas);
			// $this->session->keep_flashdata($datas);
			redirect(base_url('user/add_listing_2'));
			
			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		}else{
			//$response['status'] = false;
			//$response['msg'] = 'Invalid Request!';
			show_404();
		}
		if(IS_AJAX){
			echo json_encode($response);
			exit;
		}else{
			return $response;
		}	
	}
	//END RANSOM FUNCTION
	public function save_list($request){
		$response = array();
		if($request == 'save'){	
			$this->form_validation->set_rules('price', 'Price', 'trim|required');
			$this->form_validation->set_rules('price_by', 'Price By', 'trim|required');
			$this->form_validation->set_rules('location', 'location', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$category 	= $this->session->userdata('category');
				$title 		= $this->session->userdata('title');
				$description= $this->session->userdata('description');
				$num_rooms 	= $this->session->userdata('num_rooms');
				$num_bath 	= $this->session->userdata('num_bath');
				$date_avail = $this->session->userdata('date_avail');
				$num_occu 	= $this->session->userdata('num_occu');
				$price 		= $this->input->post('price');
				$price_by 	= $this->input->post('price_by');
				$address 	= $this->input->post('location');
				$state 		= $this->session->userdata('state');
				$city 		= $this->session->userdata('city');
				$capital 	= $this->session->userdata('capital');

				$arr = explode(",", $state);
				$location = array('address'=>ucfirst($address), 'state'=>array('abbrev'=>$arr[0], 'name'=>$arr[1]), 'city'=>$city, 'capital'=>$capital);
				//not required
				$allowed 		= $this->input->post('allowed');
				$parking 		= $this->session->userdata('parking');
				$bills_included = $this->input->post('billsinclude');
				$minimun_stay 	= $this->session->userdata('minimun_stay');
				$minimun_stay_by= $this->session->userdata('minimun_stay_by');
				$requirements 	= $this->input->post('requirements');
				
				$minimu_stay 	= array('minimun_stay'=>$minimun_stay,'minimun_stay_by'=> $minimun_stay_by);
				$final_more_options = array(
										'number_of_rooms' 	  => $num_rooms,
										'number_of_bathrooms' => $num_bath,
										'number_of_occupancy' => $num_occu,
										'parking'			  => $parking
									);
									
				$final_price = array('amount'=> $price,'price_by'=> $price_by,'included'=> $bills_included);

				if($_FILES['photo']['name'] != 0){

					$no_of_files = sizeof($_FILES['photo']['tmp_name']);
					$sub_type = $this->session->userdata('user_info')->subscription_type;

					if($no_of_files > 6 && $sub_type == 0){
						
							
						$response['status'] = false;
						$response['msg'] = 'Image was not Uploaded. Maximum allowed photos is (6). You must upgrade to upload more files. <a href="'.base_url('subscribe').'">Click here</a> to subscribe.';
						//echo json_encode($response);			

					}elseif(($no_of_files <= 6 && $sub_type == 0) || ($sub_type == 1)){
						$this->load->library('upload');
						$myStr = $this->session->userdata('user_info')->first_name;
						$key = mb_substr($myStr, 0, 3);
						for ($i=0; $i < sizeof($_FILES['photo']['name']); $i++) {
							$_FILES['userfile']['name']     = $_FILES['photo']['name'][$i];
							$_FILES['userfile']['type']     = $_FILES['photo']['type'][$i];
							$_FILES['userfile']['tmp_name'] = $_FILES['photo']['tmp_name'][$i];
							$_FILES['userfile']['error']    = $_FILES['photo']['error'][$i];
							$_FILES['userfile']['size']     = $_FILES['photo']['size'][$i];

							$config = array(
								'file_name'     => $key.date('ymdhis'),
								'allowed_types' => 'jpg|jpeg|png|gif',
								'max_size'      => 9000,
								'overwrite'     => FALSE,
								'max_width'		=> 1000,
								'max_height'	=> 768,
								'upload_path'	=> 'uploads/listing'
							);
							$this->upload->initialize($config);

							if ( !$this->upload->do_upload('userfile')) :
								$error = $this->upload->display_errors();
								$response['status'] = false;
								$response['msg'] = $error;
								$image_check = false;
								break;

							else :

							$image[] = $this->upload->data('file_name'); 
							// Continue processing the uploaded data

							endif;
						}
						
					}				    		
				}

				$data_to_insert = array(
					'id_user' 		=> $this->session->userdata('user_info')->id,
					'category' 		=> $category,
					'title_for' 	=> ucfirst($title),
					'post_type' 	=> 'property',
					'about_describ' => ucfirst($description),
					'location' 		=> serialize($location),
					//'price' 		=> serialize($price),
					'avail_movein' 	=> $date_avail,
					'more_options' 	=> serialize($final_more_options),
					'allowed'	   	=> serialize($allowed),
					'price' 	   	=> serialize($final_price),
					'required'	  	=> $requirements,
					'stay_length' 	=> serialize($minimu_stay),
					'is_premium'	=> 0,
					'date_added'   	=> $this->getCurrentDateTime(),
					'date_updated' 	=> $this->getCurrentDateTime()
				);

				if($request == 'save'):
					$data_to_insert['media'] = serialize(array('images' => ''));
					$response['msg'] = 'New Listing Added! Please add photos to your listing.';
				else:
					$response['msg'] = 'Listing Updated! Please add photos to your listing.';
				endif;

				if(count($image) > 0 && $image_check == true){
					$data_to_insert['media'] = serialize(array('images' => $image));
					$response['msg'] 		 = ($request == 'save' ? 'New Listing Added!' : 'Listing Updated!');
				}
				
				unset($_POST);

				if($request == 'save'):
					
					$id_list = $this->ListingModel->insert($data_to_insert);
					$response['status'] = true;	
					$this->session->set_flashdata('notify',$response);
					redirect('user/listings');
				else:
					$ids = explode('_',$uid);
					$id_list = $this->ListingModel->update($data_to_insert, array('id_list' =>$ids[1], 'id_user'=>$ids[0]));
					$response['status'] = true;	
					$this->session->set_flashdata('notify',$response);
					redirect('user/listings');
				endif;

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		}else{
			//$response['status'] = false;
			//$response['msg'] = 'Invalid Request!';
			show_404();
		}

		if(IS_AJAX){
			echo json_encode($response);
			exit;
		}else{
			return $response;
		}	

	}

	public function update_list($request){
		$response = array();
		if($request == 'update'){	
			$this->form_validation->set_rules('listing_id', 'Listing ID', 'trim|required');

			$this->form_validation->set_rules('category', 'Post Category', 'callback_check_options');
			$this->form_validation->set_rules('title', 'Title', 'trim|required');
			$this->form_validation->set_rules('description', 'Description', 'trim|required');
			$this->form_validation->set_rules('num_rooms', 'Number of Rooms', 'trim|required|is_natural');
			$this->form_validation->set_rules('num_bath', 'Number of Bathroom', 'trim|required|is_natural');
			$this->form_validation->set_rules('date_avail', 'Date of Availability', 'trim|required');
			$this->form_validation->set_rules('num_occu', 'Number of Occupancy', 'trim|required|is_natural');
			$this->form_validation->set_rules('address', 'Address', 'trim|required');
			$this->form_validation->set_rules('state', 'State', 'trim|required');
			$this->form_validation->set_rules('city', 'City', 'trim|required');
			$this->form_validation->set_rules('minimun_stay', 'Minimum Stay', 'trim|required');
			$this->form_validation->set_rules('minimun_stay_by', 'Minimum Stay', 'trim|required');

			$this->form_validation->set_rules('price', 'Price', 'trim|required');
			$this->form_validation->set_rules('price_by', 'Price By', 'trim|required');
			
			$image = array();
			$image_check = true;
			if($this->form_validation->run()){ 
				$listing_id = $this->input->post('listing_id');
				$category 	= $this->input->post('category');
				$title 		= $this->input->post('title');
				$description= $this->input->post('description');
				$num_rooms 	= $this->input->post('num_rooms');
				$num_bath 	= $this->input->post('num_bath');
				$date_avail = $this->input->post('date_avail');
				$num_occu 	= $this->input->post('num_occu');
				$price 		= $this->input->post('price');
				$price_by 	= $this->input->post('price_by');
				$address 	= $this->input->post('address');
				$state 		= $this->input->post('state');
				$city 		= $this->input->post('city');
				$capital 		= $this->input->post('capital');

				$arr = explode(",", $state);
				$location = array('address'=>ucfirst($address), 'state'=>array('abbrev'=>$arr[0], 'name'=>$arr[1]), 'city'=>$city, 'capital'=>$capital);
				//not required
				$allowed 		= $this->input->post('allowed');
				$parking 		= $this->input->post('parking');
				$bills_included = $this->input->post('billsinclude');
				$minimun_stay 	= $this->input->post('minimun_stay');
				$minimun_stay_by= $this->input->post('minimun_stay_by');
				$requirements 	= $this->input->post('requirements');
				
				$minimu_stay 	= array('minimun_stay'=>$minimun_stay,'minimun_stay_by'=> $minimun_stay_by);
				$final_more_options = array(
										'number_of_rooms' 	  => $num_rooms,
										'number_of_bathrooms' => $num_bath,
										'number_of_occupancy' => $num_occu,
										'parking'			  => $parking
									);
									
				$final_price = array('amount'=> $price,'price_by'=> $price_by,'included'=> $bills_included);

				if($_FILES['photo']['name'] != 0){

					$no_of_files = sizeof($_FILES['photo']['tmp_name']);
					$sub_type = $this->session->userdata('user_info')->subscription_type;

					if($no_of_files > 6 && $sub_type == 0){
						
							
						$response['status'] = false;
						$response['msg'] = 'Image was not Uploaded. Maximum allowed photos is (6). You must upgrade to upload more files. <a href="'.base_url('subscribe').'">Click here</a> to subscribe.';
						//echo json_encode($response);			

					}elseif(($no_of_files <= 6 && $sub_type == 0) || ($sub_type == 1)){
						$this->load->library('upload');
						$myStr = $this->session->userdata('user_info')->first_name;
						$key = mb_substr($myStr, 0, 3);
						for ($i=0; $i < sizeof($_FILES['photo']['name']); $i++) {
							$_FILES['userfile']['name']     = $_FILES['photo']['name'][$i];
							$_FILES['userfile']['type']     = $_FILES['photo']['type'][$i];
							$_FILES['userfile']['tmp_name'] = $_FILES['photo']['tmp_name'][$i];
							$_FILES['userfile']['error']    = $_FILES['photo']['error'][$i];
							$_FILES['userfile']['size']     = $_FILES['photo']['size'][$i];

							$config = array(
								'file_name'     => $key.date('ymdhis'),
								'allowed_types' => 'jpg|jpeg|png|gif',
								'max_size'      => 9000,
								'overwrite'     => FALSE,
								'max_width'		=> 1000,
								'max_height'	=> 768,
								'upload_path'	=> 'uploads/listing'
							);
							$this->upload->initialize($config);

							if ( !$this->upload->do_upload('userfile')) :
								$error = $this->upload->display_errors();
								$response['status'] = false;
								$response['msg'] = $error;
								$image_check = false;
								break;

							else :

							$image[] = $this->upload->data('file_name'); 
							// Continue processing the uploaded data

							endif;
						}
						
					}				    		
				}

				$data_to_update = array(
					'category' 		=> $category,
					'title_for' 	=> ucfirst($title),
					'post_type' 	=> 'property',
					'about_describ' => ucfirst($description),
					'location' 		=> serialize($location),
					//'price' 		=> serialize($price),
					'avail_movein' 	=> $date_avail,
					'more_options' 	=> serialize($final_more_options),
					'allowed'	   	=> serialize($allowed),
					'price' 	   	=> serialize($final_price),
					'required'	  	=> $requirements,
					'stay_length' 	=> serialize($minimu_stay),
					'is_premium'	=> 0,
					'date_updated' 	=> $this->getCurrentDateTime()
				);

				$response['msg'] = 'Listing Updated! Please add photos to your listing.';
				
				if(count($image) > 0 && $image_check == true){
					$data_to_update['media'] = serialize(array('images' => $image));
					$response['msg'] 		 = ($request == 'save' ? 'New Listing Added!' : 'Listing Updated!');
				}
				
				unset($_POST);

				$this->ListingModel->update_listing($listing_id, $data_to_update);
				$response['status'] = true;	
				$this->session->set_flashdata('notify',$response);
				redirect('user/listings');

			}else{
				$response['status'] = false;
				$response['value']	= $_POST;
				$response['msg'] = validation_errors();
				
			}
		
		}else{
			//$response['status'] = false;
			//$response['msg'] = 'Invalid Request!';
			show_404();
		}

		if(IS_AJAX){
			echo json_encode($response);
			exit;
		}else{
			return $response;
		}	

	}
	public function delete_listing($listing_id){
		return $this->ListingModel->delete_listing($listing_id);
	}

	public function fileUpload($id_list){
		$response = array();	
		$cover = 0;
		for ($i=0; $i < sizeof($_FILES['photo']['tmp_name']); $i++) {
			$myStr = $this->session->userdata('user_info')->first_name;
			$result = mb_substr($myStr, 0, 3);
			$filenewname = $result.date('ymdhis');
			$valid_ext = array('jpg', 'jpeg', 'bmp', 'gif', 'png');
			$file_size = $_FILES['photo']['size'][$i];

			$filename = trim(str_replace(' ','_', $_FILES['photo']['name'][$i]));
			$prev_name = explode('.', $filename);
			$ext = strtolower(end($prev_name));
			$new_name = $filenewname.'.'.$ext; 

			$upload_path = 'uploads/listing/';
			$image_path = $upload_path;

			
			// if(!is_dir($image_path)){	
			// 	mkdir($image_path);
			// }
				
			if(in_array($ext, $valid_ext)){
				if($file_size < 2097152){

					if(move_uploaded_file($_FILES['photo']['tmp_name'][$i], $image_path.$new_name)){

							$image_details = array(
								'id_list' => $id_list,
								'cover' => $cover == $i ? '1' : '0',
								'photo_name' => $new_name,
								'photo_path' => $upload_path,
								'date_added' => $this->getCurrentDateTime(),
								'date_updated' => $this->getCurrentDateTime()
							);
						
						$this->listing_model->insertRow('photos', $image_details);						
					}				
				}
			}else{

			}				
		}	
		return true;
	}

	public function getListings($where = ''){
		if(is_array($where) && count($where) > 0){
			return $this->ListingModel->getlistings($where);
		}else{
			return $this->ListingModel->getlistings();
		}
	}

	public function getListing($where = ''){
		return $this->ListingModel->getlisting($where);
	}

	public function check_options($choice){

		$this->load->module('category/category');	
		$categories_ids = $this->category->getCategoryIDs(); 
		$options = array();

		foreach($categories_ids as $val):
			$options[] = $val['cat_id'];
		endforeach;

		if(in_array($choice, $options)){
			return true;
		}else{
			$this->form_validation->set_message('check_options', 'You need to select a Category');
			return false;
		}


	}
	public function check_id($id){

	}
	//RANSOM FUNCTIONS
	public function getUserByListingID($listing_id){
		return $this->ListingModel->getUserByListingID($listing_id);
	}
	public function filter($category, $state, $search){
		return $this->ListingModel->search_filter($category, $state, $search);
	}
	public function cities_filter($cities){
		return $this->ListingModel->cities_filter($cities);
	}
	public function category_filter($category){
		return $this->ListingModel->category_filter($category);
	}
	public function related_filter($category, $state, $search){
		$search_arr = explode(" ", $search);
		return $this->ListingModel->related_search_filter($category, $state, $search_arr);
	}
	//END RANSOM FUNCTION
}

