<?php
class ListingModel extends MY_Model{

	public $table = 'listings';

	function __construct(){
		parent::__construct();
	}

	function getLastListing($id_user, $id_list){
		
		$this->db->where('id_user', $id_list);
		$this->db->where('id_user', $id_user);
		$query = $this->db->get('list');
		
		if($query->row()){
			return $query->row();
		}else{
			return false;
		}
	}

	function getlistings($where = ''){
		$this->db->select('*');
   		$this->db->from('listings a'); 
		$this->db->join('categories b', 'b.cat_id=a.category', 'left');

		if(is_array($where) && count($where) > 0){
			$this->db->where($where);
		}

		$query = $this->db->get(); 
		
		if($query->num_rows() > 0)
		{
			return $query->result();
		}
		else
		{
			return false;
		}
	}

	
	function getlisting($where = ''){
		/*$this->db->select('*');
   		$this->db->from('listings a'); 
		$this->db->join('categories b', 'b.cat_id=a.category', 'left');
		$this->db->where($where);*/
		$fw = '';
		if(is_array($where)){
			$st = true;
			foreach($where as $key => $val){
				if($st){
					$fw = 'WHERE '. $key .'="'. $val.'"';
					$st = false;
				}else{
					$fw .= ' AND '.$key .'="'. $val.'"';
				}
			}
		}else{
			$fw = $where;
		}

		$sql = "SELECT * FROM listings as a LEFT JOIN categories as b ON b.cat_id=a.category ".$fw;
		$query = $this->db->query($sql);
		
		return ($query->num_rows() == 1) ? $query->row() : false;
		
	}
	public function getUserByListingID($listing_id){
		$this->db->select('*');
   		$this->db->from('users u'); 
		$this->db->join('listings l', 'l.id_user=u.id', 'inner');
		$this->db->where('l.id_list', $listing_id);
		$query = $this->db->get('listings');
		
		if($query->row()){
			return $query->row();
		}else{
			return false;
		}
	}
	public function update_listing($listing_id, $data){
		$this->db->where('id_list',$listing_id);
        $this->db->update('listings',$data);
	}
	public function delete_listing($listing_id){
		$this->db->where('id_list',$listing_id);
        $this->db->delete('listings');
        ($this->db->affected_rows() > 0 ? true: false);
	}
	public function cities_filter($cities){
		$this->db->select('*');
   		$this->db->from('categories c'); 
		$this->db->join('listings l', 'l.category=c.cat_id', 'inner');
		$this->db->like('l.location', $cities);
		$query = $this->db->get();

		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	public function category_filter($category){
		$this->db->select('*');
   		$this->db->from('categories c'); 
		$this->db->join('listings l', 'l.category=c.cat_id', 'inner');
		$this->db->like('l.category', $category);
		$query = $this->db->get();

		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	public function search_filter($category, $state, $search){
		
		// $this->db->select('*');
  //  		$this->db->from('categories c'); 
		// $this->db->join('listings l', 'l.category=c.cat_id', 'inner');
		// $this->db->where('l.category', $category);
		// $this->db->like('l.location', $state);
		// $query = $this->db->get();

		$search_arr = explode(" ", $search);
		$arr_search = "";
		$loc = "%".$state."%";
		$sql = "SELECT * FROM listings as a inner JOIN categories as b ON b.cat_id=a.category WHERE a.category = ? and a.location LIKE ? and a.title_for LIKE ?";
				
			for($i=0;$i<count($search_arr);$i++){
				$arr_search .= "%".$search_arr[$i]."%";
				
			}
			$query = $this->db->query($sql, array($category, $loc, $arr_search));
				if($query->num_rows() > 0){
					return $query->result();
				}else{
					return false;
				}
		
		
	}
	public function related_search_filter($category, $state, $search){
		$loc = "%".$state."%";
		$sql = "SELECT * FROM listings as a inner JOIN categories as b ON b.cat_id=a.category WHERE a.category = ? or a.location LIKE ? or b.cat_name LIKE ? or a.title_for LIKE ? or a.about_describ LIKE ? or a.location LIKE ? or a.allowed LIKE ? ";
				
			for($j=0;$j<count($search);$j++){
				$arr_search = "%".$search[$j]."%";
				$query = $this->db->query($sql, array($category, $loc, $arr_search, $arr_search, $arr_search, $arr_search, $arr_search));
			}
			
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	public function attr($attr){
		$sql = "SELECT * FROM listings as a inner JOIN categories as b ON b.cat_id=a.category WHERE a.category = ? and a.location LIKE ? and ".$attr;
		return $sql;
	}
	public function query($sql, $category, $loc, $search){
		$arr_search = "%".$search."%";
		$query = $this->db->query($sql, array($category, $loc, $arr_search));
		
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}

}

?>