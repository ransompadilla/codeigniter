<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Messages extends MY_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('messages_model');
    }

	public function index(){
		show_404();
	}

	public function user_messages($user_info){
		//$user_info = $this->user->userAuth();
		$getwanted['id_user'] 	= $user_info->id;
		$getwanted['post_type']	= 'searcher';
		$this->load->module('listing/listing');	

		$a_data = array(
			's_navcurrent'	=> 'messages',
			'pagename'		=> 'Messages',
			'mywanted' 		=> $this->listing->getListing($getwanted) 
		);

		// $this->mybreadcrumb->add('Home', base_url());
		// $this->mybreadcrumb->add('Dashboard', base_url('dashboard'));
		// $this->mybreadcrumb->add('Add Listing', base_url('listing'));
		// $data['breadcrumbs'] = $this->mybreadcrumb->render();
		 
	
		$this->dash_display('messages',$a_data);

	}
	//RANSOM FUNCTIONS
	public function chat(){
		$this->load->module('chat/chat');	
		redirect('chat');
	}
	public function getChatMessages($id){
		return $this->messages_model->getChatMessages($id);
	}
	public function getUnreadMessages($id){
		return $this->messages_model->getUnreadMessages($id);
	}

}
