<script type="text/javascript" src="<?php echo base_url();?>assets/scripts/chatjs.js"></script>

</body>
</html>