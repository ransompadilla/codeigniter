<h1>CodeIgniter Sign In With Google Account</h1>
<a href="<?php echo $loginURL; ?>"><img src="<?php echo base_url().'assets/images/glogin.png'; ?>" /></a>