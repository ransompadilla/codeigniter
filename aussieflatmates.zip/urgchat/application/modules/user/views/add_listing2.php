<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2>Add Listing</h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li><a href="<?php echo site_url('user/dashboard'); ?>">Dashboard</a></li>
                    <li>Add Listing</li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!-- form open-->
            <?php echo form_open_multipart(site_url('user/add-listing-2'), array('id'=>'listingni1')); ?>
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if(isset($notify) && $notify != '' ){
                            //$notify = $this->session->flashdata('notify');
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                   <!--  <h3><i class="sl sl-icon-doc"></i> Basic Informations</h3> -->
                </div>
<!-- 
                <div style="width: 100%; height: 100%;">
                	<?php echo $maps['js'];?>
                	<?php echo $maps['html'];?>
                </div> -->
         		<input type="hidden" name="location" id="location" value="<?php echo $this->session->userdata('address');?>">
            <!-- Section -->
            <?php if(is_array($options) && count($options) > 0): ?>
            <div class="add-listing-section margin-top-45">
                            
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-book-open"></i> Additional Details</h3>

                    <!-- Switcher -->
                <!--  <label class="switch"><input type="checkbox" checked><span class="slider round"></span></label> -->
                </div>

                <!-- Row -->
                <div class="row with-forms">
                    <div class="col-md-12">
                        <h5 class="margin-top-30 margin-bottom-10">Options <span>(optional)</span></h5>
                        
                        <div class="checkboxes in-row margin-bottom-20">
                            <?php 
                            $ctr = 0;
                            foreach($options as $val): 
                            $ctr++;
                            ?>
                                <input id="option-<?php echo $ctr; ?>" type="checkbox" name="allowed[]" value="<?php echo $val->mo_name; ?>">
                                <label for="option-<?php echo $ctr; ?>"><?php echo $val->mo_name; ?></label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                </div>
                <!-- Row / End -->

            </div>
            <?php endif; ?>
            <!-- Section / End -->

            <!-- Section -->
            <div class="add-listing-section margin-top-45">
                
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-book-open"></i> Pricing</h3>
                    <!-- Switcher -->
                   <!--  <label class="switch"><input type="checkbox" checked><span class="slider round"></span></label> -->
                </div>

                <!-- Row -->
                <div class="row with-forms">
                    <div class="col-md-4">
                        <h5>Rate </h5>
	                    <div class="fm-input pricing-price">
                            <input type="text" placeholder="Price" data-unit="AUD" name="price">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h5>&nbsp;</h5>
                        <select name="price_by" class="chosen-select">
                            <option value="day">per day</option>
                            <option value="night">per night</option>
                            <option value="week">per week</option>
                            <option value="month">per month</option>
                        </select>
                    </div>
                    <div class="col-md-12">
                        <h5 class="margin-top-30 margin-bottom-10">Bills included: <span>(optional)</span></h5>
                        <div class="checkboxes in-row margin-bottom-20">
                                <input id="check-1" type="checkbox" name="billsinclude[]" value="electricity">
                                <label for="check-1">Electricity</label>
                                
                                <input id="check-2" type="checkbox" name="billsinclude[]" value="water">
                                <label for="check-2">Water</label>
                                
                                <input id="check-3" type="checkbox" name="billsinclude[]" value="gas">
                                <label for="check-3">Gas </label>
                                
                                <input id="check-4" type="checkbox" name="billsinclude[]" value="internet">
                                <label for="check-4">Internet</label>
                        </div>
                    </div>

                </div>
                <!-- Row / End -->

            </div>
            <!-- Section / End -->


            <!-- Section -->
            <div class="add-listing-section margin-top-45">
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-location"></i>Requirements</h3>
                </div>

                <div class="submit-section">

                    <!-- Row -->
                    <div class="row with-forms">

                        <!-- Address -->
                        <div class="col-md-12">
                            <h5>Documents requirements:</h5>
                            <textarea name="requirements"></textarea>
                        </div>

                    </div>
                    <!-- Row / End -->
                </div>
            </div>
            <!-- Section / End -->            

            <!-- Section -->
            <div class="add-listing-section margin-top-45">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-picture"></i> Images</h3>
                    <p><i>1000px x 768px maximum photos to upload.</i></p>
                </div>
                <div class="submit-section">                    
                   <input id="file-input" type="file" multiple="multiple" name="photo[]">
                    <div id="preview"></div>
                </div>

            </div>
            <!-- Section / End -->

            <div class="margin-top-45">
                <button class="button preview" type="submit">SUBMIT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            
        </div>
        <?php echo form_close(); ?>
            <!--  form  -->
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
    </div>

    <!-- Copyrights -->
    <?php include 'inc/copyrights.php'; ?>

</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);

</script>