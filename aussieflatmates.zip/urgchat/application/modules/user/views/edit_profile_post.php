<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2>My Wanted Listing</h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="<?php echo site_url(); ?>">Home</a></li>
                    <li><a href="<?php echo site_url('user/dashboard'); ?>">Dashboard</a></li>
                    <li>Add Listing</li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!--?php echo site_url('listing/addList'); ?-->
            <?php echo form_open_multipart(site_url('user/profile-post'), array('id'=>'listingni1')); ?>
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <div id="notify" class="notify" align="center">
                        <?php 
                        
                        if(isset($notify) && $notify != '' ){
                            //$notify = $this->session->flashdata('notify');
                            if($notify['status'] == true){
                                echo '<div class="notification success closeable">
                                    <p>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }else{
                                echo '<div class="notification error closeable">
                                    <p><span>Error! </span>'.$notify['msg'].'</p>
                                    <a class="close"></a>
                                </div>';
                            }
                        }
                        ?>
                            
                    </div>
                    <h3><i class="sl sl-icon-doc"></i> Basic Informations</h3>
                </div>

                <!-- category -->
                <!-- State -->
                <div class="row with-forms">
                    <div class="col-md-6">
                        <h5>Looking for</h5>
                        <select name="category" class="chosen-select-no-single" >
                        <?php 
                            $list_catergory = $listing->category;
                        ?>
                        <?php if(count($categories) > 0):
                                foreach($categories as $val): ?>
                                <option value="<?php echo $val->cat_id; ?>" <?php echo ($list_catergory == $val->cat_id ? 'selected' : '') ?>><?php echo ucfirst($val->cat_name); ?></option>
                        <?php   endforeach; 
                              endif; ?>
                        </select>
                    </div> 
                    <div class="col-md-6">
                        <h5>&nbsp;</h5>
                        <?php 
                            $for = $listing->title_for;
                        ?>
                        <select name="for"  class="chosen-select-no-single" >
                              <option values=""></option>
                              <option values="for me" <?php echo (strtolower($for) == 'for me'? 'selected':'') ?>>For Me</option>
                              <option values="for a couple" <?php echo (strtolower($for) == 'for a couple'? 'selected':'') ?>>For A Couple</option>
                              <option values="for a Group" <?php echo (strtolower($for) == 'for a Group'? 'selected':'') ?>>For A Group</option>
                        </select>
                    </div>
                </div> 
                <?php 
                    $more_options   = unserialize($listing->more_options);
                    $interested     = $more_options['interested_also'];
                    $is_interested  = (count($interested) > 0 ? true : false);
                    //if($listing->interested_also
                ?>
                <?php if(count($categories) > 0): ?>
                <div class="row with-forms">
                    <div class="col-md-12">
                        <h5>Interested also with:</h5>
                        <div class="checkboxes in-row margin-bottom-20">
            
                        <?php 
                            $a = 1;
                            foreach($categories as $val): ?>
                            <input id="check-<?php echo $a ?>" type="checkbox" name="room_type[]" value="<?php echo $val->cat_name ?>" <?php echo ($is_interested == true && in_array($val->cat_name,$interested) ? 'checked':'') ?>>
                            <label for="check-<?php echo $a ?>"><?php echo $val->cat_name ?></label>
                        <?php   
                            $a++;
                            endforeach; ?>
                            
                        </div> 
                    </div>
                </div> 
                <?php endif; ?>
                <div class="row with-forms" style="border-top:1px solid #eaeaea;margin-top:20px;padding-top:10px">
                    <div class="col-md-4">
                        <h5>Move Date</h5>
                        <input type="date" name="move_date" value="<?php echo $listing->avail_movein ?>">
                    </div>
                    <div class="col-md-4">
                        <h5>Preferred Stay Length</h5>
                        <?php $stay_length = unserialize($listing->stay_length);
                        ?>
                        <input type="number" name="length_stay" value="<?php echo $stay_length['length_stay'] ?>">
                    </div>
                    <div class="col-md-4">
                        <h5>&nbsp;</h5>
                        <select name="length_stay_by" >
                            <option value="">select</option>
                            <option value="day(s)" <?php echo ($length_stay_by == 'day(s)' ? 'selected' : '')?>>day(s)</option>
                            <option value="night(s)" <?php echo ($length_stay_by == 'night(s)' ? 'selected' : '')?>>night(s)</option>
                            <option value="week(s)" <?php echo ($length_stay_by == 'week(s)' ? 'selected' : '')?>>week(s)</option>
                            <option value="month(s)" <?php echo ($length_stay_by == 'month(s)' ? 'selected' : '')?>>month(s)</option>
                            <option value="year(s)" <?php echo ($length_stay_by == 'year(s)' ? 'selected' : '')?>>year(s)</option>
                        </select>
                    </div>
                </div>
            </div>
            <!-- Section / End -->


              <!-- Section -->
            <div class="add-listing-section margin-top-45">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-docs"></i> About You</h3>
                </div>

                <!-- Description -->
                <div class="form">
                    <h5>Profile Description</h5>
                    <textarea class="WYSIWYG" name="description" cols="40" rows="3" id="summary" spellcheck="true"><?php echo $listing->about_describ ?></textarea>
                </div>                       
               

                

            </div>
            <!-- Section / End -->

            <!-- Section -->
            <div class="add-listing-section margin-top-45">
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-location"></i>More Details</h3>
                </div>

                    <!-- Row -->
                    <div class="row with-forms">

                        <!-- Address -->
                        <div class="col-md-12">
                            <h5>Preferred location</h5>
                            <input name="address" type="text" value="<?php echo $listing->location; ?>" placeholder="e.g. 964 School Street">
                        </div>
                        
                        <!-- Checkboxes -->
                        <div class="col-md-12">
                            <div class="checkboxes in-row margin-bottom-20">
                                <?php 
                                $allowed = unserialize($listing->allowed);
                                $ctr = 0;
                                foreach($options as $val): 
                                $ctr++;
                                ?>
                                    <input id="option-<?php echo $ctr; ?>" type="checkbox" name="allowed[]" value="<?php echo $val->mo_name; ?>" <?php echo (in_array($val->mo_name , $allowed) ? 'checked' : '') ?>>
                                    <label for="option-<?php echo $ctr; ?>"><?php echo ucfirst($val->mo_name); ?></label>
                                <?php endforeach; ?>
                            </div>
                        </div>
                        <!-- Checkboxes / End -->

                    </div>
                    <!-- Row / End -->
            </div>
            <!-- Section / End -->   

            <!-- Section -->
            <div class="add-listing-section margin-top-45">
                
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-book-open"></i> Pricing</h3>
                    <!-- Switcher -->
                   <!--  <label class="switch"><input type="checkbox" checked><span class="slider round"></span></label> -->
                </div>

                <!-- Row -->
                <?php $price = unserialize($listing->price); ?>
                <div class="row with-forms">
                    <div class="col-md-4">
                        <h5>Minimum Rent  </h5>
                        <div class="fm-input pricing-price">
                            <input name="min_price" type="text" value="<?php echo $price['min_amount'] ?>" data-unit="AUD">
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h5>Maximum Rent  </h5>
                        <div class="fm-input pricing-price">
                            <input name="max_price" type="text" value="<?php echo $price['max_amount']  ?>" data-unit="AUD" >
                        </div>
                    </div>
                    <div class="col-md-4">
                        <h5>&nbsp;</h5>
                        <select name="price_by">
                            <option value="day" <?php echo ($price['price_by'] == 'day' ? 'selected' : '' ); ?>>per day</option>
                            <option value="night" <?php echo ($price['price_by'] == 'night' ? 'selected' : '' ); ?>>per night</option>
                            <option value="week" <?php echo ($price['price_by'] == 'week' ? 'selected' : '' ); ?>>per week</option>
                            <option value="month" <?php echo ($price['price_by'] == 'month' ? 'selected' : '' ); ?>>per month</option>
                        </select>
                    </div>
                </div>
                <!-- Row / End -->

            </div>
            <!-- Section / End -->


            <!-- Section -->
            <div class="add-listing-section margin-top-45">
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-location"></i>Requirements</h3>
                </div>

                <!-- Row -->
                <div class="row with-forms">

                    <!-- Address -->
                    <div class="col-md-12">
                        <h5>Documents requirements:</h5>
                        <textarea name="requirements"><?php echo $listing->required; ?></textarea>
                    </div>

                </div>
                <!-- Row / End -->
            </div>
            <!-- Section / End --> 

            
            <!-- Section -->
            <div class="add-listing-section margin-top-45">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-picture"></i>Cover Photo</h3>
                    <p><i>1000px x 768px maximum photos to upload.</i></p>
                </div>
                <div class="submit-section">
                    <input id="file-input" type="file" name="photo">
                    <div id="preview"></div>
                </div>

            </div>
            <!-- Section / End -->

            <div class="margin-top-45">
                <button class="button preview" type="submit">SUBMIT<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            <?php echo form_close(); ?>
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
        </div>
    </div>

    <!-- Copyrights -->
    <?php include 'inc/copyrights.php'; ?>

</div>
<script type="text/javascript">
    function previewImages() {

        var $preview = $('#preview').empty();
        if (this.files) $.each(this.files, readAndPreview);

        function readAndPreview(i, file) {

            if (!/\.(jpe?g|png|gif)$/i.test(file.name)){
              return alert(file.name +" is not an image");
            } // else...

            var reader = new FileReader();

            $(reader).on("load", function() {
              $preview.append($("<img/>", {src:this.result, height:100}));
            });

            reader.readAsDataURL(file);
        }

    }

    $('#file-input').on("change", previewImages);

</script>