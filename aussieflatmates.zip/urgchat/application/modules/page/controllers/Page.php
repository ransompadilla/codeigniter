<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Page extends MY_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('page_model');
        $this->load->module('listing/listing');
        $this->load->module('category/category');
		$this->load->module('options/options');	
    }

	public function index($page=''){
	    
		if($page === ''){
			$a_data = array(
				's_navcurrent'	=> 'home',
				'pagename'		=> 'Home'
			);
			
			$a_data['categories'] = $this->category->getCategories(); 

			$this->pg_display('main',$a_data);
		}else{
			redirect($page);
		}
	}

	public function about(){
		$a_data = array(
			's_navcurrent'	=> 'about',
			'pagename'		=> 'About'
		);
		$this->pg_display('about',$a_data);
	}

	public function listings(){
		$a_data = array(
			's_navcurrent'	=> 'listings',
			'pagename'		=> 'Listings'
		);
		$a_data['categories'] = $this->category->getCategories(); 
		if(isset($_GET['cities'])){
			$a_data['listings'] = $this->listing->cities_filter($_GET['cities']); 
			$a_data['related'] = "";
		}
		else if(isset($_GET['category']) && !isset($_GET['state']) || !isset($_GET['search'])){
			$a_data['listings'] = $this->listing->category_filter($_GET['category']); 
			$a_data['related'] = "";
		}
		else if(isset($_GET['category']) || isset($_GET['state']) || isset($_GET['search'])){
			$a_data['listings'] = $this->listing->filter($_GET['category'], $_GET['state'], $_GET['search']); 
			$a_data['related'] = $this->listing->related_filter($_GET['category'], $_GET['state'], $_GET['search']); 
		}
		else{
			$a_data['related'] = "";
			$a_data['listings'] = $this->listing->getListings();
		}
		
		$a_data['u_info'] = ''; 
		$this->pg_display('listings',$a_data);
	}

	public function listing($id){ 
		$from = $this->session->userdata('user_info')->id;
		$list_id=$id;
		if(!is_numeric($id)){
			show_404();
		}
		if(!$this->session->userdata('user_info')){
			redirect('opps');
		}
		$a_data = array(
			's_navcurrent'	=> 'listings',
			'pagename'		=> 'Listings'
		);
		
		$id = array('id_list' => $id);
		$a_data['listing'] = $this->listing->getlisting($id);

		$location = unserialize($a_data['listing']->location);

		$a_data['u_info'] = $this->listing->getUserByListingID($list_id); 
		$this->load->module('chat/chat');
		$a_data['chat_convo'] = $this->chat->getChatIndivConvo($from, $a_data['u_info']->id);

		if($a_data['listing'] == '' ){
			show_404();
		}


		$a_data['options'] = $this->options->getOptions(); 

		$a_data['categories'] 	= $this->category->getCategories(); 
		$a_data['list_id'] 		= $id;
		// ---- MAP PART --- //
		
		$this->load->library('googlemap_api');
		$complate_add = $location['address'].", ".$location['city'].", ".$location['state']['name'];
		//if(isset($_GET['sensor'])!=""){
			$config['center'] = $complate_add;
			$config['zoom'] = 15;
			$this->googlemap_api->initialize($config);

			$marker = array();
			$marker['position'] = $complate_add;
			$this->googlemap_api->add_marker($marker);
			
			$a_data['maps'] = $this->googlemap_api->create_map();

		//}
		

		if($a_data['listing']->post_type == 'property'){
			$this->pg_display('property-list',$a_data);
		}elseif($a_data['listing']->post_type == 'searcher'){
			$this->pg_display('profile-list',$a_data);
		}else{
			show_404();
		}
		
	}
	public function pricing(){
		$a_data = array(
			's_navcurrent'	=> 'pricing',
			'pagename'		=> 'Pricing'
		);
		$this->pg_display('pricing',$a_data);
	}
	public function contact(){
		$a_data = array(
			's_navcurrent'	=> 'contact',
			'pagename'		=> 'Contact'
		);
		$this->pg_display('contactpage',$a_data);
	}
	public function terms_conditions(){
		$a_data = array(
			's_navcurrent'	=> 'terms-conditions',
			'pagename'		=> 'Terms and Conditions'
		);
		$this->pg_display('terms-conditions',$a_data);
	}

	public function signup(){
		$a_data = array(
			's_navcurrent'	=> 'signup',
			'pagename'		=> 'Register'
		);
		$this->pg_display('signup',$a_data);
	}
	public function signin(){
		$a_data = array(
			's_navcurrent'	=> 'signin',
			'pagename'		=> 'Login'
		);
		$this->pg_display('signin',$a_data);
	}
}

