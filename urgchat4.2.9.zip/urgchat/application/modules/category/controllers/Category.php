<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Category extends MY_Controller {
    public function __construct(){
        parent::__construct();
        
        $this->load->model('CategoryModel');
    }

    public function index(){
        //return $this->CategoryModel->getAll();
    }
    
    public function getCategories(){
        return $this->CategoryModel->getAll();
    }
    public function getCategoryIDs(){
        return $this->CategoryModel->getIDs();
    }
}