<?php defined('BASEPATH') OR exit('No direct script access allowed');

class CategoryModel extends My_Model{
        public $table = 'categories';

        
	function getIDs(){
		$this->db->select('cat_id');
		$this->db->from($this->table);
		$query = $this->db->get(); 
		return $query->result_array();
	}
}