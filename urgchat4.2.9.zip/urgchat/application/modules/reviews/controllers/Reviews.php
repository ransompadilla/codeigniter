<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reviews extends MY_Controller {

	public function __construct(){
        parent::__construct();
    }

	public function index(){
		$a_data = array(
			's_navcurrent'	=> 'reviews',
			'pagename'		=> 'Reviews'
		);

		// $this->mybreadcrumb->add('Home', base_url());
		// $this->mybreadcrumb->add('Dashboard', base_url('dashboard'));
		// $this->mybreadcrumb->add('Add Listing', base_url('listing'));
		// $data['breadcrumbs'] = $this->mybreadcrumb->render();
		 
	
		$this->dash_display('reviews',$a_data);

	}



}
