<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Plan extends MY_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->library('paypal_lib');
       // $this->load->module('user/user');
        $this->load->model('Plan_Model');
    }
    function pay($plan_id){

    	
        // Set variables for paypal form
        $returnURL = base_url().'plan/paypal/success'; //payment success url
        $cancelURL = base_url().'pricing'; //payment cancel url
        $notifyURL = base_url().'plan/paypal/ipn'; //ipn url
        
        // Get product data
        $plan = $this->Plan_Model->getPlan($plan_id);
        
        // Get current user ID from session
        $userID = $this->session->userdata('user_info')->id;
        
        // Add fields to paypal form
        $this->paypal_lib->add_field('return', $returnURL);
        $this->paypal_lib->add_field('cancel_return', $cancelURL);
        $this->paypal_lib->add_field('notify_url', $notifyURL);
        $this->paypal_lib->add_field('item_name', $plan->plan_category);
        $this->paypal_lib->add_field('custom', $userID);
        $this->paypal_lib->add_field('item_number',  $plan->plan_id);
        $this->paypal_lib->add_field('amount',  $plan->price);
        
        // Load paypal form
        $this->paypal_lib->paypal_auto_form();
    }
}