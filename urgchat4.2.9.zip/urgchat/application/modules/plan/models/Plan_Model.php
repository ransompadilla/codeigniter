<?php
class Plan_Model extends MY_Model{
	function __construct(){
		parent::__construct();
	}
	function getPlan($plan_id){
		$result = $this->db->get_where('plan', array('plan_id'=>$plan_id));
		if($result->num_rows() > 0){return $result->row();}
		else{return false;}
	}
	// Insert transaction data
    public function insertTransaction($data = array()){
        $insert = $this->db->insert('plan_payments',$data);
        return $insert?true:false;
    }
}
?>