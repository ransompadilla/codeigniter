<!-- Titlebar -->
<div id="titlebar">
    <div class="row">
        <div class="col-md-12">
            <h2>Subscribe</h2>
            <!-- Breadcrumbs -->
            <nav id="breadcrumbs">
                <ul>
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Dashboard</a></li>
                    <li>Add Listing</li>
                </ul>
            </nav>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-lg-12">
        <div id="add-listing">            
            
            <!--?php echo site_url('listing/addList'); ?-->
            <form action="" method="post" enctype="multipart/form-data" id="listingni">
            <!-- Section -->
            <div class="add-listing-section">

                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-doc"></i>Personal Details</h3>
                </div>

                <!-- category -->
                <!-- State -->
                <div class="row with-forms">
                    <div class="col-md-6">
                        <label>First Name</label>
                        <input type="text" value="">
                    </div>

                    <div class="col-md-6">
                        <label>Last Name</label>
                        <input type="text" value="">
                    </div>

                    <div class="col-md-6">
                        <div class="input-with-icon medium-icons">
                            <label>E-Mail Address</label>
                            <input type="text" value="">
                            <i class="im im-icon-Mail"></i>
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="input-with-icon medium-icons">
                            <label>Phone</label>
                            <input type="text" value="">
                            <i class="im im-icon-Phone-2"></i>
                        </div>
                    </div>
                </div>  
               
            </div>
            <!-- Section / End -->


              <!-- Section -->
            <div class="add-listing-section margin-top-45">
                <!-- Headline -->
                <div class="add-listing-headline">
                    <h3><i class="sl sl-icon-docs"></i> Payment Method</h3>
                </div>

                <!-- Row -->
                <div class="row with-forms">
                    <div class="payment">

                        <div class="payment-tab payment-tab-active">
                            <div class="payment-tab-trigger">
                                <input checked id="paypal" name="cardType" type="radio" value="paypal">
                                <label for="paypal">PayPal</label>
                                <img class="payment-logo paypal" src="../../../i.imgur.com/ApBxkXU.png" alt="">
                            </div>

                            <div class="payment-tab-content">
                                <p>You will be redirected to PayPal to complete payment.</p>
                            </div>
                        </div>

                    </div>
                </div>
                <!-- Row / End -->
            </div>
            <!-- Section / End -->

            <div>
                <button class="button preview" type="submit">Confirm and Pay<i class="fa fa-arrow-circle-right"></i></button>
                <!-- <a href="#" class="button preview">Submit </a> -->
            </div>
            </form>
            <!-- =============== -->
            <!-- END FORM -->
            <!-- =============== -->
        </div>
    </div>

    <!-- Copyrights -->
    <div class="col-md-12 text-center">
        <div class="copyrights">© 2018 Listeo. All Rights Reserved.</div>
    </div>

</div>