<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Subscribe extends MY_Controller {

	public function __construct(){
        parent::__construct();
    }

	public function index(){
		$a_data = array(
			's_navcurrent'	=> 'subscribe',
			'pagename'		=> 'Subscribe'
		);

		
		 
	
		$this->dash_display('subscribe',$a_data);

	}



}
