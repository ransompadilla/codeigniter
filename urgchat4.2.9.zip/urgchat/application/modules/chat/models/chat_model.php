<?php
class Chat_Model extends MY_Model{

	public function __construct(){
		parent::__construct();
	}
	public function getUsers(){
		return $this->getallQuery('select * from users');
	}
	public function getUserToChat($id){
		return $this->getRowQuery('select * from users where id='.$id.'');
	}
	public function pushMessage($data){
		return $this->insertData('chat',$data);
	}
	public function getChatLogs(){
		return $this->getallQuery('select * from chat order by time desc');
	}
	public function getChatIndivConvo($from, $to){
		$this->db->where('from', $from);
		$this->db->where('to', $to);
		$this->db->or_where('from', $to);
		$this->db->where('to', $from);
		$query = $this->db->get('chat');
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	public function getUserToIsTyping($to){
		$this->db->where('id', $to);
		$query = $this->db->get_where('users');
		if($query->num_rows() > 0){
			return $query->row();
		}else{
			return false;
		}
	}
}
?>