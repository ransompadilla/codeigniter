<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class Chat extends MY_Controller {

	public function __construct(){
        parent::__construct();
        $this->load->model('chat_model');
    }
    function index(){
    	$data['users'] = $this->chat_model->getUsers();
    	$this->load->view('chat-box', $data);
    }
    function with($to){
        $from = $this->session->userdata('user_info')->id;
        $this->load->model('user/UserModel');
        $data['u_info'] = $this->UserModel->getUserInfo($to);
        $data['chat_convo'] = $this->chat_model->getChatIndivConvo($from, $to);
        $this->load->view('chat', $data);
    }
    function push_message(){
    	$data = array(
    		'from'		=>$this->input->post('from'),
    		'to'		=>$this->input->post('to'),
    		'message'	=>$this->input->post('message')
    	);
   		$this->chat_model->pushMessage($data);
    }
    function getChatIndivConvo($from, $to){
        return $this->chat_model->getChatIndivConvo($from, $to);
    }
    function load_chat($to, $list_id){
        $from = $this->session->userdata('user_info')->id;
        $this->load->module('listing/listing');
        if($list_id == ""){
            $data['u_info'] = $this->UserModel->getUserInfo($to);
        }
        else{
            $data['u_info'] = $this->listing->getUserByListingID($list_id);
        }
        $data['chat_convo'] = $this->chat_model->getChatIndivConvo($from, $to);
        $this->load->view('chat-box', $data);

    }
   
}
?>