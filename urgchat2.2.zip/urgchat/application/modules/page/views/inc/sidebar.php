        <!-- Sidebar
		================================================== -->
		<div class="col-lg-3 col-md-4  margin-top-75 sticky">
			<div class="sidebar">

				<!-- Widget -->
				<div class="widget margin-bottom-40">
					<h3 class="margin-top-0 margin-bottom-30">Filters</h3>

					<!-- Row -->
					<div class="row with-forms">
						<!-- Cities -->
						<div class="col-md-12">
							<input type="text" placeholder="What are you looking for?" value=""/>
						</div>
					</div>
					<!-- Row / End -->


					<!-- Row -->
					<div class="row with-forms">
						<!-- Type -->
						<div class="col-md-12">
							<select data-placeholder="All Categories" class="chosen-select" >
								<option>All Categories</option>	
								<?php 
								if(count($categories)> 0){

									foreach($categories as $val){
									?>
									<option value="<?php echo $val->cat_name ?>"><?php echo $val->cat_name ?></option>
								<?php
									}
								} ?>
								
							</select>
						</div>
					</div>
					<!-- Row / End -->


					<!-- Row -->
					<div class="row with-forms">
						<!-- Cities -->
						<div class="col-md-12">

							<div class="input-with-icon">
								<select data-placeholder="All Categories" class="chosen-select" >
									<option>Select Location</option>	
									<option value="VIC">VIC</option>	
									<option value="NSW">NSW</option>	
									<option value="QLD">QLD</option>	
									<option value="WA">WA</option>	
									<option value="SA">SA</option>	
									<option value="ACT">ACT</option>	
								</select>
							</div>

						</div>
					</div>
					<!-- Row / End -->
					<br>

					<!-- More Search Options -->
					<!--a href="#" class="more-search-options-trigger margin-bottom-5 margin-top-20" data-open-title="More Filters" data-close-title="More Filters"></a>

					<div class="more-search-options relative">

						< ! - - Checkboxes - - >
						<div class="checkboxes one-in-row margin-bottom-15">
							<!- -	
							<input id="check-a" type="checkbox" name="check">
							<label for="check-a">Elevator in building</label>

							<input id="check-b" type="checkbox" name="check">
							<label for="check-b">Friendly workspace</label>

							<input id="check-c" type="checkbox" name="check">
							<label for="check-c">Instant Book</label>

							<input id="check-d" type="checkbox" name="check">
							<label for="check-d">Wireless Internet</label>

							<input id="check-e" type="checkbox" name="check" >
							<label for="check-e">Free parking on premises</label>

							<input id="check-f" type="checkbox" name="check" >
							<label for="check-f">Free parking on street</label>

							<input id="check-g" type="checkbox" name="check">
							<label for="check-g">Smoking allowed</label>	

							<input id="check-h" type="checkbox" name="check">
							<label for="check-h">Events</label>
							- - >
						</div>
						<!-- Checkboxes / End - - >

					</div>
					< ! - - More Search Options / End -->

					<button class="button fullwidth margin-top-25">Update</button>
					<?php 
						if($u_info != ""):?>
						<button id="get-in-touch" class="button fullwidth margin-top-25">Get in Touch wih -> <?php echo ucfirst($u_info->first_name);?></button>
					<?php
						endif;
					?>
					
					<div class="chat" style="display: none;">
					    <div class="chat-header clearfix">
					       
					        <div class="chat-about">
					          <div class="chat-with"><?php echo ucfirst($u_info->first_name)." ".ucfirst($u_info->last_name);?></div>
					        </div>
					    </div> <!-- end chat-header -->
						<div class="chat-history">
							<?php $this->load->view('chat/chat-box');?>
						</div>
						<?php 
						if($u_info != ""):?>
						<div class="chat-message">
							<input type="hidden" name="to" id="to" value="<?php if($u_info->id_user != ''){ echo $u_info->id_user;}?>">
							<input type="hidden" name="list_id" id="list_id" value="<?php if($u_info->id_list != ''){ echo $u_info->id_list;}?>">
						    
						    <input type="hidden" name="from" id="from" value="<?php echo $this->session->userdata('user_info')->id;?>">
						    
						    <input type="text" id="message-to-send" name="message"  placeholder ="Type your message">
					     </div> <!-- end chat-message -->
					<?php
						endif;
					?>
						
					</div>
				</div>
				<!-- Widget / End -->

			</div>
		</div>
		<!-- Sidebar / End -->