<?php
class Messages_model extends MY_Model{

	function __construct(){
		parent::__construct();
	}
}

?>