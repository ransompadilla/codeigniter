<?php
class UserModel extends MY_Model{

	public function __construct(){
		parent::__construct();
	}

	public $table = 'users';
    public $userdata = ['id','first_name','last_name','email','role','status','account_status','subscription_type','user_type','date_added','date_modified'];
    
	public function authCheck($arr){
	    $this->db->select($this->userdata);
        $this->db->from($this->table);
        $this->db->where($arr);
        $this->db->limit(1);
        $query = $this->db->get();
        
        if ($query->num_rows() == 1) {
            $ret['status'] = true;
            $ret['data'] = $query->row();
            return $ret;
        } else {
            $ret['status'] = false;
            $ret['data'] = '';
            return $ret;
        }
    }
    
}


