<?php
class Messages_model extends MY_Model{

	function __construct(){
		parent::__construct();
	}
	public function getChatMessages($id){

		$this->db->order_by('c.time', 'desc');

		$this->db->where('c.to', $id);
		$this->db->select('DISTINCT(c.from), u.*, c.to, c.from');
   		$this->db->from('users u'); 
		$this->db->join('chat c', 'c.from=u.id', 'right');
		$query = $this->db->get();
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
	
	public function getUnreadMessages($id){
		$query = $this->db->where('from', $id);
		$query = $this->db->where('is_read', "1");
		$query = $this->db->get('chat');
		//$query = $this->db->get_where('chat', array('from'=>$id));
		if($query->num_rows() > 0){
			return $query->result();
		}else{
			return false;
		}
	}
}

?>