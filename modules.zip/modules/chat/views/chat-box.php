
      
        <ul class="chat-body">
          <?php
            if($chat_convo){
              $date_message="";
              foreach ($chat_convo as $chat) : 
                $d = strtotime($chat->time);
                //$date = date('F j h:i A',$d);
                $date_cur_month = date('F j',$d);
                $date_cur_hour = date('h:i A',$d);
                $date_now = date('F j');
                $day_curr = date('j',$d);
                $day_now = date('j');
                if($date_cur_month == $date_now){
                  $date_message = "Today ".$date_cur_hour;
                }
                else{
                  $date_message = $date_cur_month." ".$date_cur_hour;
                }
              if($chat->from == $this->session->userdata('user_info')->id):?>

               <li class="clearfix">
                  <div class="message-data-by-you">
                      <div class="you-message" id="chat-from-message">
                        <?php echo $chat->message;?>
                      </div>
                      <i class="message-time"><?php echo $date_message;?></i>
                  </div>
                 
              </li>
          <?php
          else:?>
             <li>
                <div class="message-data">
                  <div class="message-data-name">
                    <img src="<?php echo base_url('uploads/profile/listing-item-02.jpg')?>" width="30"/>
                    <?php echo ucfirst($u_info->first_name)." ".ucfirst($u_info->last_name);?>
                  </div>
                  
                    <div class="message">
                     <?php echo $chat->message;?>
                    </div>
                  
                  <i class="message-time"><?php echo $date_message;?></i>
                </div>
                
              </li>
          <?php

            endif;
            endforeach;
            }
            else{
              ?>
              <div class="no-data-found">
                <h2> Get in Touch with <?php echo ucfirst($u_info->first_name);?> !</h2>
              </div>
              
          <?php
            }
          ?>

          <li id="isTyping" style="display: none;"><p>is Typing....</p></li>
        </ul>
        
      <!-- </div> --> <!-- end chat-history -->
      


