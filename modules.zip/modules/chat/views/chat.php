<?php $this->load->view('inc/header');?>
<div class="chat">
					    <div class="chat-header clearfix">
					        <div class="chat-about">
					          <div class="chat-with"><?php echo ucfirst($u_info->first_name)." ".ucfirst($u_info->last_name);?> </div>
					        </div>
					    </div> <!-- end chat-header -->
						<div class="chat-history">
							<?php $this->load->view('chat/chat-box');?>
						</div>
						<?php 
						if($u_info != ""):?>
						<div class="chat-message">
							<input type="hidden" name="list_id" id="list_id" value="">
							<input type="hidden" name="to" id="to" value="<?php echo $u_info->id;?>">
						    <input type="hidden" name="from" id="from" value="<?php echo $this->session->userdata('user_info')->id;?>">
						    
						    <input type="text" id="message-to-send" name="message"  placeholder ="Type your message">
					     </div> <!-- end chat-message -->
					<?php
						endif;
					?>
						
					</div>
<?php $this->load->view('inc/header');?>